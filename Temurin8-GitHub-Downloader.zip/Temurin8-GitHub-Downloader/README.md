# Temurin 8 installer downloader

This small GitHub-friendly bundle downloads the official Eclipse Adoptium Temurin 8 JDK installers on demand. The installers themselves are not included (about 205 MB combined).

## macOS Intel (x64)
Run `./download-macos.sh` in Terminal.

## Windows x64
Right-click `download-windows.ps1` and run it with PowerShell, or run:
`powershell -ExecutionPolicy Bypass -File .\download-windows.ps1`

Files are saved in the `downloads` folder next to the script.

Official Adoptium API endpoints:
- macOS x64 JDK 8: https://api.adoptium.net/v3/binary/latest/8/ga/mac/x64/jdk/hotspot/normal/eclipse
- Windows x64 JDK 8: https://api.adoptium.net/v3/binary/latest/8/ga/windows/x64/jdk/hotspot/normal/eclipse
