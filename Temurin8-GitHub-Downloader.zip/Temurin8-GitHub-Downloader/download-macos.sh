#!/bin/sh
set -eu
mkdir -p downloads
curl -fL --retry 3 'https://api.adoptium.net/v3/binary/latest/8/ga/mac/x64/jdk/hotspot/normal/eclipse' -o downloads/OpenJDK8U-jdk_x64_mac_hotspot.pkg
echo 'Downloaded macOS Intel JDK 8 installer to downloads/.'
