$ErrorActionPreference = 'Stop'
New-Item -ItemType Directory -Force -Path 'downloads' | Out-Null
$url = 'https://api.adoptium.net/v3/binary/latest/8/ga/windows/x64/jdk/hotspot/normal/eclipse'
$out = 'downloads/OpenJDK8U-jdk_x64_windows_hotspot.msi'
Invoke-WebRequest -Uri $url -OutFile $out
Write-Host "Downloaded Windows x64 JDK 8 installer to $out"
