# Winter Client 26.3 — Fabric PvP + FPS profile

This is the modern counterpart to the legacy Forge 1.8.9 profile. Minecraft 26.3 uses Fabric (not Forge 1.8.9 mods), Java 25+, Fabric Loader 0.20.1, and Fabric API 0.166.2+26.3.

## Core performance stack

Install the exact 26.3 Fabric releases listed in `mods/manifest.json`:

- Sodium — rendering engine and frame-rate improvement (start with the stable 0.9.2 release)
- Lithium — game logic optimization
- FerriteCore — lower memory use
- ImmediatelyFast — faster GUI and immediate-mode rendering
- Entity Culling — skip rendering hidden entities and block entities
- More Culling — additional face/model culling
- Dynamic FPS — reduce background-window resource use

Mod Menu is included for viewing installed mods. Fabric API is a required library. These are client-side additions; do not put them on a server unless their project page explicitly supports it.

## WinterHUD feature parity

`winter-hud-26.3/` is the original Fabric client mod project. The target feature set mirrors WinterHUD 1.8.9: FPS/CPS, keystrokes, armor and potion status, toggle sprint, zoom, perspective, HUD visibility/layout, plus the existing PvP visual options (block outline color, hit color and hitboxes). Features will be brought across in version-safe stages rather than reusing Forge 1.8.9 bytecode.

## Installation

Use the launcher's Minecraft 26.3 profile and its matching game directory. Install Fabric Loader for 26.3, then place the downloaded `.jar` files from the official Modrinth project pages into that profile's `mods/` directory. The manifest records Modrinth project/version identifiers and official file URLs; third-party binaries are deliberately not bundled in this repository.

For the 2015 Intel MacBook Pro with 8 GB RAM, start with 4–6 render distance, 4 simulation distance, Fast graphics, clouds off, minimal particles, no shaders, and a 60 FPS cap. Test frame pacing and temperatures before raising the cap. Sodium is the primary renderer; do not add a second renderer replacement.