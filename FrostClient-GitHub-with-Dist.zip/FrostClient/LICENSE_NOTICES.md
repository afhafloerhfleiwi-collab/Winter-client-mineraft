# Third-party notices

## Winter Client launcher

The launcher source in `launcher/` is original project code. It is not derived from HMCL or another Minecraft launcher framework.

## Minecraft

Minecraft Java Edition is proprietary software. Winter Client does not include or redistribute Minecraft binaries, assets, or account credentials. Users must obtain Minecraft through official channels and comply with Mojang/Microsoft terms.

## Forge, OptiFine and other mods

Forge, OptiFine and third-party mods are not bundled in the launcher. Users obtain them from their respective official authors and must follow each project's license and compatibility requirements. WinterHUD is original client-side mod source in this project.
