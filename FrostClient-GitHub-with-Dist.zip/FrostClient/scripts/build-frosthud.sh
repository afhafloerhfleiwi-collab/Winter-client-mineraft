#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
JAVA8_HOME="${JAVA8_HOME:-}"
if [[ -z "$JAVA8_HOME" ]]; then
  for candidate in /Library/Java/JavaVirtualMachines/*/Contents/Home; do
    if [[ -x "$candidate/bin/javac" ]] && "$candidate/bin/java" -version 2>&1 | grep -q 'version "1.8'; then
      JAVA8_HOME="$candidate"
      break
    fi
  done
fi
if [[ -z "$JAVA8_HOME" || ! -x "$JAVA8_HOME/bin/javac" ]]; then
  echo "WinterHUD's legacy ForgeGradle toolchain requires a 64-bit JDK 8 (javac included). Install Temurin 8 or set JAVA8_HOME to its JDK path." >&2
  exit 1
fi
export JAVA_HOME="$JAVA8_HOME"
export PATH="$JAVA_HOME/bin:$PATH"
TOOLS="$ROOT/.tools"
GRADLE_VERSION=2.14.1
GRADLE_HOME="$TOOLS/gradle-$GRADLE_VERSION"
if [[ ! -x "$GRADLE_HOME/bin/gradle" ]]; then
  mkdir -p "$TOOLS"
  ZIP="$TOOLS/gradle-$GRADLE_VERSION-bin.zip"
  curl -fL "https://services.gradle.org/distributions/gradle-$GRADLE_VERSION-bin.zip" -o "$ZIP"
  unzip -q -o "$ZIP" -d "$TOOLS"
fi
cd "$ROOT/frost-hud"
"$GRADLE_HOME/bin/gradle" build --no-daemon
mkdir -p "$ROOT/dist/mods"
cp build/libs/WinterHUD-1.0.0.jar "$ROOT/dist/mods/WinterHUD-1.0.0.jar"
echo "Built: $ROOT/dist/mods/WinterHUD-1.0.0.jar"