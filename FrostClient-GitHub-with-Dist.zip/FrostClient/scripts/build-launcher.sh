#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
BUILD="$ROOT/launcher/build"
rm -rf "$BUILD"
mkdir -p "$BUILD/classes" "$ROOT/dist"
find "$ROOT/launcher/src/main/java" -name '*.java' -print0 | xargs -0 javac -encoding UTF-8 -source 8 -target 8 -d "$BUILD/classes"
HUD_JAR="$ROOT/winter-hud-26.3/build/libs/WinterHUD-0.1.0.jar"
if [[ -f "$HUD_JAR" ]]; then cp "$HUD_JAR" "$BUILD/classes/winterhud-26.3.jar"; fi
printf 'Manifest-Version: 1.0\nMain-Class: com.frostclient.Launcher\n\n' > "$BUILD/manifest.mf"
jar cfm "$ROOT/dist/WinterClient.jar" "$BUILD/manifest.mf" -C "$BUILD/classes" .
echo "Built Winter Client launcher: $ROOT/dist/WinterClient.jar"