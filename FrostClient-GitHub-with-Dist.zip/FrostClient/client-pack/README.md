# Winter Client 1.8.9 PvP profile

This folder describes the game profile; it deliberately contains no Minecraft or third-party binary files.

## Recommended instance

- Minecraft: `1.8.9`
- Forge: `1.8.9-11.15.1.2318-1.8.9`
- Optional renderer: OptiFine HD U M5 (download directly from the official OptiFine site; never use repacked mirrors).
- Java runtime: 64-bit Java 8 for Minecraft 1.8.9. The Winter Client launcher itself runs on Java 8 or newer.

Use Winter Client's Version Manager to download Minecraft 1.8.9 and the official Forge installer. In the Forge installer window, choose Install client and confirm the same game directory configured in Winter Client. Add only mods that explicitly support Minecraft 1.8.9 + Forge and whose licenses permit your intended use. Do not mix Fabric mods into this Forge instance.

## PvP features

WinterHUD supplies FPS/CPS, keystrokes, armor durability, potion timers, toggle sprint, zoom, and perspective controls. See `mods/README.md` for installation. The HUD has compiled but still needs an in-game smoke test.

- Visuals: use OptiFine's crosshair options and Minecraft's minimal particles; advanced crosshair/hit-color customization is not implemented yet.
- Performance: avoid duplicate HUD/render mods and test each optional mod separately.

## Low-end profile

The included `options.txt` is a conservative starting template: 6 chunks, Fast graphics, minimum smooth lighting, clouds off, minimal particles, entity shadows off, no shaders, 16x textures, and a 60 FPS cap. The 2015 Intel MacBook Pro is thermally constrained; test 90/120 FPS only if temperatures and frame pacing remain stable.
