# Optional 1.8.9 mods

WinterHUD is built locally as `dist/mods/WinterHUD-1.0.0.jar`; copy it into the Forge 1.8.9 instance's `mods/` folder. It provides FPS/CPS, keystrokes, armor durability, potion timers, toggle sprint, zoom, and perspective controls. It has compiled successfully but has not yet been tested inside a live Minecraft session.

No third-party binary mods are included in this repository. Download only from the authors' official pages and verify each mod's supported Minecraft version and loader.

| Mod | Purpose | Official source / notes |
|---|---|---|
| WinterHUD | Original lightweight PvP HUD and controls | Build with `./scripts/build-frosthud.sh`; source in `frost-hud/`. |
| OptiFine HD U M5 | Graphics options, FPS tuning, zoom | [Official downloads](https://optifine.net/downloads). 1.8.9 stable release; install manually. Proprietary; not redistributed here. |

Avoid installing multiple mods that duplicate the same HUD/render hooks. Test one addition at a time and remove it if frame pacing worsens.
