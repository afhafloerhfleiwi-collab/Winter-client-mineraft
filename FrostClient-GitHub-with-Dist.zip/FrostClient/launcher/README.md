# Winter Client Launcher

This is an original Java Swing launcher written for this project. It does not use HMCL or another launcher framework.

## Current features
- Lists official Mojang release versions from the Mojang version manifest.
- Installs vanilla versions by downloading the version JSON, client JAR, libraries, native libraries and asset objects, checking SHA-1 hashes supplied by Mojang.
- Lists compatible Fabric Loader builds from the official Fabric Meta API and Forge builds from official Forge Maven metadata for the selected Minecraft release. Installs the selected client profile with the official Fabric or Forge installer, using a Java major version matched to Minecraft.
- OptiFine 1.8.9 HD U M5 is user-downloaded from the official OptiFine website; the launcher does not redistribute or silently fetch it. The Version Manager imports the selected JAR only after checking its known SHA-256, expected size, and required classes, then installs it into the Minecraft `mods` folder.
- Selects local profiles, configures player display name, Java executable, game directory and maximum heap.
- Saves settings under `~/.frostclient/launcher.properties`.
- Opens the mods folder and writes game output to `frost-client.log`.
- Resolves inherited legacy profile metadata so Forge profiles can use the vanilla client JAR and inherited libraries.
- Imports Modrinth `.mrpack` and supported `.zip` modpacks into isolated `instances/<version>` folders, keeping each version's mods/config/resourcepacks/shaderpacks separate. Existing files are preserved with `.modpack-N` conflict suffixes. Modrinth mod downloads are checksum-verified; required Fabric/Forge loader profiles must be installed first. CurseForge manifests are not supported.
## Authentication
- Microsoft sign-in uses the browser OAuth flow and verifies Xbox Live, Minecraft Java entitlement, and the Java profile.
- LittleSkin uses Yggdrasil authentication and the authlib-injector compatibility layer.
- Passwords are never saved. Refreshable session tokens are stored in the macOS login Keychain and refreshed when Winter Client starts.
- Offline identities only work on offline-mode servers.
- Loader installation runs the official installer in client-install mode after explicit confirmation and verifies that the expected version profile was created.
- The launcher targets legacy Minecraft 1.8.9 metadata; newer modern-argument versions may install but are not currently launchable.
- Java 8 is recommended for Minecraft 1.8.9.
