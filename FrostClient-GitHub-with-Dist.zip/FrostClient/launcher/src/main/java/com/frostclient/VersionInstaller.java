package com.frostclient;

import java.io.*;
import java.net.*;
import java.nio.file.*;
import java.security.*;
import java.util.*;
import java.util.zip.*;
import java.util.function.Consumer;

/** Downloads official Mojang version files and the official Forge installer. */
final class VersionInstaller {
    private static final String MANIFEST = "https://piston-meta.mojang.com/mc/game/version_manifest_v2.json";
    private static final String FORGE_VERSION = "1.8.9-11.15.1.2318-1.8.9";
    private static final String FORGE_INSTALLER = "https://maven.minecraftforge.net/net/minecraftforge/forge/" + FORGE_VERSION + "/forge-" + FORGE_VERSION + "-installer.jar";
    private static final String OPTIFINE_M5_FILE = "OptiFine_1.8.9_HD_U_M5.jar";
    private static final long OPTIFINE_M5_SIZE = 2585014L;
    private static final String OPTIFINE_M5_SHA256 = "2739760a70fca6ae5c7dc817bcc6283f18f55e38fa23778da7f387a6b724b2c4";
    private static final String OPTIFINE_M6_FILE = "preview_OptiFine_1.8.9_HD_U_M6_pre2.jar";
    private static final long OPTIFINE_M6_SIZE = 2584186L;    private final File gameDir;
    VersionInstaller(File gameDir) { this.gameDir = gameDir.getAbsoluteFile(); }

    List<String> listReleases() throws Exception {
        Map<String,Object> manifest = map(new Json(readUrl(MANIFEST)).parse());
        List<String> releases = new ArrayList<String>();
        Object versions = manifest.get("versions");
        if (versions instanceof List) for (Object item : (List<?>) versions) {
            Map<String,Object> v = map(item);
            if ("release".equals(v.get("type")) && v.get("id") instanceof String) releases.add((String)v.get("id"));
        }
        return releases;
    }

    List<String> listFabricLoaderVersions(String minecraftVersion) throws Exception {
        String url = "https://meta.fabricmc.net/v2/versions/loader/" + URLEncoder.encode(minecraftVersion, "UTF-8");
        Object parsed = new Json(readUrl(url)).parse();
        List<String> result = new ArrayList<String>();
        if (parsed instanceof List) for (Object item : (List<?>)parsed) {
            String version = string(map(map(item).get("loader")).get("version"));
            if (version != null && !result.contains(version)) result.add(version);
        }
        if (result.isEmpty()) throw new IOException("Fabric does not publish a loader build for Minecraft " + minecraftVersion + ".");
        return result;
    }

    List<String> listForgeVersions(String minecraftVersion) throws Exception {
        String xml = readUrl("https://maven.minecraftforge.net/net/minecraftforge/forge/maven-metadata.xml");
        java.util.regex.Matcher matcher = java.util.regex.Pattern.compile("<version>" + java.util.regex.Pattern.quote(minecraftVersion) + "-([^<]+)</version>").matcher(xml);
        List<String> result = new ArrayList<String>();
        while (matcher.find()) result.add(matcher.group(1));
        Collections.reverse(result);
        if (result.isEmpty()) throw new IOException("Forge does not publish installer builds for Minecraft " + minecraftVersion + ".");
        return result;
    }

    File installForgeClient(String minecraftVersion, String forgeVersion, String javaExecutable, Consumer<String> progress) throws Exception {
        if (minecraftVersion == null || !minecraftVersion.matches("[0-9]+\\.[0-9]+(\\.[0-9]+)?")) throw new IOException("Invalid Minecraft version.");
        if (forgeVersion == null || !forgeVersion.matches("[A-Za-z0-9._-]+")) throw new IOException("Invalid Forge version.");
        File downloads = safe(new File(gameDir, "frost-downloads").getPath());
        if (!downloads.isDirectory() && !downloads.mkdirs()) throw new IOException("Could not create download directory.");
        String coordinate = minecraftVersion + "-" + forgeVersion;
        String filename = "forge-" + coordinate + "-installer.jar";
        String url = "https://maven.minecraftforge.net/net/minecraftforge/forge/" + coordinate + "/" + filename;
        File installer = safe(new File(downloads, filename).getPath());
        progress.accept("Downloading official Forge " + forgeVersion + " for Minecraft " + minecraftVersion + "…");
        String checksum = null;
        try { checksum = readUrl(url + ".sha1").trim().split("\\s+")[0]; } catch (Exception ignored) { }
        writeVerified(url, installer, checksum);
        progress.accept("Running Forge client installer…");
        Process process = new ProcessBuilder(javaExecutable, "-jar", installer.getAbsolutePath(), "--installClient", gameDir.getAbsolutePath()).directory(gameDir).redirectErrorStream(true).start();
        StringBuilder output = new StringBuilder();
        BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream(), "UTF-8"));
        String line;
        while ((line = reader.readLine()) != null) { if (output.length() < 12000) output.append(line).append('\n'); progress.accept(line); }
        int exit = process.waitFor();
        if (exit != 0) throw new IOException("Forge installer failed (exit " + exit + "): " + output);
        File versionsRoot = new File(gameDir, "versions");
        File[] installed = versionsRoot.listFiles();
        File profile = null;
        if (installed != null) for (File entry : installed) {
            String id = entry.getName();
            if (!entry.isDirectory() || !id.startsWith(minecraftVersion) || !id.toLowerCase(Locale.ROOT).contains("forge")) continue;
            File candidate = new File(entry, id + ".json");
            if (!candidate.isFile()) continue;
            try {
                Map<String,Object> metadata = map(new Json(new String(Files.readAllBytes(candidate.toPath()), "UTF-8")).parse());
                String parent = string(metadata.get("inheritsFrom"));
                boolean matchingParent = minecraftVersion.equals(parent);
                boolean hasForgeLibrary = false;
                Object libraries = metadata.get("libraries");
                if (libraries instanceof List) for (Object library : (List<?>)libraries) {
                    String name = string(map(library).get("name"));
                    if (name != null && name.startsWith("net.minecraftforge:forge:")) { hasForgeLibrary = true; break; }
                }
                if (matchingParent && hasForgeLibrary) { profile = candidate; break; }
            } catch (Exception ignored) { }
        }
        if (profile == null) throw new IOException("Forge installer completed but no matching Forge client profile was found for Minecraft " + minecraftVersion + ". Installer output: " + output);
        progress.accept("Forge " + forgeVersion + " installed for Minecraft " + minecraftVersion + ".");
        return profile;    }

    void installVanilla(String id, Consumer<String> progress) throws Exception {
        Map<String,Object> manifest = map(new Json(readUrl(MANIFEST)).parse());
        Map<String,Object> selected = null;
        for (Object item : (List<?>)manifest.get("versions")) {
            Map<String,Object> v = map(item);
            if (id.equals(v.get("id"))) { selected = v; break; }
        }
        if (selected == null) throw new IOException("Version not found in Mojang manifest: " + id);
        progress.accept("Downloading " + id + " metadata…");
        Map<String,Object> meta = map(new Json(readUrl((String)selected.get("url"))).parse());
        File versionDir = safe(new File(gameDir, "versions/" + id).getPath());
        versionDir.mkdirs();
        File json = new File(versionDir, id + ".json");
        writeVerified((String)selected.get("url"), json, string(selected.get("sha1")));        Map<String,Object> downloads = map(meta.get("downloads"));
        Map<String,Object> client = map(downloads.get("client"));
        progress.accept("Downloading Minecraft " + id + " client…");
        writeVerified(string(client.get("url")), new File(versionDir, id + ".jar"), string(client.get("sha1")));

        progress.accept("Downloading libraries…");
        File nativesDir = new File(versionDir, id + "-natives");
        nativesDir.mkdirs();
        Object libs = meta.get("libraries");
        if (libs instanceof List) for (Object item : (List<?>)libs) {
            Map<String,Object> lib = map(item);
            if (!libraryAllowed(lib)) continue;
            Map<String,Object> dl = map(lib.get("downloads"));
            Map<String,Object> artifact = map(dl.get("artifact"));
            if (artifact.get("url") instanceof String && artifact.get("path") instanceof String) {
                File dest = safe(new File(gameDir, "libraries/" + artifact.get("path")).getPath());
                writeVerified(string(artifact.get("url")), dest, string(artifact.get("sha1")));
                if (isNativeClassifier(lib)) extractNatives(dest, new File(nativesDir, nativeDirectory(lib)));
            }
            String nativeKey = nativeKey(map(lib.get("natives")));
            Map<String,Object> classifiers = map(dl.get("classifiers"));
            Map<String,Object> nativeArtifact = map(classifiers.get(nativeKey));
            if (nativeArtifact.get("url") instanceof String && nativeArtifact.get("path") instanceof String) {
                File nativeJar = safe(new File(gameDir, "libraries/" + nativeArtifact.get("path")).getPath());
                writeVerified(string(nativeArtifact.get("url")), nativeJar, string(nativeArtifact.get("sha1")));
                extractNatives(nativeJar, nativesDir);
            }
        }


        Map<String,Object> logging = map(meta.get("logging"));
        Map<String,Object> clientLogging = map(logging.get("client"));
        Map<String,Object> loggingFile = map(clientLogging.get("file"));
        if (loggingFile.get("url") instanceof String && loggingFile.get("id") instanceof String) {
            File config = safe(new File(gameDir, "assets/log_configs/" + loggingFile.get("id")).getPath());
            writeVerified(string(loggingFile.get("url")), config, string(loggingFile.get("sha1")));
        }

        Map<String,Object> assetIndex = map(meta.get("assetIndex"));
        if (assetIndex.get("url") instanceof String) {
            progress.accept("Downloading asset index…");
            String indexText = readUrl((String)assetIndex.get("url"));
            File indexFile = safe(new File(gameDir, "assets/indexes/" + assetIndex.get("id") + ".json").getPath());
            writeBytes(indexText.getBytes("UTF-8"), indexFile, string(assetIndex.get("sha1")));            Map<String,Object> index = map(new Json(indexText).parse());
            Map<String,Object> objects = map(index.get("objects"));
            int total = objects.size(), done = 0;
            for (Object value : objects.values()) {
                Map<String,Object> obj = map(value);
                String hash = string(obj.get("hash"));
                if (hash == null || hash.length() < 2) continue;
                File object = safe(new File(gameDir, "assets/objects/" + hash.substring(0,2) + "/" + hash).getPath());                if (!object.isFile() || !sha1(object).equalsIgnoreCase(hash)) {
                    writeVerified("https://resources.download.minecraft.net/" + hash.substring(0,2) + "/" + hash, object, hash);
                }
                done++;
                if (done % 100 == 0) progress.accept("Downloading assets… " + done + "/" + total);
            }
        }
        progress.accept("Minecraft " + id + " installed.");
    }

    File downloadForgeInstaller(Consumer<String> progress) throws Exception {
        File dir = safe(new File(gameDir, "frost-downloads").getPath());
        dir.mkdirs();
        File installer = safe(new File(dir, "forge-" + FORGE_VERSION + "-installer.jar").getPath());
        progress.accept("Downloading official Forge 1.8.9 installer…");
        String checksum = readUrl(FORGE_INSTALLER + ".sha1").trim().split("\\s+")[0];
        writeVerified(FORGE_INSTALLER, installer, checksum);
        progress.accept("Forge installer downloaded and checksum verified.");
        return installer;
    }

    File installFabricClient(String minecraftVersion, String loaderVersion, String javaExecutable, Consumer<String> progress) throws Exception {
        File downloads = safe(new File(gameDir, "frost-downloads").getPath());
        if (!downloads.isDirectory() && !downloads.mkdirs()) throw new IOException("Could not create download directory.");
        String installerVersion = "1.1.2";
        String installerName = "fabric-installer-" + installerVersion + ".jar";
        String installerUrl = "https://maven.fabricmc.net/net/fabricmc/fabric-installer/" + installerVersion + "/" + installerName;
        File installer = safe(new File(downloads, installerName).getPath());
        progress.accept("Downloading official Fabric Installer " + installerVersion + "…");
        String checksum = readUrl(installerUrl + ".sha1").trim().split("\\s+")[0];        writeVerified(installerUrl, installer, checksum);
        // Winter Client manages version profiles itself and does not rely on Mojang's legacy launcher_profiles.json.
        // Skip Fabric Installer's optional launcher-profile registration; otherwise it fails when no supported
        // official launcher profile is present, even though the loader files can be installed successfully.
        List<String> command = Arrays.asList(javaExecutable, "-jar", installer.getAbsolutePath(), "client", "-dir", gameDir.getAbsolutePath(), "-mcversion", minecraftVersion, "-loader", loaderVersion, "-noprofile");        Process process = new ProcessBuilder(command).directory(gameDir).redirectErrorStream(true).start();
        StringBuilder output = new StringBuilder();
        BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream(), "UTF-8"));
        String line; while ((line = reader.readLine()) != null) { if (output.length() < 12000) output.append(line).append('\n'); progress.accept(line); }        int exit = process.waitFor();
        if (exit != 0) throw new IOException("Fabric installer failed (exit " + exit + "): " + output);
        File profile = new File(gameDir, "versions/fabric-loader-" + loaderVersion + "-" + minecraftVersion + "/fabric-loader-" + loaderVersion + "-" + minecraftVersion + ".json");
        if (!profile.isFile()) throw new IOException("Fabric installer finished but did not create the expected profile: " + profile);
        progress.accept("Fabric Loader installed successfully.");
        return profile;
    }

    File install26PerformanceMods(Consumer<String> progress) throws Exception {
        String[] versionIds = {"bAZQdGpg", "fWv5bnZk", "d5ddUdiB", "3MP9UR23", "UWpkLRV5", "5jIORlSK", "Jwq069rR", "Zns5SSRA", "fg2uyxOW"};
        File mods = safe(new File(gameDir, "instances/26.3-fabric/mods").getPath());
        if (!mods.isDirectory() && !mods.mkdirs()) throw new IOException("Could not create Minecraft 26.3 Fabric mods folder: " + mods);
        for (String versionId : versionIds) {
            progress.accept("Checking Modrinth release " + versionId + "…");
            Map<String,Object> version = map(new Json(readUrl("https://api.modrinth.com/v2/version/" + versionId)).parse());
            List<?> files = (List<?>) version.get("files");
            if (files == null || files.isEmpty()) throw new IOException("Modrinth returned no files for version " + versionId);
            Map<String,Object> selected = map(files.get(0));
            for (Object candidate : files) if (Boolean.TRUE.equals(map(candidate).get("primary"))) { selected = map(candidate); break; }
            String filename = string(selected.get("filename"));
            String url = string(selected.get("url"));
            String expected = string(map(selected.get("hashes")).get("sha1"));
            if (filename == null || url == null || expected == null) throw new IOException("Incomplete Modrinth file metadata for " + versionId);
            File target = safe(new File(mods, filename).getPath());
            progress.accept("Downloading " + filename + "…");
            writeVerified(url, target, expected);
        }
        File winterHud = safe(new File(mods, "WinterHUD-0.1.0.jar").getPath());
        try (InputStream bundled = VersionInstaller.class.getResourceAsStream("/winterhud-26.3.jar")) {
            if (bundled == null) throw new IOException("WinterHUD 26.3 is not bundled in this launcher. Rebuild Winter Client after building winter-hud-26.3.");
            Files.copy(bundled, winterHud.toPath(), StandardCopyOption.REPLACE_EXISTING);
        }
        try (ZipFile zip = new ZipFile(winterHud)) {
            if (zip.getEntry("fabric.mod.json") == null || zip.getEntry("net/frostclient/winterhud/WinterHudClient.class") == null)
                throw new IOException("Bundled WinterHUD archive failed validation.");
        }
        progress.accept("Installed 7 performance mods, Fabric API, Cloth Config and WinterHUD into " + mods.getAbsolutePath());
        return mods;
    }    File importOptiFine(File source, Consumer<String> progress) throws Exception {        if (source == null || !source.isFile() || !source.canRead()) throw new IOException("Choose an official OptiFine 1.8.9 JAR downloaded from optifine.net.");
        String fileName = source.getName();
        boolean isM5 = OPTIFINE_M5_FILE.equals(fileName) && source.length() == OPTIFINE_M5_SIZE && sha256(source).equalsIgnoreCase(OPTIFINE_M5_SHA256);
        boolean isM6 = OPTIFINE_M6_FILE.equals(fileName) && source.length() == OPTIFINE_M6_SIZE;
        if (!isM5 && !isM6) throw new IOException("Unsupported OptiFine file. Choose the official M5 build or M6 pre2 preview for Minecraft 1.8.9.");
        String label = isM6 ? "HD U M6 pre2" : "HD U M5";
        progress.accept("Validating OptiFine " + label + " archive…");
        ZipFile zip = new ZipFile(source);
        try {
            if (zip.getEntry("optifine/OptiFineClassTransformer.class") == null || zip.getEntry("Config.class") == null || zip.getEntry("optifine/Installer.class") == null)
                throw new IOException("The selected JAR does not contain the expected OptiFine classes.");
        } finally { zip.close(); }
        File mods = safe(new File(gameDir, "mods").getPath());
        if (!mods.isDirectory() && !mods.mkdirs()) throw new IOException("Could not create the Minecraft mods folder: " + mods);
        String targetName = isM6 ? OPTIFINE_M6_FILE : OPTIFINE_M5_FILE;
        File target = safe(new File(mods, targetName).getPath());
        progress.accept("Installing OptiFine " + label + " into the Forge 1.8.9 mods folder…");
        Files.copy(source.toPath(), target.toPath(), StandardCopyOption.REPLACE_EXISTING);
        if (target.length() != source.length() || (isM5 && !sha256(target).equalsIgnoreCase(OPTIFINE_M5_SHA256))) {
            target.delete(); throw new IOException("OptiFine changed while being copied; installation was rolled back.");
        }
        progress.accept("OptiFine " + label + " installed. M6 pre2 is a preview release; test it separately if M5 caused a launch crash.");
        return target;
    }

    private static String sha256(File file) throws Exception {        MessageDigest digest = MessageDigest.getInstance("SHA-256"); InputStream in = new FileInputStream(file);
        try { byte[] buffer = new byte[32768]; int count; while ((count = in.read(buffer)) != -1) digest.update(buffer, 0, count); } finally { in.close(); }
        StringBuilder out = new StringBuilder(); for (byte b : digest.digest()) out.append(String.format("%02x", b & 255)); return out.toString();
    }
    private boolean isNativeClassifier(Map<String,Object> library) {
        String coordinate=string(library.get("name")); if(coordinate==null)return false;
        String[] parts=coordinate.split(":"); return parts.length>3 && parts[3].startsWith("natives-");
    }
    private String nativeDirectory(Map<String,Object> library) {
        String coordinate=string(library.get("name"));
        if(coordinate==null)return "java";
        if(coordinate.startsWith("org.lwjgl:"))return "lwjgl";
        if(coordinate.startsWith("io.netty:"))return "netty";
        if(coordinate.startsWith("net.java.dev.jna:"))return "jna";
        return "java";
    }

    private boolean libraryAllowed(Map<String,Object> library) {
        Object raw=library.get("rules");
        if(raw instanceof List) {
            boolean allowed=false;
            for(Object value:(List<?>)raw) {
                Map<String,Object> rule=map(value), os=map(rule.get("os"));
                if(!os.isEmpty()) {
                    String expected=string(os.get("name")); String current=System.getProperty("os.name","").toLowerCase(Locale.ROOT);
                    String actual=current.contains("mac")?"osx":current.contains("win")?"windows":current.contains("linux")?"linux":"unknown";
                    if(expected!=null&&!expected.equals(actual))continue;
                    String pattern=string(os.get("arch"));
                    if(pattern!=null&&!java.util.regex.Pattern.compile(pattern).matcher(System.getProperty("os.arch","")).matches())continue;
                }
                allowed="allow".equals(string(rule.get("action")));
            }
            if(!allowed)return false;
        }
        String coordinate=string(library.get("name")); if(coordinate==null)return true;
        String[] parts=coordinate.split(":"); if(parts.length<4)return true;
        String classifier=parts[3].toLowerCase(Locale.ROOT), arch=System.getProperty("os.arch","").toLowerCase(Locale.ROOT);
        boolean arm=arch.contains("aarch64")||arch.contains("arm64");
        if(classifier.contains("arm64")||classifier.contains("aarch64"))return arm;
        if(classifier.contains("x86_64")||classifier.contains("amd64"))return !arm;
        if(classifier.startsWith("natives-")&&(classifier.endsWith("-macos")||classifier.endsWith("-windows")||classifier.endsWith("-linux")))return !arm;
        return true;
    }

    private String nativeKey(Map<String,Object> natives) {
        String os = System.getProperty("os.name").toLowerCase(Locale.ROOT);
        String key = os.contains("mac") ? "osx" : os.contains("win") ? "windows" : "linux";
        String value = string(natives.get(key));
        if (value == null) return "";
        return value.replace("${arch}", System.getProperty("os.arch").contains("64") ? "64" : "32");
    }
    private void extractNatives(File jar, File dest) throws Exception {
        if (!dest.isDirectory()) dest.mkdirs();
        ZipInputStream in = new ZipInputStream(new FileInputStream(jar));
        try {
            ZipEntry e;
            while ((e = in.getNextEntry()) != null) {
                String n = e.getName();
                if (e.isDirectory() || n.startsWith("META-INF/") || n.contains("/") || !(n.endsWith(".dylib") || n.endsWith(".jnilib") || n.endsWith(".so") || n.endsWith(".dll"))) continue;
                File out = safe(new File(dest, n).getPath());
                Files.copy(in, out.toPath(), StandardCopyOption.REPLACE_EXISTING);
            }
        } finally { in.close(); }
    }
    private File safe(String path) throws IOException {
        File f = new File(path).getCanonicalFile();
        String base = gameDir.getCanonicalPath() + File.separator;
        if (!f.getPath().startsWith(base)) throw new IOException("Refusing path outside game directory: " + path);
        return f;
    }
    private void writeVerified(String url, File dest, String expectedSha1) throws Exception {
        if (url == null) throw new IOException("Download URL missing for " + dest);
        if (dest.isFile() && expectedSha1 != null && sha1(dest).equalsIgnoreCase(expectedSha1)) return;
        File parent = dest.getParentFile(); if (parent != null) parent.mkdirs();
        File tmp = new File(dest.getPath() + ".part");
        URLConnection connection = new URL(url).openConnection();
        connection.setConnectTimeout(15000); connection.setReadTimeout(30000);
        InputStream in = connection.getInputStream();
        try { Files.copy(in, tmp.toPath(), StandardCopyOption.REPLACE_EXISTING); } finally { in.close(); }        if (expectedSha1 != null && !sha1(tmp).equalsIgnoreCase(expectedSha1)) { tmp.delete(); throw new IOException("SHA-1 mismatch for " + dest.getName()); }
        try { Files.move(tmp.toPath(), dest.toPath(), StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
        catch (AtomicMoveNotSupportedException e) { Files.move(tmp.toPath(), dest.toPath(), StandardCopyOption.REPLACE_EXISTING); }
    }
    private void writeBytes(byte[] bytes, File dest, String expectedSha1) throws Exception {
        File parent=dest.getParentFile();if(parent!=null)parent.mkdirs();Files.write(dest.toPath(),bytes);
        if(expectedSha1!=null&&!sha1(dest).equalsIgnoreCase(expectedSha1))throw new IOException("SHA-1 mismatch for "+dest);
    }
    private String readUrl(String url) throws Exception {
        URLConnection c=new URL(url).openConnection();c.setConnectTimeout(15000);c.setReadTimeout(30000);
        InputStream in=c.getInputStream();ByteArrayOutputStream out=new ByteArrayOutputStream();
        try{byte[] b=new byte[32768];int n;while((n=in.read(b))!=-1)out.write(b,0,n);}finally{in.close();}
        return new String(out.toByteArray(),"UTF-8");
    }
    private static String sha1(File f) throws Exception {
        MessageDigest d=MessageDigest.getInstance("SHA-1");InputStream in=new FileInputStream(f);
        try{byte[] b=new byte[32768];int n;while((n=in.read(b))!=-1)d.update(b,0,n);}finally{in.close();}
        StringBuilder s=new StringBuilder();for(byte b:d.digest())s.append(String.format("%02x",b&255));return s.toString();
    }
    @SuppressWarnings("unchecked") private static Map<String,Object> map(Object o){return o instanceof Map?(Map<String,Object>)o:Collections.<String,Object>emptyMap();}
    private static String string(Object o){return o instanceof String?(String)o:null;}

    private static final class Json {
        final String s; int i; Json(String s){this.s=s;}
        Object parse(){Object v=value();ws();if(i!=s.length())throw new IllegalArgumentException("Trailing JSON");return v;}
        Object value(){ws();char c=s.charAt(i);if(c=='{')return obj();if(c=='[')return arr();if(c=='"')return str();if(c=='t'){i+=4;return true;}if(c=='f'){i+=5;return false;}if(c=='n'){i+=4;return null;}return num();}
        Map<String,Object> obj(){Map<String,Object>m=new LinkedHashMap<String,Object>();i++;ws();if(take('}'))return m;do{ws();String k=str();ws();need(':');m.put(k,value());ws();if(take('}'))return m;need(',');}while(true);}
        List<Object> arr(){List<Object>a=new ArrayList<Object>();i++;ws();if(take(']'))return a;do{a.add(value());ws();if(take(']'))return a;need(',');}while(true);}
        String str(){need('"');StringBuilder b=new StringBuilder();while(i<s.length()){char c=s.charAt(i++);if(c=='"')return b.toString();if(c=='\\'){char e=s.charAt(i++);switch(e){case '"':case '\\':case '/':b.append(e);break;case 'b':b.append('\b');break;case 'f':b.append('\f');break;case 'n':b.append('\n');break;case 'r':b.append('\r');break;case 't':b.append('\t');break;case 'u':b.append((char)Integer.parseInt(s.substring(i,i+4),16));i+=4;break;default:throw new IllegalArgumentException("Bad JSON escape");}}else b.append(c);}throw new IllegalArgumentException("Unclosed JSON string");}
        Number num(){int start=i;while(i<s.length()&&"-+0123456789.eE".indexOf(s.charAt(i))>=0)i++;String n=s.substring(start,i);return n.indexOf('.')>=0?Double.valueOf(n):Long.valueOf(n);}
        void ws(){while(i<s.length()&&Character.isWhitespace(s.charAt(i)))i++;}
        boolean take(char c){if(i<s.length()&&s.charAt(i)==c){i++;return true;}return false;}
        void need(char c){if(!take(c))throw new IllegalArgumentException("Expected "+c+" at "+i);}
    }
}
