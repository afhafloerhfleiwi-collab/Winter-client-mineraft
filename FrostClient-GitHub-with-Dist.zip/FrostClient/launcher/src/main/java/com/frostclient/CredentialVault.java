package com.frostclient;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;

/** Stores launcher session material in the macOS login Keychain, never in launcher.properties. */
final class CredentialVault {
    private static final String SERVICE = "com.frostclient.auth";
    private static final String ACCOUNT = "selected-session";
    private CredentialVault() {}

    static void save(String value) throws Exception {
        run(new String[]{"/usr/bin/security","add-generic-password","-U","-a",ACCOUNT,"-s",SERVICE,"-w",value}, false);
    }

    static String load() throws Exception {
        Result r=run(new String[]{"/usr/bin/security","find-generic-password","-a",ACCOUNT,"-s",SERVICE,"-w"}, true);
        return r.code==0?r.output.trim():null;
    }

    static void clear() throws Exception {
        run(new String[]{"/usr/bin/security","delete-generic-password","-a",ACCOUNT,"-s",SERVICE}, true);
    }

    private static Result run(String[] command, boolean allowFailure) throws Exception {
        Process p=new ProcessBuilder(command).redirectErrorStream(true).start();
        ByteArrayOutputStream out=new ByteArrayOutputStream();
        InputStream in=p.getInputStream(); byte[] buffer=new byte[1024]; int n;
        while((n=in.read(buffer))!=-1) out.write(buffer,0,n);
        int code=p.waitFor();
        String output=new String(out.toByteArray(),StandardCharsets.UTF_8);
        if(code!=0&&!allowFailure) throw new IllegalStateException(output.trim().isEmpty()?"macOS Keychain operation failed.":output.trim());
        return new Result(code,output);
    }

    private static final class Result {
        final int code; final String output;
        Result(int code,String output){this.code=code;this.output=output;}
    }
}
