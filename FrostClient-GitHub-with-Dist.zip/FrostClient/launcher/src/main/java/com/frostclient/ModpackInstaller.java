package com.frostclient;

import java.io.*;
import java.net.*;
import java.nio.file.*;
import java.security.*;
import java.util.*;
import java.util.function.Consumer;
import java.util.zip.*;

/**
 * Imports Modrinth .mrpack files and ordinary ZIPs into an isolated per-version
 * Winter instance. Existing files are preserved by choosing a non-conflicting
 * destination name rather than silently replacing them.
 */
final class ModpackInstaller {
    private static final long MAX_ARCHIVE_BYTES = 512L * 1024L * 1024L;
    private static final long MAX_FILE_BYTES = 128L * 1024L * 1024L;
    private static final int MAX_ENTRIES = 10000;
    private final File gameDir;

    ModpackInstaller(File gameDir) { this.gameDir = gameDir.getAbsoluteFile(); }

    File importModpack(File archive, String versionId, Consumer<String> progress) throws Exception {
        if (archive == null || !archive.isFile() || !archive.canRead()) throw new IOException("Choose a readable .mrpack or .zip file.");
        if (versionId == null || !versionId.matches("[A-Za-z0-9._-]{1,120}")) throw new IOException("Invalid Minecraft version selection.");
        if (archive.length() > MAX_ARCHIVE_BYTES) throw new IOException("The modpack archive exceeds the 512 MB safety limit.");

        File profileJson = new File(new File(gameDir, "versions/" + versionId), versionId + ".json");
        if (!profileJson.isFile()) throw new IOException("The selected Minecraft version is not installed.");

        boolean legacyFabricProfile = versionId.startsWith("fabric-loader-") && versionId.endsWith("-26.3");
        String instanceId = legacyFabricProfile ? "26.3-fabric" : versionId;
        File instance = safe(new File(gameDir, "instances/" + instanceId).getPath());
        if (!instance.isDirectory() && !instance.mkdirs()) throw new IOException("Could not create the isolated instance directory: " + instance);        String lower = archive.getName().toLowerCase(Locale.ROOT);
        if (lower.endsWith(".mrpack")) importMrpack(archive, instance, versionId, progress);
        else if (lower.endsWith(".zip")) importZip(archive, instance, progress);
        else throw new IOException("Unsupported file type. Choose a Modrinth .mrpack or .zip archive.");
        File marker = new File(instance, ".winter-modpack-instance");
        if (!marker.exists()) Files.write(marker.toPath(), ("Winter Client modpack instance for " + versionId + "\n").getBytes("UTF-8"));
        progress.accept("Modpack imported into " + instance.getAbsolutePath());
        return instance;
    }

    private void importMrpack(File archive, File instance, String versionId, Consumer<String> progress) throws Exception {
        ZipFile zip = new ZipFile(archive);
        try {
            ZipEntry manifestEntry = zip.getEntry("modrinth.index.json");
            if (manifestEntry == null) throw new IOException("This .mrpack does not contain modrinth.index.json. Only Modrinth-format .mrpack files are supported.");
            String manifestText = readText(zip.getInputStream(manifestEntry), 2 * 1024 * 1024);
            Map<String,Object> manifest = asMap(new Launcher.Json(manifestText).parse());
            Map<String,Object> dependencies = asMap(manifest.get("dependencies"));
            String requiredMinecraft = string(dependencies.get("minecraft"));
            if (requiredMinecraft != null && !matchesMinecraftVersion(versionId, requiredMinecraft))
                throw new IOException("This modpack requires Minecraft " + requiredMinecraft + " but you selected " + versionId + ". Select the matching installed version first.");
            if (dependencies.containsKey("fabric-loader") && !versionId.toLowerCase(Locale.ROOT).contains("fabric"))
                throw new IOException("This modpack requires Fabric Loader " + dependencies.get("fabric-loader") + ". Install the matching Fabric profile first.");
            if (dependencies.containsKey("forge") && !versionId.toLowerCase(Locale.ROOT).contains("forge"))
                throw new IOException("This modpack requires Forge " + dependencies.get("forge") + ". Install the matching Forge profile first.");
            if (dependencies.containsKey("neoforge") || dependencies.containsKey("quilt-loader"))
                throw new IOException("This modpack requires NeoForge or Quilt. Winter Launcher currently imports files only; install a compatible loader separately before importing.");

            Object filesValue = manifest.get("files");
            if (!(filesValue instanceof List)) throw new IOException("Modrinth modpack manifest has no files list.");
            int total = ((List<?>)filesValue).size(), count = 0;
            for (Object item : (List<?>)filesValue) {
                Map<String,Object> file = asMap(item);
                String path = safeRelative(string(file.get("path")));
                if (path == null || !path.startsWith("mods/")) continue;
                if ("unsupported".equals(string(asMap(file.get("env")).get("client")))) continue;
                String url = string(file.get("downloads") instanceof List && !((List<?>)file.get("downloads")).isEmpty()
                        ? ((List<?>)file.get("downloads")).get(0) : null);                if (url == null || !url.startsWith("https://")) throw new IOException("Modpack contains a missing or non-HTTPS download URL for " + path);
                Map<String,Object> hashes = asMap(file.get("hashes"));
                String sha1 = string(hashes.get("sha1"));
                String sha512 = string(hashes.get("sha512"));
                if (sha1 == null && sha512 == null) throw new IOException("No checksum provided for modpack file " + path);
                File target = destination(instance, path);
                progress.accept("Downloading mod " + (++count) + "/" + total + ": " + new File(path).getName());
                downloadVerified(url, target, sha1, sha512);
            }

            ZipEntry overrides = zip.getEntry("overrides/");
            if (overrides != null) progress.accept("Applying modpack configuration and resource overrides…");
            Enumeration<? extends ZipEntry> entries = zip.entries();
            int seen = 0;
            while (entries.hasMoreElements()) {
                ZipEntry entry = entries.nextElement();
                if (++seen > MAX_ENTRIES) throw new IOException("Modpack contains too many archive entries.");
                String name = entry.getName();
                if (!name.startsWith("overrides/") || entry.isDirectory()) continue;
                String relative = safeRelative(name.substring("overrides/".length()));
                if (relative == null || !allowedPath(relative)) continue;
                if (entry.getSize() > MAX_FILE_BYTES) throw new IOException("Modpack override is too large: " + relative);
                File target = destination(instance, relative);
                copyLimited(zip.getInputStream(entry), target, MAX_FILE_BYTES);
            }
        } finally { zip.close(); }
    }

    private void importZip(File archive, File instance, Consumer<String> progress) throws Exception {
        ZipFile zip = new ZipFile(archive);
        try {
            Enumeration<? extends ZipEntry> entries = zip.entries();
            int count = 0, imported = 0;
            long totalBytes = 0;
            while (entries.hasMoreElements()) {
                ZipEntry entry = entries.nextElement();
                if (++count > MAX_ENTRIES) throw new IOException("ZIP contains too many entries.");
                if (entry.isDirectory()) continue;
                String name = safeRelative(entry.getName());
                if (name == null) continue;
                // Support common exported layouts with an optional single wrapper folder.
                String relative = stripWrapper(name);
                if (!allowedPath(relative)) continue;
                long size = entry.getSize();
                if (size > MAX_FILE_BYTES) throw new IOException("ZIP entry is too large: " + name);
                if (size > 0) totalBytes += size;
                if (totalBytes > MAX_ARCHIVE_BYTES) throw new IOException("ZIP expands beyond the 512 MB safety limit.");
                File target = destination(instance, relative);
                copyLimited(zip.getInputStream(entry), target, MAX_FILE_BYTES);
                imported++;
            }
            if (imported == 0) {
                if (zip.getEntry("manifest.json") != null)
                    throw new IOException("This appears to be a CurseForge export. CurseForge manifest downloads are not supported yet; export the pack as a Modrinth .mrpack or use a ZIP containing mods/, config/, resourcepacks/ or shaderpacks/.");
                throw new IOException("No supported files found. ZIPs must contain mods/, config/, resourcepacks/ or shaderpacks/ folders.");
            }
            progress.accept("Imported " + imported + " supported files from ZIP.");
        } finally { zip.close(); }
    }

    private boolean matchesMinecraftVersion(String profileId, String required) {
        if (profileId.equals(required)) return true;
        String lower = profileId.toLowerCase(Locale.ROOT);
        return lower.endsWith("-" + required.toLowerCase(Locale.ROOT))
                || lower.contains("forge-" + required.toLowerCase(Locale.ROOT))
                || lower.contains("fabric-") && lower.endsWith("-" + required.toLowerCase(Locale.ROOT));
    }

    private String stripWrapper(String path) {
        String[] parts = path.split("/");
        if (parts.length > 1 && !allowedRoot(parts[0])) return path.substring(parts[0].length() + 1);
        return path;
    }

    private boolean allowedPath(String path) {
        String first = path.contains("/") ? path.substring(0, path.indexOf('/')) : path;
        return allowedRoot(first) && !path.equals("mods") && !path.equals("config")
                && !path.equals("resourcepacks") && !path.equals("shaderpacks");
    }
    private boolean allowedRoot(String root) {
        return "mods".equals(root) || "config".equals(root) || "resourcepacks".equals(root)
                || "shaderpacks".equals(root);
    }

    private File destination(File instance, String relative) throws IOException {
        File target = new File(instance, relative).getCanonicalFile();
        String base = instance.getCanonicalPath() + File.separator;
        if (!target.getPath().startsWith(base)) throw new IOException("Refusing archive path outside the instance: " + relative);
        if (target.exists()) {
            String name = target.getName(), parent = target.getParent();
            int dot = name.lastIndexOf('.');
            String stem = dot > 0 ? name.substring(0, dot) : name;
            String ext = dot > 0 ? name.substring(dot) : "";
            int suffix = 1;
            do { target = new File(parent, stem + ".modpack-" + suffix++ + ext); } while (target.exists());
        }
        return target;
    }

    private void downloadVerified(String url, File target, String sha1, String sha512) throws Exception {
        URLConnection connection = new URL(url).openConnection();
        connection.setConnectTimeout(15000); connection.setReadTimeout(30000);
        File temp = new File(target.getPath() + ".part");
        copyLimited(connection.getInputStream(), temp, MAX_FILE_BYTES);
        if (sha1 != null && !digest(temp, "SHA-1").equalsIgnoreCase(sha1)
                || sha512 != null && !digest(temp, "SHA-512").equalsIgnoreCase(sha512)) {
            temp.delete(); throw new IOException("Checksum verification failed for " + target.getName());
        }
        move(temp, target);
    }

    private void copyLimited(InputStream input, File target, long limit) throws Exception {
        File parent = target.getParentFile();
        if (parent != null && !parent.isDirectory() && !parent.mkdirs()) throw new IOException("Could not create folder: " + parent);
        long copied = 0;
        try (InputStream in = input; OutputStream out = new BufferedOutputStream(new FileOutputStream(target))) {
            byte[] buffer = new byte[32768]; int n;
            while ((n = in.read(buffer)) != -1) {
                copied += n; if (copied > limit) throw new IOException("File exceeds the extraction size limit: " + target.getName());
                out.write(buffer, 0, n);
            }
        } catch (Exception ex) { target.delete(); throw ex; }
    }

    private String readText(InputStream input, int limit) throws Exception {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        try (InputStream in = input) {
            byte[] b = new byte[8192]; int n;
            while ((n = in.read(b)) != -1) { if (out.size() + n > limit) throw new IOException("Modpack manifest is too large."); out.write(b, 0, n); }
        }
        return new String(out.toByteArray(), "UTF-8");
    }

    private String safeRelative(String raw) {
        if (raw == null || raw.trim().isEmpty() || raw.startsWith("/") || raw.indexOf('\\') >= 0
                || raw.matches("^[A-Za-z]:.*")) return null;
        String path = raw.replace('\\', '/');
        for (String part : path.split("/")) if ("..".equals(part) || ".".equals(part)) return null;
        return path;
    }

    private String digest(File file, String algorithm) throws Exception {
        MessageDigest digest = MessageDigest.getInstance(algorithm);
        try (InputStream in = new FileInputStream(file)) {
            byte[] b = new byte[32768]; int n; while ((n = in.read(b)) != -1) digest.update(b, 0, n);
        }
        StringBuilder out = new StringBuilder();
        for (byte b : digest.digest()) out.append(String.format("%02x", b & 255));
        return out.toString();
    }

    private void move(File source, File target) throws IOException {
        File parent = target.getParentFile(); if (parent != null && !parent.isDirectory()) parent.mkdirs();
        try { Files.move(source.toPath(), target.toPath(), StandardCopyOption.ATOMIC_MOVE); }
        catch (AtomicMoveNotSupportedException ex) { Files.move(source.toPath(), target.toPath()); }
    }

    private File safe(String path) throws IOException {
        File file = new File(path).getCanonicalFile();
        String base = gameDir.getCanonicalPath() + File.separator;
        if (!file.getPath().startsWith(base)) throw new IOException("Refusing path outside Minecraft game directory: " + path);
        return file;
    }

    @SuppressWarnings("unchecked") private static Map<String,Object> asMap(Object value) {
        return value instanceof Map ? (Map<String,Object>)value : Collections.<String,Object>emptyMap();
    }
    private static String string(Object value) { return value instanceof String ? (String)value : null; }
}
