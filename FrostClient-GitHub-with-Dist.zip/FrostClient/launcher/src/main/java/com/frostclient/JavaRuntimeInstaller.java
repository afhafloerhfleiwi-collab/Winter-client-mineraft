package com.frostclient;

import java.io.*;
import java.net.*;
import java.nio.file.*;
import java.util.function.Consumer;

/** Installs Eclipse Temurin JDK builds into the current user's macOS JVM directory. */
final class JavaRuntimeInstaller {
    private JavaRuntimeInstaller() {}

    static File install(int major, Consumer<String> progress) throws Exception {
        String os = System.getProperty("os.name").toLowerCase(java.util.Locale.ROOT);
        if (!os.contains("mac")) throw new IOException("Automatic Java installation is currently supported on macOS only.");
        String arch = System.getProperty("os.arch").toLowerCase(java.util.Locale.ROOT);
        String platform = (arch.contains("aarch64") || arch.contains("arm64")) ? "aarch64" : "x64";
        String url = "https://api.adoptium.net/v3/binary/latest/" + major
                + "/ga/mac/" + platform + "/jdk/hotspot/normal/eclipse";
        File vmRoot = new File(System.getProperty("user.home"), "Library/Java/JavaVirtualMachines");
        if (!vmRoot.isDirectory() && !vmRoot.mkdirs()) throw new IOException("Cannot create " + vmRoot);
        File destination = new File(vmRoot, "temurin-" + major + ".jdk");
        File tempRoot = Files.createTempDirectory("winter-java-" + major + "-").toFile();
        File archive = new File(tempRoot, "temurin.tar.gz");
        File extracted = new File(tempRoot, "extracted");
        if (!extracted.mkdirs()) throw new IOException("Cannot create temporary extraction directory.");
        try {
            progress.accept("Downloading Temurin Java " + major + " (" + platform + ")…");
            URLConnection connection = new URL(url).openConnection();
            connection.setConnectTimeout(20000);
            connection.setReadTimeout(60000);
            connection.setRequestProperty("User-Agent", "WinterClient/1.0");
            try (InputStream in = connection.getInputStream(); OutputStream out = new FileOutputStream(archive)) {
                byte[] buffer = new byte[65536];
                int count;
                while ((count = in.read(buffer)) != -1) out.write(buffer, 0, count);
            }
            if (!archive.isFile() || archive.length() < 1024 * 1024)
                throw new IOException("The Java download was incomplete or invalid.");
            progress.accept("Extracting Java " + major + "…");
            Process process = new ProcessBuilder("/usr/bin/tar", "-xzf", archive.getAbsolutePath(), "-C", extracted.getAbsolutePath())
                    .redirectErrorStream(true).start();
            StringBuilder output = new StringBuilder();
            try (BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream(), "UTF-8"))) {
                String line;
                while ((line = reader.readLine()) != null) output.append(line).append('\n');
            }
            int exit = process.waitFor();
            if (exit != 0) throw new IOException("Could not extract Java archive: " + output.toString().trim());
            File bundle = findBundle(extracted);
            if (bundle == null) throw new IOException("Downloaded archive does not contain a macOS JDK bundle.");
            File java = new File(bundle, "Contents/Home/bin/java");
            if (!java.isFile()) throw new IOException("Downloaded JDK is missing its Java executable.");
            if (destination.exists()) deleteTree(destination.toPath());
            Files.move(bundle.toPath(), destination.toPath(), StandardCopyOption.REPLACE_EXISTING);
            File installedJava = new File(destination, "Contents/Home/bin/java");
            if (!installedJava.setExecutable(true, false) && !installedJava.canExecute())
                throw new IOException("Java installed, but its executable permission could not be set.");
            progress.accept("Java " + major + " installed. Auto detection can now find it.");
            return installedJava;
        } finally {
            deleteTree(tempRoot.toPath());
        }
    }

    private static File findBundle(File root) {
        File[] children = root.listFiles();
        if (children == null) return null;
        for (File child : children) {
            if (child.isDirectory() && new File(child, "Contents/Home/bin/java").isFile()) return child;
        }
        return null;
    }

    private static void deleteTree(Path path) throws IOException {
        if (!Files.exists(path)) return;
        try (java.util.stream.Stream<Path> stream = Files.walk(path)) {
            Path[] paths = stream.sorted(java.util.Comparator.reverseOrder()).toArray(Path[]::new);
            for (Path item : paths) Files.deleteIfExists(item);
        }
    }
}
