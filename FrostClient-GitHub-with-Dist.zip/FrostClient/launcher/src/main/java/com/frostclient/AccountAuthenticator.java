package com.frostclient;

import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.security.MessageDigest;
import java.util.*;
import java.util.jar.JarFile;
import javax.swing.*;

/** Network authentication helpers. Passwords remain transient; refreshable session tokens are stored in macOS Keychain by CredentialVault. */
final class AccountAuthenticator {
    static final String MICROSOFT_CLIENT_ID = "00000000402b5328";
    static final String DEFAULT_LITTLESKIN = "https://littleskin.cn/api/yggdrasil";

    static final class Profile {
        final String id, name;
        Profile(String id, String name) { this.id=id; this.name=name; }
        public String toString() { return name; }
    }

    static final class Session {
        final String type, clientToken, apiRoot;
        String accessToken, refreshToken;
        final List<Profile> profiles;
        Profile profile;
        Session(String type, String token, String refresh, String client, String root, List<Profile> profiles, Profile selected) {
            this.type=type; this.accessToken=token; this.refreshToken=refresh; this.clientToken=client; this.apiRoot=root;
            this.profiles=profiles; this.profile=selected;
        }
    }
    private AccountAuthenticator() {}

    static String microsoftAuthorizationUrl() {
        try {
            return "https://login.live.com/oauth20_authorize.srf?client_id="+enc(MICROSOFT_CLIENT_ID)
                +"&response_type=code&redirect_uri="+enc("https://login.live.com/oauth20_desktop.srf")
                +"&scope="+enc("service::user.auth.xboxlive.com::MBI_SSL")
                +"&display=touch&prompt=select_account";
        } catch(Exception e) { throw new IllegalStateException(e); }
    }

    static Session microsoftFromRedirect(String redirect) throws Exception {
        String code = null;
        String query = redirect.trim();
        int q=query.indexOf('?'); if(q>=0) query=query.substring(q+1);
        int hash=query.indexOf('#'); if(hash>=0) query=query.substring(0,hash);
        for(String pair:query.split("&")) {
            int p=pair.indexOf('=');
            if(p>0 && "code".equals(URLDecoder.decode(pair.substring(0,p),"UTF-8"))) { code=URLDecoder.decode(pair.substring(p+1),"UTF-8"); break; }
            if(p>0 && "error".equals(pair.substring(0,p))) throw new IOException("Microsoft sign-in failed: "+URLDecoder.decode(pair.substring(p+1),"UTF-8"));
        }
        if(code==null || code.isEmpty()) throw new IOException("The pasted Microsoft redirect URL did not contain an authorization code.");
        Map<String,Object> oauth=form("https://login.live.com/oauth20_token.srf","client_id",MICROSOFT_CLIENT_ID,"code",code,
            "grant_type","authorization_code","redirect_uri","https://login.live.com/oauth20_desktop.srf",
            "scope","service::user.auth.xboxlive.com::MBI_SSL");
        String msa=string(oauth.get("access_token")), refresh=string(oauth.get("refresh_token"));
        if(msa==null) throw apiError("Microsoft OAuth",oauth);
        return microsoftMinecraftSession(msa,refresh);
    }

    static Session refreshMicrosoft(String refreshToken) throws Exception {
        Map<String,Object> oauth=form("https://login.live.com/oauth20_token.srf","client_id",MICROSOFT_CLIENT_ID,
            "refresh_token",refreshToken,"grant_type","refresh_token","scope","service::user.auth.xboxlive.com::MBI_SSL");
        String msa=string(oauth.get("access_token")), nextRefresh=string(oauth.get("refresh_token"));
        if(msa==null) throw apiError("Microsoft token refresh",oauth);
        return microsoftMinecraftSession(msa,nextRefresh==null?refreshToken:nextRefresh);
    }

    private static Session microsoftMinecraftSession(String msa,String refresh) throws Exception {
        Map<String,Object> xblBody=map("Properties",map("AuthMethod","RPS","SiteName","user.auth.xboxlive.com","RpsTicket","d="+msa),
            "RelyingParty","http://auth.xboxlive.com","TokenType","JWT");
        Map<String,Object> xbl=post("https://user.auth.xboxlive.com/user/authenticate",xblBody,null);
        String xblToken=string(xbl.get("Token")); List<Object> xui=list(asMap(xbl.get("DisplayClaims")).get("xui"));
        if(xblToken==null||xui.isEmpty()) throw apiError("Xbox Live",xbl);
        String uhs=string(asMap(xui.get(0)).get("uhs")); if(uhs==null) throw new IOException("Xbox Live did not return a user hash.");
        Map<String,Object> xsts=post("https://xsts.auth.xboxlive.com/xsts/authorize",map("Properties",map("SandboxId","RETAIL","UserTokens",Arrays.asList(xblToken)),"RelyingParty","rp://api.minecraftservices.com/","TokenType","JWT"),null);
        String xstsToken=string(xsts.get("Token"));
        if(xstsToken==null) { Object xerr=xsts.get("XErr"); throw new IOException("Xbox security check failed"+(xerr==null?"":" (code "+xerr+")")+". Check Xbox profile, family settings and regional availability."); }
        Map<String,Object> mc=post("https://api.minecraftservices.com/authentication/login_with_xbox",map("identityToken","XBL3.0 x="+uhs+";"+xstsToken),null);
        String mcToken=string(mc.get("access_token")); if(mcToken==null) throw apiError("Minecraft Services login",mc);
        Map<String,Object> ent=get("https://api.minecraftservices.com/entitlements/mcstore",mcToken); boolean owns=false;
        for(Object item:list(ent.get("items"))) { String n=string(asMap(item).get("name")); if("game_minecraft".equals(n)||"product_minecraft".equals(n)) owns=true; }
        if(!owns) throw new IOException("This Microsoft account does not have Minecraft: Java Edition entitlement (including eligible Game Pass access).");
        Map<String,Object> profile=get("https://api.minecraftservices.com/minecraft/profile",mcToken);
        String id=string(profile.get("id")),name=string(profile.get("name"));
        if(id==null||name==null) throw new IOException("Minecraft profile is missing. Create a Java Edition profile at minecraft.net and sign in again.");
        Profile p=new Profile(id,name); return new Session("Microsoft",mcToken,refresh,null,null,Collections.singletonList(p),p);
    }
    static Session littleSkin(String apiRoot, String email, char[] password) throws Exception {
        String root=apiRoot.trim(); while(root.endsWith("/")) root=root.substring(0,root.length()-1);
        URL u=new URL(root); if(!"https".equalsIgnoreCase(u.getProtocol())) throw new IOException("LittleSkin authentication requires HTTPS.");
        Map<String,Object> metadata=get(root,null); if(metadata.isEmpty()) throw new IOException("LittleSkin returned empty Yggdrasil metadata.");
        String client=UUID.randomUUID().toString().replace("-","");
        Map<String,Object> response=post(root+"/authserver/authenticate",map("agent",map("name","Minecraft","version",1),"username",email,"password",new String(password),"clientToken",client,"requestUser",Boolean.TRUE),null);
        String token=string(response.get("accessToken")); if(token==null) throw apiError("LittleSkin sign-in",response);
        List<Profile> profiles=new ArrayList<Profile>();
        for(Object o:list(response.get("availableProfiles"))) { Map<String,Object> p=asMap(o); String id=string(p.get("id")),name=string(p.get("name")); if(id!=null&&name!=null)profiles.add(new Profile(id,name)); }
        Map<String,Object> selected=asMap(response.get("selectedProfile")); String sid=string(selected.get("id")),sname=string(selected.get("name"));
        Profile chosen=sid!=null&&sname!=null?new Profile(sid,sname):null;
        return new Session("LittleSkin",token,null,client,root,profiles,chosen);
    }

    static Session refreshLittleSkin(String apiRoot,String accessToken,String clientToken,Profile profile) throws Exception {
        Map<String,Object> body=map("accessToken",accessToken,"clientToken",clientToken,"requestUser",Boolean.TRUE);
        if(profile!=null) body.put("selectedProfile",map("id",profile.id,"name",profile.name));
        Map<String,Object> result=post(apiRoot+"/authserver/refresh",body,null);
        String next=string(result.get("accessToken")); if(next==null) throw apiError("LittleSkin token refresh",result);
        Map<String,Object> selected=asMap(result.get("selectedProfile"));
        String id=string(selected.get("id")),name=string(selected.get("name"));
        Profile chosen=id!=null&&name!=null?new Profile(id,name):profile;
        return new Session("LittleSkin",next,null,clientToken,apiRoot,Collections.singletonList(chosen),chosen);
    }

    static void selectLittleSkinProfile(Session session, Profile profile) throws Exception {
        Map<String,Object> result=post(session.apiRoot+"/authserver/refresh",map("accessToken",session.accessToken,"clientToken",session.clientToken,
            "selectedProfile",map("id",profile.id,"name",profile.name),"requestUser",Boolean.TRUE),null);
        if(string(result.get("accessToken"))==null) throw apiError("LittleSkin profile selection",result);
        session.accessToken=string(result.get("accessToken")); session.profile=profile;
    }
    static File ensureAuthlibInjector() throws Exception {
        File dir=new File(System.getProperty("user.home"),".frostclient");
        if(!dir.isDirectory() && !dir.mkdirs()) throw new IOException("Cannot create Winter Client cache directory: "+dir);        File jar=new File(dir,"authlib-injector.jar");
        if(jar.isFile() && validJar(jar)) return jar;
        Map<String,Object> release=get("https://authlib-injector.yushi.moe/artifact/latest.json",null);
        String download=string(release.get("download_url"));
        String expected=string(asMap(release.get("checksums")).get("sha256"));
        if(download==null || expected==null) throw new IOException("Official authlib-injector release API did not provide a download URL and SHA-256 checksum.");
        URL url=new URL(download);
        if(!"https".equalsIgnoreCase(url.getProtocol())) throw new IOException("Refusing a non-HTTPS authlib-injector download.");
        HttpURLConnection c=(HttpURLConnection)url.openConnection();
        c.setConnectTimeout(15000); c.setReadTimeout(30000); c.setInstanceFollowRedirects(true);
        c.setRequestProperty("User-Agent","WinterClient/1.0");        int code=c.getResponseCode();
        if(code<200||code>=300) throw new IOException("authlib-injector download failed (HTTP "+code+").");
        File tmp=new File(dir,"authlib-injector.jar.tmp");
        InputStream in=c.getInputStream(); FileOutputStream out=new FileOutputStream(tmp);
        try { byte[] b=new byte[8192]; int n; while((n=in.read(b))!=-1) out.write(b,0,n); }
        finally { try{in.close();}finally{out.close();c.disconnect();} }
        if(!validJar(tmp)) { tmp.delete(); throw new IOException("Downloaded authlib-injector file was not a valid JAR."); }
        String actual=sha256(tmp);
        if(!expected.equalsIgnoreCase(actual)) { tmp.delete(); throw new IOException("authlib-injector SHA-256 verification failed; download was discarded."); }
        if(jar.exists()) jar.delete();
        if(!tmp.renameTo(jar)) throw new IOException("Could not cache authlib-injector at "+jar);
        return jar;
    }

    private static String sha256(File f) throws Exception {
        MessageDigest digest=MessageDigest.getInstance("SHA-256"); InputStream in=new FileInputStream(f);
        try { byte[] b=new byte[8192]; int n; while((n=in.read(b))!=-1) digest.update(b,0,n); } finally { in.close(); }
        StringBuilder out=new StringBuilder(); for(byte b:digest.digest()) out.append(String.format(Locale.ROOT,"%02x",b&255)); return out.toString();
    }
    static String littleSkinPrefetchedMetadata(String root) throws Exception {
        Map<String,Object> meta=get(root,null);
        String json=toJson(meta);
        return Base64.getEncoder().encodeToString(json.getBytes(StandardCharsets.UTF_8));
    }

    private static boolean validJar(File f) {
        if(!f.isFile()||f.length()<10000) return false;
        try { JarFile j=new JarFile(f); boolean ok=j.getManifest()!=null; j.close(); return ok; }
        catch(Exception e) { return false; }
    }

    private static Map<String,Object> get(String url,String bearer) throws Exception { return request("GET",url,null,bearer); }
    private static Map<String,Object> post(String url,Map<String,Object> body,String bearer) throws Exception { return request("POST",url,toJson(body),bearer); }
    private static Map<String,Object> form(String url,String... pairs) throws Exception {
        StringBuilder b=new StringBuilder();
        for(int i=0;i<pairs.length;i+=2) { if(b.length()>0)b.append('&'); b.append(enc(pairs[i])).append('=').append(enc(pairs[i+1])); }
        HttpURLConnection c=(HttpURLConnection)new URL(url).openConnection();
        c.setConnectTimeout(15000); c.setReadTimeout(30000); c.setRequestMethod("POST"); c.setDoOutput(true);
        c.setRequestProperty("Content-Type","application/x-www-form-urlencoded"); c.setRequestProperty("Accept","application/json");
        byte[] data=b.toString().getBytes(StandardCharsets.UTF_8); c.setFixedLengthStreamingMode(data.length);
        OutputStream out=c.getOutputStream(); out.write(data); out.close();
        return readResponse(c);
    }
    private static Map<String,Object> request(String method,String url,String body,String bearer) throws Exception {
        HttpURLConnection c=(HttpURLConnection)new URL(url).openConnection();
        c.setConnectTimeout(15000); c.setReadTimeout(30000); c.setRequestMethod(method); c.setRequestProperty("Accept","application/json");
        if(bearer!=null)c.setRequestProperty("Authorization","Bearer "+bearer);
        if(body!=null) { c.setDoOutput(true); c.setRequestProperty("Content-Type","application/json; charset=utf-8"); byte[] d=body.getBytes(StandardCharsets.UTF_8); c.setFixedLengthStreamingMode(d.length); OutputStream o=c.getOutputStream();o.write(d);o.close(); }
        return readResponse(c);
    }
    private static Map<String,Object> readResponse(HttpURLConnection c) throws Exception {
        int code=c.getResponseCode(); InputStream in=code>=200&&code<300?c.getInputStream():c.getErrorStream();
        StringBuilder b=new StringBuilder();
        if(in!=null) { BufferedReader r=new BufferedReader(new InputStreamReader(in,StandardCharsets.UTF_8)); String line; while((line=r.readLine())!=null)b.append(line);r.close(); }
        c.disconnect();
        Object parsed;
        try { parsed=new Launcher.Json(b.toString()).parse(); } catch(Exception e) { throw new IOException("Authentication server returned HTTP "+code+" with an unreadable response."); }
        Map<String,Object> result=asMap(parsed);
        if(code<200||code>=300) throw apiError("HTTP "+code,result);
        return result;
    }
    private static IOException apiError(String label,Map<String,Object> data) {
        String desc=string(data.get("errorMessage")); if(desc==null)desc=string(data.get("error_description"));
        if(desc==null)desc=string(data.get("message")); if(desc==null)desc=string(data.get("error")); if(desc==null && data.get("XErr")!=null)desc="Xbox error code "+data.get("XErr");
        return new IOException(label+" failed"+(desc==null?".":": "+desc));
    }
    private static String enc(String s) throws Exception { return URLEncoder.encode(s,"UTF-8"); }
    private static String string(Object o) { return o instanceof String?(String)o:null; }
    @SuppressWarnings("unchecked") private static Map<String,Object> asMap(Object o) { return o instanceof Map?(Map<String,Object>)o:Collections.<String,Object>emptyMap(); }
    @SuppressWarnings("unchecked") private static List<Object> list(Object o) { return o instanceof List?(List<Object>)o:Collections.<Object>emptyList(); }
    private static Map<String,Object> map(Object... a) { Map<String,Object> m=new LinkedHashMap<String,Object>(); for(int i=0;i<a.length;i+=2)m.put(String.valueOf(a[i]),a[i+1]); return m; }
    private static String toJson(Object o) {
        if(o==null)return "null";
        if(o instanceof String)return "\""+((String)o).replace("\\","\\\\").replace("\"","\\\"").replace("\n","\\n").replace("\r","\\r")+"\"";
        if(o instanceof Number||o instanceof Boolean)return String.valueOf(o);
        if(o instanceof Map) { StringBuilder b=new StringBuilder("{"); for(Object k:((Map<?,?>)o).keySet()){if(b.length()>1)b.append(',');b.append(toJson(String.valueOf(k))).append(':').append(toJson(((Map<?,?>)o).get(k)));}return b.append('}').toString(); }
        if(o instanceof Iterable) { StringBuilder b=new StringBuilder("[");for(Object v:(Iterable<?>)o){if(b.length()>1)b.append(',');b.append(toJson(v));}return b.append(']').toString(); }
        return toJson(String.valueOf(o));
    }
}