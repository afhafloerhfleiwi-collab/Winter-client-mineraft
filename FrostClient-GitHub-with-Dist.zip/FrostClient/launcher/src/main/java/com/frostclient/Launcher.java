package com.frostclient;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.List;

/** Winter Client's original lightweight Minecraft launcher. */
public final class Launcher {
    private final JFrame frame = new JFrame("Winter Client");
    private final JComboBox<String> profile = new JComboBox<String>();
    private final JTextField username = new JTextField("Player", 16);
    private final JTextField javaPath = new JTextField(defaultJava(), 28);
    private final JComboBox<String> javaMode = new JComboBox<String>(new String[] {"Automatic (match Minecraft)", "Manual (use selected executable)"});
    private final JLabel javaRequirement = new JLabel("Auto: Java 8 for Minecraft 1.8.9");
    private final JTextField gameDir = new JTextField(defaultGameDir(), 28);
    private final JSpinner memory = new JSpinner(new SpinnerNumberModel(2048, 512, 6144, 256));
    private final JLabel status = new JLabel("Ready");
    private final JProgressBar downloadProgress = new JProgressBar();
    private final DefaultListModel<String> installedModel = new DefaultListModel<String>();
    private final JList<String> installedVersions = new JList<String>(installedModel);
    private final JComboBox<String> loaderBaseVersions = new JComboBox<String>();
    private final Properties settings = new Properties();    private final JComboBox<String> accountType = new JComboBox<String>(new String[] {"Offline / Cracked", "Microsoft", "LittleSkin"});
    private final JTextField accountUsername = new JTextField("Player", 20);
    private final JTextField littleSkinServer = new JTextField("https://littleskin.cn/api/yggdrasil", 32);
    private final DefaultListModel<String> accountModel = new DefaultListModel<String>();
    private final JList<String> accountList = new JList<String>(accountModel);
    private String selectedAccountType = "Offline / Cracked";
    private String selectedAccountName = "Player";
    private AccountAuthenticator.Session authenticatedSession;
    private boolean restoringSession=false;

    private final File settingsFile = new File(System.getProperty("user.home"), ".frostclient/launcher.properties");

    public static void main(String[] args) { SwingUtilities.invokeLater(new Runnable() { public void run() { new Launcher().show(); } }); }
    private Launcher() {
        loadSettings();
        javaMode.setSelectedIndex("manual".equalsIgnoreCase(settings.getProperty("javaMode", "auto")) ? 1 : 0);
        javaPath.setText(settings.getProperty("java", defaultJava()));
        javaPath.setEnabled(javaMode.getSelectedIndex()==1);
        javaMode.addActionListener(e -> javaPath.setEnabled(javaMode.getSelectedIndex()==1));
        javaRequirement.setForeground(new Color(147,164,188));
        username.setText(settings.getProperty("username", "Player"));
        gameDir.setText(normalizeGameDirectory(settings.getProperty("gameDir", defaultGameDir())));        memory.setValue(Integer.valueOf(settings.getProperty("memory", "2048")));
        refreshProfiles();
        ListCellRenderer<? super String> versionNameRenderer = new DefaultListCellRenderer() {
            public Component getListCellRendererComponent(JList<?> list, Object value, int index, boolean selected, boolean focus) {
                super.getListCellRendererComponent(list, value, index, selected, focus);
                if (value != null) setText(versionDisplayLabel(String.valueOf(value)));
                return this;
            }
        };
        profile.setRenderer(versionNameRenderer);
        installedVersions.setCellRenderer(versionNameRenderer);
        loaderBaseVersions.setRenderer(versionNameRenderer);
    }    private void show() {
        frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);        frame.setMinimumSize(new Dimension(760, 570));
        JPanel root = new JPanel(new BorderLayout(18, 18));
        root.setBorder(new EmptyBorder(24, 28, 22, 28)); root.setBackground(new Color(18, 22, 31));
        JPanel top = new JPanel(new BorderLayout()); top.setOpaque(false);
        JLabel title = new JLabel("WINTER CLIENT"); title.setForeground(new Color(236,243,255)); title.setFont(new Font("SansSerif",Font.BOLD,28));
        JLabel subtitle = new JLabel("1.8.9  •  Lightweight PvP launcher"); subtitle.setForeground(new Color(147,164,188));        JPanel heading = new JPanel(new GridLayout(2,1,0,4)); heading.setOpaque(false); heading.add(title); heading.add(subtitle); top.add(heading);
        JButton refresh = button("Refresh profiles"); refresh.addActionListener(e -> refreshProfiles()); top.add(refresh,BorderLayout.EAST); root.add(top,BorderLayout.NORTH);

        JTabbedPane tabs = new JTabbedPane();
        tabs.setOpaque(true); tabs.setBackground(Color.WHITE); tabs.setForeground(new Color(28,38,55));
        tabs.setUI(new javax.swing.plaf.basic.BasicTabbedPaneUI() {
            protected void installDefaults() { super.installDefaults(); tabAreaInsets = new Insets(4,4,4,4); }
            protected void paintTabBackground(Graphics g, int tabPlacement, int tabIndex, int x, int y, int w, int h, boolean isSelected) {
                g.setColor(Color.WHITE); g.fillRect(x,y,w,h);
            }
            protected void paintText(Graphics g, int tabPlacement, Font font, FontMetrics metrics, int tabIndex, String title, Rectangle textRect, boolean isSelected) {
                g.setFont(font); g.setColor(new Color(28,38,55));
                g.drawString(title,textRect.x,textRect.y+metrics.getAscent());
            }
        });
        JPanel play = new JPanel(new GridBagLayout()); play.setOpaque(false); GridBagConstraints c = new GridBagConstraints();        c.insets=new Insets(10,4,10,4); c.fill=GridBagConstraints.HORIZONTAL; c.weightx=0; c.gridx=0; c.gridy=-1;
        addRow(play,c,"Minecraft profile",profile);
        addRow(play,c,"Player name (offline account only)",username);
        addRow(play,c,"Java selection",javaMode);
        addRow(play,c,"Java executable (manual mode)",javaPath);
        addRow(play,c,"Java requirement",javaRequirement);
        addRow(play,c,"Game directory",gameDir);
        addRow(play,c,"Memory (MB)",memory);
        JPanel paths=new JPanel(new FlowLayout(FlowLayout.LEFT,8,0)); paths.setOpaque(false);
        JButton chooseJava=button("Browse Java"); chooseJava.addActionListener(e->chooseFile(javaPath));
        JButton chooseDir=button("Browse folder"); chooseDir.addActionListener(e->{chooseDirectory(gameDir);refreshProfiles();});
        paths.add(chooseJava); paths.add(chooseDir);
        c.gridx=0; c.gridy++; c.gridwidth=2; c.weightx=1; c.fill=GridBagConstraints.HORIZONTAL; play.add(paths,c); c.gridwidth=1;
        JButton openDownloader=button("DOWNLOAD MINECRAFT VERSIONS");        openDownloader.setBackground(new Color(76,137,255)); openDownloader.setForeground(Color.WHITE);
        openDownloader.setFont(new Font("SansSerif",Font.BOLD,14));
        c.gridx=0; c.gridy++; c.gridwidth=2; c.weightx=1; c.fill=GridBagConstraints.HORIZONTAL;
        play.add(openDownloader,c); c.gridwidth=1;
        JScrollPane playScroll = new JScrollPane(play);
        playScroll.setBorder(BorderFactory.createEmptyBorder());
        playScroll.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        playScroll.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED);
        playScroll.getViewport().setOpaque(false); playScroll.setOpaque(false);
        tabs.addTab("Play",playScroll); tabs.addTab("Account Manager",buildAccountManager());        JButton openAccounts=button("MANAGE ACCOUNTS");
        openAccounts.setFont(new Font("SansSerif",Font.BOLD,14));
        c.gridx=0; c.gridy++; c.gridwidth=2; c.weightx=1; c.fill=GridBagConstraints.HORIZONTAL;
        play.add(openAccounts,c); c.gridwidth=1;
        openAccounts.addActionListener(e -> tabs.setSelectedIndex(1));

        tabs.addTab("Version Downloader",buildVersionManager());        openDownloader.addActionListener(e -> tabs.setSelectedIndex(2));

                root.add(tabs,BorderLayout.CENTER);

        JPanel bottom=new JPanel(new BorderLayout(10,12));bottom.setOpaque(false);
        JPanel actions=new JPanel(new FlowLayout(FlowLayout.LEFT,8,0));actions.setOpaque(false);
        JButton launch=button("LAUNCH GAME");launch.setBackground(new Color(76,137,255));launch.setForeground(Color.WHITE);launch.setFont(new Font("SansSerif",Font.BOLD,14));launch.addActionListener(e->launchGame());
        JButton mods=button("Open mods");mods.addActionListener(e->openSubfolder("mods"));
        JButton folder=button("Open game folder");folder.addActionListener(e->openPath(new File(gameDir.getText())));
        actions.add(launch);actions.add(mods);actions.add(folder);bottom.add(actions,BorderLayout.NORTH);
        status.setForeground(new Color(155,177,207));bottom.add(status,BorderLayout.SOUTH);root.add(bottom,BorderLayout.SOUTH);
        frame.setContentPane(root);frame.pack();frame.setLocationRelativeTo(null);frame.setVisible(true);
        restoreStoredSession();
    }


    private JPanel buildAccountManager() {
        JPanel content = new JPanel(); content.setOpaque(true); content.setBackground(Color.WHITE); content.setBorder(new EmptyBorder(22,22,22,22));
        content.setLayout(new BoxLayout(content, BoxLayout.Y_AXIS));
        JLabel heading = new JLabel("ACCOUNT MANAGER"); heading.setForeground(new Color(28,38,55)); heading.setFont(new Font("SansSerif",Font.BOLD,20));
        JLabel intro = new JLabel("Choose the account type used when launching Minecraft."); intro.setForeground(new Color(75,88,106));
        content.add(heading); content.add(Box.createVerticalStrut(6)); content.add(intro); content.add(Box.createVerticalStrut(18));
        addAccountRow(content, "Account type", accountType);
        addAccountRow(content, "Minecraft username / email", accountUsername);
        addAccountRow(content, "LittleSkin Yggdrasil API", littleSkinServer);
        JLabel help = new JLabel("<html>Microsoft: browser sign-in. LittleSkin: email + password. Passwords are never saved; session tokens are kept in macOS Keychain and refreshed on startup. Offline accounts only work on offline-mode servers.</html>");
        help.setForeground(new Color(75,88,106)); help.setMaximumSize(new Dimension(680,48)); content.add(Box.createVerticalStrut(8)); content.add(help); content.add(Box.createVerticalStrut(14));
        JPanel actions = new JPanel(new FlowLayout(FlowLayout.LEFT,8,0)); actions.setOpaque(false);
        JButton save = button("SAVE / SELECT ACCOUNT"); save.setBackground(new Color(76,137,255)); save.setForeground(Color.WHITE);
        JButton signIn = button("SIGN IN"); signIn.setBackground(new Color(40,125,82)); signIn.setForeground(Color.WHITE);
        JButton signOut = button("SIGN OUT");
        JButton remove = button("Remove selected"); actions.add(save); actions.add(signIn); actions.add(signOut); actions.add(remove); content.add(actions);
        JLabel listTitle = new JLabel("SAVED ACCOUNTS"); listTitle.setForeground(new Color(40,52,70)); listTitle.setFont(new Font("SansSerif",Font.BOLD,13));
        content.add(Box.createVerticalStrut(18)); content.add(listTitle);
        accountList.setVisibleRowCount(6); accountList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION); accountList.setBackground(Color.WHITE); accountList.setForeground(new Color(28,38,55));
        JScrollPane listScroll = new JScrollPane(accountList); listScroll.setPreferredSize(new Dimension(520,130)); listScroll.setMaximumSize(new Dimension(Integer.MAX_VALUE,145)); listScroll.getViewport().setBackground(Color.WHITE); listScroll.setBackground(Color.WHITE); content.add(listScroll);
        save.addActionListener(e -> saveAccount());
        signIn.addActionListener(e -> signInAccount());
        signOut.addActionListener(e -> { authenticatedSession=null; try{CredentialVault.clear();setStatus("Signed out and removed the saved Keychain session.");}catch(Exception ex){error("Could not clear saved session: "+rootMessage(ex));} });
        remove.addActionListener(e -> { int i=accountList.getSelectedIndex(); if(i>=0){accountModel.remove(i); persistAccounts();} });
        accountList.addListSelectionListener(e -> { if(!e.getValueIsAdjusting()){String v=accountList.getSelectedValue(); if(v!=null) loadAccount(v);} });
        loadAccounts();
        JScrollPane outer = new JScrollPane(content); outer.setBorder(BorderFactory.createEmptyBorder()); outer.getViewport().setOpaque(true); outer.getViewport().setBackground(Color.WHITE); outer.setOpaque(true); outer.setBackground(Color.WHITE);
        JPanel accountTab = wrapInPanel(outer); accountTab.setOpaque(true); accountTab.setBackground(Color.WHITE); return accountTab;
    }

    private void addAccountRow(JPanel panel, String label, JComponent component) {
        JPanel row = new JPanel(new BorderLayout(12,0)); row.setOpaque(false); row.setMaximumSize(new Dimension(Integer.MAX_VALUE,38));
        JLabel l = new JLabel(label); l.setForeground(new Color(45,58,76)); l.setPreferredSize(new Dimension(190,28));
        component.setFont(new Font("SansSerif",Font.PLAIN,13)); component.setBackground(Color.WHITE); component.setForeground(new Color(28,38,55)); row.add(l,BorderLayout.WEST); row.add(component,BorderLayout.CENTER);
        panel.add(row); panel.add(Box.createVerticalStrut(9));
    }
    private void saveAccount() {
        String type=String.valueOf(accountType.getSelectedItem()); String name=accountUsername.getText().trim();
        if(name.isEmpty()){error("Enter a Minecraft username or Microsoft email.");return;}
        if("Offline / Cracked".equals(type) && !name.matches("[A-Za-z0-9_]{1,16}")){error("Offline usernames must contain 1–16 letters, numbers or underscores.");return;}
        if("LittleSkin".equals(type)) {
            String server=littleSkinServer.getText().trim();
            if(!server.startsWith("https://")){error("LittleSkin authentication server must use HTTPS.");return;}
        }
        selectedAccountType=type; selectedAccountName=name; username.setText(name);
        String entry=type+" | "+name;
        if(!accountModel.contains(entry)) accountModel.addElement(entry);
        accountList.setSelectedValue(entry,true); persistAccounts();
        setStatus("Selected "+type+" account: "+name);
        authenticatedSession=null;
        if("Offline / Cracked".equals(type)) setStatus("Offline account selected. It only works on offline-mode servers.");
        else setStatus(type+" account saved. Press SIGN IN to authenticate before launching.");
    }

    private void signInAccount() {
        final String type=String.valueOf(accountType.getSelectedItem());
        final String account=accountUsername.getText().trim();
        if(account.isEmpty()){error("Enter the account email or identifier first.");return;}
        selectedAccountType=type; selectedAccountName=account; String accountEntry=type+" | "+account; if(!accountModel.contains(accountEntry))accountModel.addElement(accountEntry); persistAccounts();
        if("Microsoft".equals(type)) {
            try { Desktop.getDesktop().browse(new java.net.URI(AccountAuthenticator.microsoftAuthorizationUrl())); }
            catch(Exception ex){error("Could not open the Microsoft sign-in page: "+ex.getMessage());return;}
            String redirect=JOptionPane.showInputDialog(frame,"Complete Microsoft sign-in in your browser. When Microsoft redirects to login.live.com/oauth20_desktop.srf, copy the FULL address-bar URL and paste it here.\n\nIf the page says it cannot be reached, copy its address anyway.","Microsoft sign-in",JOptionPane.QUESTION_MESSAGE);
            if(redirect==null||redirect.trim().isEmpty())return;
            final String pasted=redirect.trim(); setStatus("Exchanging Microsoft authorization and checking Xbox/Minecraft access…");
            new SwingWorker<AccountAuthenticator.Session,Void>() {
                protected AccountAuthenticator.Session doInBackground() throws Exception { return AccountAuthenticator.microsoftFromRedirect(pasted); }
                protected void done(){try{applyAuthenticatedSession(get());}catch(Exception ex){error("Microsoft sign-in failed: "+rootMessage(ex));}}
            }.execute();
        } else if("LittleSkin".equals(type)) {
            final JPasswordField password=new JPasswordField(22);
            JPanel prompt=new JPanel(new GridLayout(2,1,4,4)); prompt.add(new JLabel("LittleSkin account password (not saved):")); prompt.add(password);
            if(JOptionPane.showConfirmDialog(frame,prompt,"LittleSkin sign-in",JOptionPane.OK_CANCEL_OPTION,JOptionPane.PLAIN_MESSAGE)!=JOptionPane.OK_OPTION)return;
            final char[] secret=password.getPassword(); final String root=littleSkinServer.getText().trim();
            setStatus("Authenticating with LittleSkin…");
            new SwingWorker<AccountAuthenticator.Session,Void>() {
                protected AccountAuthenticator.Session doInBackground() throws Exception { try{return AccountAuthenticator.littleSkin(root,account,secret);}finally{Arrays.fill(secret, (char)0);} }
                protected void done(){try{AccountAuthenticator.Session s=get(); if(s.profile==null){if(s.profiles.isEmpty())throw new IOException("LittleSkin account has no Minecraft player profile."); Object choice=s.profiles.size()==1?s.profiles.get(0):JOptionPane.showInputDialog(frame,"Choose the Minecraft profile to use:","LittleSkin profile",JOptionPane.PLAIN_MESSAGE,null,s.profiles.toArray(),s.profiles.get(0)); if(choice==null)return; final AccountAuthenticator.Profile p=(AccountAuthenticator.Profile)choice; setStatus("Selecting LittleSkin profile…"); new SwingWorker<AccountAuthenticator.Session,Void>(){protected AccountAuthenticator.Session doInBackground()throws Exception{AccountAuthenticator.selectLittleSkinProfile(s,p);return s;}protected void done(){try{applyAuthenticatedSession(get());}catch(Exception ex){error("LittleSkin profile selection failed: "+rootMessage(ex));}}}.execute();}else applyAuthenticatedSession(s);}catch(Exception ex){error("LittleSkin sign-in failed: "+rootMessage(ex));}}
            }.execute();
        } else { error("Offline accounts do not need sign-in. They only work on offline-mode servers."); }
    }

    private void applyAuthenticatedSession(AccountAuthenticator.Session session) {
        if(session.profile==null){error("Authentication completed but no Minecraft profile was selected.");return;}
        authenticatedSession=session;
        username.setText(session.profile.name);
        selectedAccountType=session.type;
        if("Microsoft".equals(session.type)) setStatus("Signed in to Microsoft as "+session.profile.name+". Minecraft ownership verified.");
        else setStatus("Signed in to LittleSkin as "+session.profile.name+".");
        persistAccounts();
        try {
            if("Microsoft".equals(session.type) && (session.refreshToken==null || session.refreshToken.isEmpty()))
                throw new IOException("Microsoft did not return a refresh token; this session cannot be safely restored automatically.");
            CredentialVault.save(encodeSession(session));
            setStatus("Signed in as "+session.profile.name+". Session securely saved in macOS Keychain; Winter Client will restore it next launch.");
        } catch(Exception ex) {
            setStatus("Signed in as "+session.profile.name+", but automatic sign-in could not be saved: "+rootMessage(ex));
        }
    }

    private String encodeSession(AccountAuthenticator.Session s) {
        String[] values={s.type,selectedAccountName,s.accessToken,s.refreshToken,s.clientToken,s.apiRoot,s.profile.id,s.profile.name};
        StringBuilder out=new StringBuilder("v1");
        for(String value:values) out.append("|").append(java.util.Base64.getEncoder().encodeToString((value==null?"":value).getBytes(StandardCharsets.UTF_8)));
        return out.toString();
    }

    private void restoreStoredSession() {
        if("Offline / Cracked".equals(selectedAccountType)) return;
        restoringSession=true;
        final String expectedType=selectedAccountType, expectedName=selectedAccountName;
        setStatus("Checking saved account session in macOS Keychain…");
        new SwingWorker<AccountAuthenticator.Session,Void>() {
            protected AccountAuthenticator.Session doInBackground() throws Exception {
                String saved=CredentialVault.load();
                if(saved==null||saved.trim().isEmpty()) return null;
                String[] f=saved.split("\\|",-1);
                if(f.length!=9||!"v1".equals(f[0])) return null;
                String[] v=new String[8];
                for(int i=0;i<8;i++) v[i]=new String(java.util.Base64.getDecoder().decode(f[i+1]),StandardCharsets.UTF_8);
                if(!expectedType.equals(v[0])||!expectedName.equals(v[1])) return null;
                if("Microsoft".equals(v[0])) {
                    if(v[3].isEmpty()) return null;
                    return AccountAuthenticator.refreshMicrosoft(v[3]);
                }
                if("LittleSkin".equals(v[0])) {
                    AccountAuthenticator.Profile p=new AccountAuthenticator.Profile(v[6],v[7]);
                    return AccountAuthenticator.refreshLittleSkin(v[5],v[2],v[4],p);
                }
                return null;
            }
            protected void done() {
                restoringSession=false;
                try {
                    AccountAuthenticator.Session restored=get();
                    if(restored!=null) applyAuthenticatedSession(restored);
                    else setStatus("Ready. Sign in once in Account Manager to enable automatic sign-in next time.");
                } catch(Exception ex) {
                    setStatus("Saved session expired or needs re-authentication. Sign in once in Account Manager: "+rootMessage(ex));
                }
            }
        }.execute();
    }
    private void loadAccount(String entry) {
        int split=entry.indexOf(" | "); if(split<0)return;
        authenticatedSession=null; selectedAccountType=entry.substring(0,split); selectedAccountName=entry.substring(split+3); accountType.setSelectedItem(selectedAccountType); accountUsername.setText(selectedAccountName); username.setText(selectedAccountName);
        if("LittleSkin".equals(selectedAccountType)) littleSkinServer.setText(settings.getProperty("account.littleskin.server", "https://littleskin.cn/api/yggdrasil"));
        setStatus("Selected account: "+selectedAccountName+" ("+selectedAccountType+")");
    }

    private void loadAccounts() {
        String saved=settings.getProperty("accounts", "");
        for(String item:saved.split(";;")) if(!item.trim().isEmpty()) accountModel.addElement(item.trim());        selectedAccountType=settings.getProperty("account.type", "Offline / Cracked"); selectedAccountName=settings.getProperty("account.name", settings.getProperty("username", "Player"));
        accountType.setSelectedItem(selectedAccountType); accountUsername.setText(selectedAccountName); username.setText(selectedAccountName);
        littleSkinServer.setText(settings.getProperty("account.littleskin.server", "https://littleskin.cn/api/yggdrasil"));

    }

    private void persistAccounts() {
        StringBuilder b=new StringBuilder(); for(int i=0;i<accountModel.size();i++){if(i>0)b.append(";;");b.append(accountModel.get(i));}
        settings.setProperty("accounts",b.toString()); settings.setProperty("account.type",selectedAccountType); settings.setProperty("account.name",selectedAccountName); settings.setProperty("account.littleskin.server",littleSkinServer.getText().trim());        try{settingsFile.getParentFile().mkdirs();FileOutputStream out=new FileOutputStream(settingsFile);settings.store(out,"Winter Client settings");out.close();}catch(Exception e){setStatus("Account save failed: "+e.getMessage());}
    }


    private JPanel buildVersionManager() {
        JPanel content = new JPanel(); content.setOpaque(false); content.setBorder(new EmptyBorder(18,18,18,18));
        content.setLayout(new BoxLayout(content, BoxLayout.Y_AXIS));

        JLabel heading = new JLabel("VERSION DOWNLOADER");
        heading.setForeground(new Color(236,243,255)); heading.setFont(new Font("SansSerif",Font.BOLD,20));
        JLabel intro = new JLabel("Browse official Minecraft releases and install them into your game directory.");
        intro.setForeground(new Color(147,164,188));
        content.add(heading); content.add(Box.createVerticalStrut(6)); content.add(intro); content.add(Box.createVerticalStrut(18));

        JPanel chooser = new JPanel(new BorderLayout(10,0)); chooser.setOpaque(false);
        JComboBox<String> versions = new JComboBox<String>(); versions.setEditable(false); versions.setFont(new Font("SansSerif",Font.PLAIN,14));
        JButton reload = button("Refresh versions"); chooser.add(versions,BorderLayout.CENTER); chooser.add(reload,BorderLayout.EAST);
        content.add(chooser); content.add(Box.createVerticalStrut(10));

        JButton install = button("DOWNLOAD & INSTALL SELECTED VERSION");
        install.setBackground(new Color(76,137,255)); install.setForeground(Color.WHITE);
        install.setFont(new Font("SansSerif",Font.BOLD,14)); install.setAlignmentX(Component.LEFT_ALIGNMENT);
        content.add(install); content.add(Box.createVerticalStrut(10));
        downloadProgress.setStringPainted(true); downloadProgress.setString("Ready to download"); downloadProgress.setValue(0);
        downloadProgress.setForeground(new Color(76,137,255)); downloadProgress.setBackground(new Color(35,43,57));
        content.add(downloadProgress); content.add(Box.createVerticalStrut(18));
        JSeparator javaSep = new JSeparator(); javaSep.setMaximumSize(new Dimension(Integer.MAX_VALUE,2)); content.add(javaSep); content.add(Box.createVerticalStrut(14));
        JLabel javaTitle = new JLabel("JAVA RUNTIME INSTALLER"); javaTitle.setForeground(new Color(205,218,239)); javaTitle.setFont(new Font("SansSerif",Font.BOLD,14)); content.add(javaTitle);
        JLabel javaInfo = new JLabel("Install Temurin Java runtimes for Minecraft versions. Auto mode will detect installed versions."); javaInfo.setForeground(new Color(147,164,188)); content.add(Box.createVerticalStrut(5)); content.add(javaInfo);
        JPanel javaInstallRow = new JPanel(new FlowLayout(FlowLayout.LEFT,8,0)); javaInstallRow.setOpaque(false);
        JComboBox<String> javaVersions = new JComboBox<String>(new String[] {"Java 8 (Minecraft 1.8.9–1.16.5)", "Java 16 (Minecraft 1.17)", "Java 17 (Minecraft 1.18–1.20.4)", "Java 21 (Minecraft 1.20.5–1.21.x)", "Java 24", "Java 25 (Minecraft 26.1+ / 26.3)"});
        javaVersions.setSelectedIndex(0);
        JButton installJava = button("INSTALL JAVA"); installJava.setBackground(new Color(40,90,70)); installJava.setForeground(Color.WHITE);
        javaInstallRow.add(javaVersions); javaInstallRow.add(installJava); content.add(Box.createVerticalStrut(8)); content.add(javaInstallRow); content.add(Box.createVerticalStrut(16));

        JLabel installedTitle = new JLabel("INSTALLED VERSIONS"); installedTitle.setForeground(new Color(205,218,239));
        installedTitle.setFont(new Font("SansSerif",Font.BOLD,13)); content.add(installedTitle);
        installedVersions.setVisibleRowCount(4); installedVersions.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        installedVersions.setBackground(new Color(27,34,46)); installedVersions.setForeground(new Color(230,238,250));
        installedVersions.setFont(new Font("SansSerif",Font.PLAIN,13));
        JScrollPane installedScroll = new JScrollPane(installedVersions); installedScroll.setPreferredSize(new Dimension(500,95));
        installedScroll.setMaximumSize(new Dimension(Integer.MAX_VALUE,105)); content.add(installedScroll);
        JLabel installedHint = new JLabel("Select an installed version to use it in the Play tab."); installedHint.setForeground(new Color(147,164,188));
        content.add(Box.createVerticalStrut(4)); content.add(installedHint); content.add(Box.createVerticalStrut(18));        content.add(Box.createVerticalStrut(4)); content.add(installedHint); content.add(Box.createVerticalStrut(8));
        JButton importModpack = button("ADD MODPACK TO SELECTED VERSION"); importModpack.setBackground(new Color(76,110,160)); importModpack.setForeground(Color.WHITE); importModpack.setAlignmentX(Component.LEFT_ALIGNMENT);
        content.add(importModpack);
        JLabel modpackHint = new JLabel("Imports Modrinth .mrpack or ZIP files into an isolated folder for that Minecraft version."); modpackHint.setForeground(new Color(147,164,188));
        content.add(Box.createVerticalStrut(5)); content.add(modpackHint); content.add(Box.createVerticalStrut(18));
        importModpack.addActionListener(e -> importModpack(importModpack));

        JSeparator loaderSep = new JSeparator(); loaderSep.setMaximumSize(new Dimension(Integer.MAX_VALUE,2)); content.add(loaderSep); content.add(Box.createVerticalStrut(14));
        JLabel loaderTitle = new JLabel("FABRIC / FORGE LOADER INSTALLER"); loaderTitle.setForeground(new Color(205,218,239)); loaderTitle.setFont(new Font("SansSerif",Font.BOLD,14)); content.add(loaderTitle);
        JLabel loaderInfo = new JLabel("Install a loader onto a Minecraft version that is already installed. Your original version stays unchanged."); loaderInfo.setForeground(new Color(147,164,188)); content.add(loaderInfo);
        JPanel loaderRow = new JPanel(new FlowLayout(FlowLayout.LEFT,8,0)); loaderRow.setOpaque(false);
        loaderBaseVersions.setPreferredSize(new Dimension(190,28));
        JComboBox<String> loaderType = new JComboBox<String>(new String[] {"Fabric", "Forge"});
        JComboBox<String> loaderBuilds = new JComboBox<String>(); loaderBuilds.setPreferredSize(new Dimension(220,28));
        JButton loadLoaderBuilds = button("LOAD BUILDS"); loadLoaderBuilds.setBackground(new Color(76,110,160));
        JButton installLoader = button("INSTALL SELECTED LOADER"); installLoader.setBackground(new Color(40,90,70)); installLoader.setForeground(Color.WHITE);
        loaderRow.add(new JLabel("Installed Minecraft:")); loaderRow.add(loaderBaseVersions); loaderRow.add(loaderType); loaderRow.add(loaderBuilds); content.add(Box.createVerticalStrut(8)); content.add(loaderRow);
        JPanel loaderActions = new JPanel(new FlowLayout(FlowLayout.LEFT,8,0)); loaderActions.setOpaque(false); loaderActions.add(loadLoaderBuilds); loaderActions.add(installLoader); content.add(loaderActions);
        JLabel loaderNote = new JLabel("Select an installed vanilla version, load official builds, then install. Loader profiles are created separately."); loaderNote.setForeground(new Color(147,164,188)); content.add(Box.createVerticalStrut(5)); content.add(loaderNote); content.add(Box.createVerticalStrut(16));
        loadLoaderBuilds.addActionListener(e -> loadLoaderBuilds(loaderBaseVersions, loaderType, loaderBuilds, loadLoaderBuilds));
        loaderType.addActionListener(e -> { if (loaderBuilds.getItemCount() > 0) loadLoaderBuilds(loaderBaseVersions, loaderType, loaderBuilds, loadLoaderBuilds); });
        installLoader.addActionListener(e -> installSelectedLoader(loaderBaseVersions, loaderType, loaderBuilds, installLoader));
        JSeparator fabricSep = new JSeparator(); fabricSep.setMaximumSize(new Dimension(Integer.MAX_VALUE,2)); content.add(fabricSep); content.add(Box.createVerticalStrut(14));
        JLabel fabricTitle = new JLabel("FABRIC 26.3 — MODERN CLIENT"); fabricTitle.setForeground(new Color(205,218,239)); fabricTitle.setFont(new Font("SansSerif",Font.BOLD,14)); content.add(fabricTitle);
        JLabel fabricInfo = new JLabel("Install Fabric Loader 0.20.1, WinterHUD 26.3, 7 performance mods and 2 required libraries."); fabricInfo.setForeground(new Color(147,164,188)); content.add(fabricInfo);
        JPanel fabricButtons = new JPanel(new FlowLayout(FlowLayout.LEFT,8,0)); fabricButtons.setOpaque(false);
        JButton fabricInstall = button("INSTALL FABRIC 26.3"); fabricInstall.setBackground(new Color(40,90,70)); fabricInstall.setForeground(Color.WHITE);
        JButton fpsPackInstall = button("INSTALL 26.3 FPS + HUD PACK"); fpsPackInstall.setBackground(new Color(76,110,160)); fpsPackInstall.setForeground(Color.WHITE);
        fabricButtons.add(fabricInstall); fabricButtons.add(fpsPackInstall); content.add(Box.createVerticalStrut(8)); content.add(fabricButtons);        JLabel fabricNote = new JLabel("Uses a separate instances/26.3-fabric folder, keeping 1.8.9 Forge mods isolated."); fabricNote.setForeground(new Color(147,164,188)); content.add(Box.createVerticalStrut(5)); content.add(fabricNote);
        fabricInstall.addActionListener(e -> installFabric26(fabricInstall));
        fpsPackInstall.addActionListener(e -> installFabricMods(fpsPackInstall));

        JSeparator sep = new JSeparator(); sep.setMaximumSize(new Dimension(Integer.MAX_VALUE,2)); content.add(sep); content.add(Box.createVerticalStrut(14));
        JLabel forge = new JLabel("FORGE 1.8.9"); forge.setForeground(new Color(205,218,239)); forge.setFont(new Font("SansSerif",Font.BOLD,14)); content.add(forge);
        JLabel forgeInfo = new JLabel("Official Forge 11.15.1.2318 installer for Minecraft 1.8.9."); forgeInfo.setForeground(new Color(147,164,188)); content.add(forgeInfo);
        JButton forgeInstall = button("Download & open Forge 1.8.9 installer"); forgeInstall.setBackground(new Color(40,90,70));
        forgeInstall.setAlignmentX(Component.LEFT_ALIGNMENT); content.add(Box.createVerticalStrut(8)); content.add(forgeInstall);
        JLabel note = new JLabel("In the Forge installer, choose Install client and confirm your game directory."); note.setForeground(new Color(147,164,188)); content.add(Box.createVerticalStrut(5)); content.add(note);

        JSeparator optiSep = new JSeparator(); optiSep.setMaximumSize(new Dimension(Integer.MAX_VALUE,2)); content.add(Box.createVerticalStrut(14)); content.add(optiSep); content.add(Box.createVerticalStrut(12));
        JLabel optiTitle = new JLabel("OPTIFINE 1.8.9 — M5 / M6 PRE2"); optiTitle.setForeground(new Color(205,218,239)); optiTitle.setFont(new Font("SansSerif",Font.BOLD,14)); content.add(optiTitle);
        JLabel optiInfo = new JLabel("Import the official OptiFine M5 release or M6 pre2 preview for Forge 1.8.9."); optiInfo.setForeground(new Color(147,164,188)); content.add(optiInfo);
        JPanel optiButtons = new JPanel(new FlowLayout(FlowLayout.LEFT,8,0)); optiButtons.setOpaque(false);
        JButton optiDownload = button("Open official OptiFine download page"); optiDownload.setBackground(new Color(40,90,70));
        JButton optiInstall = button("Install downloaded OptiFine"); optiInstall.setBackground(new Color(76,110,160)); optiButtons.add(optiDownload); optiButtons.add(optiInstall); content.add(Box.createVerticalStrut(8)); content.add(optiButtons);
        JLabel optiNote = new JLabel("M6 pre2 is a preview build. OptiFine may conflict with other rendering/performance mods."); optiNote.setForeground(new Color(147,164,188)); content.add(Box.createVerticalStrut(5)); content.add(optiNote);        reload.addActionListener(e -> loadVersionList(versions,reload));
        install.addActionListener(e -> { Object selected=versions.getSelectedItem(); if(selected!=null) { String id=selected.toString(); String customName=promptVersionName(id); if(customName!=null) installVanilla(id,customName,install); } });
        installJava.addActionListener(e -> {
            String choice = String.valueOf(javaVersions.getSelectedItem());
            int major = Integer.parseInt(choice.substring("Java ".length(), choice.indexOf(' ' , "Java ".length()) < 0 ? choice.length() : choice.indexOf(' ', "Java ".length())));
            installJavaRuntime(major, installJava);
        });        installedVersions.addListSelectionListener(e -> { if(!e.getValueIsAdjusting() && installedVersions.getSelectedValue()!=null) { profile.setSelectedItem(installedVersions.getSelectedValue()); setStatus("Selected installed version "+installedVersions.getSelectedValue()+" for Play."); } });
        forgeInstall.addActionListener(e -> installForge(forgeInstall));
        optiDownload.addActionListener(e -> { try { if (Desktop.isDesktopSupported()) Desktop.getDesktop().browse(new java.net.URI("https://optifine.net/downloads")); else setStatus("Open https://optifine.net/downloads and download OptiFine 1.8.9 HD U M6 pre2."); setStatus("Download OptiFine 1.8.9 HD U M6 pre2 (Preview versions), then choose Install downloaded OptiFine."); } catch (Exception ex) { error("Could not open the official OptiFine website: " + rootMessage(ex)); } });        optiInstall.addActionListener(e -> installOptiFine(optiInstall));
        refreshInstalledVersions();
        SwingUtilities.invokeLater(() -> loadVersionList(versions,reload));
        JScrollPane outer = new JScrollPane(content); outer.setBorder(BorderFactory.createEmptyBorder()); outer.getViewport().setOpaque(false); outer.setOpaque(false);
        return wrapInPanel(outer);
    }

    private JPanel wrapInPanel(JComponent component) { JPanel p=new JPanel(new BorderLayout()); p.setOpaque(false); p.add(component,BorderLayout.CENTER); return p; }

    private String versionDisplayLabel(String id) {
        if (id == null || id.startsWith("No versions")) return id;
        File profileJson = new File(gameDir.getText(), "versions/" + id + "/" + id + ".json");
        if (profileJson.isFile()) {
            try {
                Map<String,Object> metadata = object(new Json(new String(Files.readAllBytes(profileJson.toPath()), StandardCharsets.UTF_8)).parse());
                String parent = string(metadata.get("inheritsFrom"));
                if (parent != null) {
                    String loader = null;
                    Object libraries = metadata.get("libraries");
                    if (libraries instanceof List) for (Object item : (List<?>)libraries) {
                        String coordinate = string(asMap(item).get("name"));
                        if (coordinate == null) continue;
                        if (coordinate.startsWith("net.fabricmc:fabric-loader:")) loader = "Fabric " + coordinate.substring("net.fabricmc:fabric-loader:".length());
                        else if (coordinate.startsWith("net.minecraftforge:forge:")) loader = "Forge " + coordinate.substring("net.minecraftforge:forge:".length());
                    }
                    if (loader != null) return "Minecraft " + versionDisplayLabel(parent) + "  (" + loader + ")";
                }
            } catch (Exception ignored) { }
        }
        File nameFile = new File(gameDir.getText(), "versions/" + id + "/.winter-name");
        if (!nameFile.isFile()) return id;
        try {
            String name = new String(Files.readAllBytes(nameFile.toPath()), StandardCharsets.UTF_8).trim();
            return name.isEmpty() || name.equals(id) ? id : name + "  (" + id + ")";
        } catch (Exception ignored) { return id; }
    }
    private String promptVersionName(String versionId) {
        String defaultName = "Minecraft " + versionId;
        String entered = JOptionPane.showInputDialog(frame, "Give this Minecraft version a name. You can still identify its original version ID in the launcher.", defaultName);
        if (entered == null) return null;
        String name = entered.trim();
        if (name.isEmpty() || name.length() > 48 || !name.matches("[\\p{L}\\p{N} _().+\\-]+")) {
            error("Version names must be 1–48 characters and may contain letters, numbers, spaces, parentheses, dots, plus signs, underscores or hyphens.");
            return null;
        }
        return name;
    }

    private void refreshInstalledVersions() {
        installedModel.clear();
        File dir = new File(gameDir.getText(), "versions");
        File[] entries = dir.listFiles();
        if(entries!=null) for(File entry:entries) if(new File(entry,entry.getName()+".json").isFile()) installedModel.addElement(entry.getName());
        if(installedModel.isEmpty()) installedModel.addElement("No versions installed yet");
        refreshLoaderBaseVersions();
    }

    private void refreshLoaderBaseVersions() {
        String previous = (String)loaderBaseVersions.getSelectedItem();
        loaderBaseVersions.removeAllItems();
        File versionsDir = new File(gameDir.getText(), "versions");
        File[] entries = versionsDir.listFiles();
        if (entries != null) {
            Arrays.sort(entries, (a, b) -> a.getName().compareToIgnoreCase(b.getName()));
            for (File entry : entries) {
                if (!entry.isDirectory()) continue;
                File metadata = new File(entry, entry.getName() + ".json");
                if (!metadata.isFile()) continue;
                try {
                    String json = new String(Files.readAllBytes(metadata.toPath()), StandardCharsets.UTF_8);
                    // Loader and OptiFine profiles inherit a base version; offer only standalone installed bases.
                    if (json.matches("(?s).*\\\"inheritsFrom\\\"\\s*:.*")) continue;
                    loaderBaseVersions.addItem(entry.getName());
                } catch (Exception ignored) { }
            }
        }
        if (previous != null) loaderBaseVersions.setSelectedItem(previous);
    }

    private void loadVersionList(JComboBox<String> versions,JButton button) {
        button.setEnabled(false);setStatus("Fetching Mojang version manifest…");
        new SwingWorker<List<String>,Void>() {
            protected List<String> doInBackground() throws Exception { return new VersionInstaller(new File(gameDir.getText())).listReleases(); }
            protected void done(){button.setEnabled(true);try{String old=(String)versions.getSelectedItem();versions.removeAllItems();for(String v:get())versions.addItem(v);if(old!=null)versions.setSelectedItem(old);if(versions.getSelectedItem()==null)versions.setSelectedItem("1.8.9");setStatus("Loaded "+versions.getItemCount()+" official Minecraft releases.");}catch(Exception ex){error("Could not load versions: "+rootMessage(ex));}}
        }.execute();
    }
    private void loadLoaderBuilds(JComboBox<String> minecraftVersions, JComboBox<String> loaderType, JComboBox<String> builds, JButton button) {
        String mc = (String)minecraftVersions.getSelectedItem();
        if (mc == null || mc.trim().isEmpty()) { error("Choose a Minecraft release first."); return; }
        String type = String.valueOf(loaderType.getSelectedItem());
        button.setEnabled(false); setStatus("Fetching official " + type + " builds for Minecraft " + mc + "…");
        new SwingWorker<List<String>,Void>() {
            protected List<String> doInBackground() throws Exception {
                VersionInstaller installer = new VersionInstaller(new File(gameDir.getText()));
                return "Fabric".equals(type) ? installer.listFabricLoaderVersions(mc) : installer.listForgeVersions(mc);
            }
            protected void done() {
                button.setEnabled(true);
                try { List<String> found = get(); builds.removeAllItems(); for (String v : found) builds.addItem(v); setStatus("Loaded " + found.size() + " official " + type + " build(s) for Minecraft " + mc + "."); }
                catch (Exception ex) { builds.removeAllItems(); error("Could not load " + type + " builds: " + rootMessage(ex)); }
            }
        }.execute();
    }

    private int javaMajorForMinecraft(String version) {
        try {
            String[] p = version.split("\\."); int minor = Integer.parseInt(p[1]);
            if (Integer.parseInt(p[0]) >= 26) return 25;
            if (minor >= 21) return 21;
            if (minor == 20 && p.length > 2 && Integer.parseInt(p[2]) >= 5) return 21;
            if (minor >= 18) return 17;
            if (minor == 17) return 16;
        } catch (Exception ignored) { }
        return 8;
    }

    private void installSelectedLoader(JComboBox<String> minecraftVersions, JComboBox<String> loaderType, JComboBox<String> builds, JButton button) {
        String mc = (String)minecraftVersions.getSelectedItem(); String build = (String)builds.getSelectedItem();
        if (mc == null || build == null) { error("Choose a Minecraft version and load a compatible loader build first."); return; }
        File vanilla = new File(gameDir.getText(), "versions/" + mc + "/" + mc + ".json");
        if (!vanilla.isFile()) { error("Install vanilla Minecraft " + mc + " first using DOWNLOAD & INSTALL SELECTED VERSION."); return; }
        String type = String.valueOf(loaderType.getSelectedItem()); int javaMajor = javaMajorForMinecraft(mc); String java = findJava(javaMajor);
        if (java == null) { error("Minecraft " + mc + " needs Java " + javaMajor + " for the loader installer. Install Java " + javaMajor + " in the Java Runtime Installer first."); return; }
        int confirm = JOptionPane.showConfirmDialog(frame, "Install official " + type + " " + build + " for Minecraft " + mc + "?", "Install " + type, JOptionPane.YES_NO_OPTION);
        if (confirm != JOptionPane.YES_OPTION) return;
        button.setEnabled(false); downloadProgress.setIndeterminate(true); downloadProgress.setString("Installing " + type + "…");
        new SwingWorker<File,String>() {
            protected File doInBackground() throws Exception {
                VersionInstaller installer = new VersionInstaller(new File(gameDir.getText()));
                return "Fabric".equals(type) ? installer.installFabricClient(mc, build, java, s -> publish(s)) : installer.installForgeClient(mc, build, java, s -> publish(s));
            }
            protected void process(List<String> chunks) { if (!chunks.isEmpty()) { String latest = chunks.get(chunks.size()-1); downloadProgress.setString(latest); setStatus(latest); } }
            protected void done() {
                button.setEnabled(true); downloadProgress.setIndeterminate(false);
                try { File installed = get(); refreshProfiles(); refreshInstalledVersions(); String id = installed.getParentFile().getName(); profile.setSelectedItem(id); downloadProgress.setValue(100); downloadProgress.setString(type + " installed"); setStatus("Minecraft " + mc + " is ready with " + type + " " + build + ". The Play selector now shows the parent Minecraft version and loader; the original vanilla profile remains unchanged."); }
                catch (Exception ex) { downloadProgress.setValue(0); downloadProgress.setString("Loader installation failed"); error(type + " installation failed: " + rootMessage(ex)); }            }
        }.execute();
    }

    private void installFabric26(JButton button) {
        String java25 = findJava(25);
        if (java25 == null) { error("Minecraft 26.3 requires Java 25. Install Java 25 in the Java Runtime Installer first."); return; }
        button.setEnabled(false); downloadProgress.setIndeterminate(true); downloadProgress.setString("Installing Fabric 26.3…");
        new SwingWorker<File,String>() {
            protected File doInBackground() throws Exception { return new VersionInstaller(new File(gameDir.getText())).installFabricClient("26.3", "0.20.1", java25, message -> publish(message)); }
            protected void process(List<String> chunks) { if (!chunks.isEmpty()) { String latest=chunks.get(chunks.size()-1); downloadProgress.setString(latest); setStatus(latest); } }
            protected void done() { button.setEnabled(true); downloadProgress.setIndeterminate(false); try { File profileJson=get(); refreshProfiles(); String id=profileJson.getParentFile().getName(); profile.setSelectedItem(id); refreshInstalledVersions(); downloadProgress.setValue(100); downloadProgress.setString("Fabric 26.3 installed"); setStatus("Fabric Loader 0.20.1 installed. Next, install the 26.3 FPS + WinterHUD pack."); } catch(Exception ex) { error("Fabric installation failed: "+rootMessage(ex)); } }        }.execute();
    }

    private void installFabricMods(JButton button) {
        File fabricProfile = new File(gameDir.getText(), "versions/fabric-loader-0.20.1-26.3/fabric-loader-0.20.1-26.3.json");
        if (!fabricProfile.isFile()) { error("Install Fabric 26.3 first using INSTALL FABRIC 26.3."); return; }
        button.setEnabled(false);
        downloadProgress.setIndeterminate(true);
        downloadProgress.setString("Installing 7 FPS mods, 2 libraries and WinterHUD…");
        new SwingWorker<File,String>() {
            protected File doInBackground() throws Exception {
                return new VersionInstaller(new File(gameDir.getText())).install26PerformanceMods(message -> publish(message));
            }
            protected void process(List<String> chunks) {
                if (!chunks.isEmpty()) {
                    String latest=chunks.get(chunks.size()-1);
                    downloadProgress.setString(latest);
                    setStatus(latest);
                }
            }
            protected void done() {
                button.setEnabled(true);
                downloadProgress.setIndeterminate(false);
                try {
                    File mods=get();
                    downloadProgress.setValue(100);
                    downloadProgress.setString("FPS pack + WinterHUD installed");
                    setStatus("Installed 7 verified 26.3 performance mods, 2 dependencies and WinterHUD in "+mods.getAbsolutePath());
                } catch(Exception ex) {
                    error("FPS mod installation failed: "+rootMessage(ex));
                }
            }
        }.execute();
    }
    private void installJavaRuntime(int major, JButton button) {
        button.setEnabled(false);
        downloadProgress.setIndeterminate(true);
        downloadProgress.setString("Installing Temurin Java " + major + "…");
        setStatus("Preparing Java " + major + " installation…");
        new SwingWorker<File,String>() {
            protected File doInBackground() throws Exception {
                return JavaRuntimeInstaller.install(major, message -> publish(message));
            }
            protected void process(List<String> chunks) {
                if (!chunks.isEmpty()) {
                    String latest = chunks.get(chunks.size()-1);
                    downloadProgress.setString(latest);
                    setStatus(latest);
                }
            }
            protected void done() {
                button.setEnabled(true);
                downloadProgress.setIndeterminate(false);
                try {
                    File executable = get();
                    String detected = findJava(major);
                    if (detected == null) detected = executable.getAbsolutePath();
                    javaPath.setText(detected);
                    javaRequirement.setText("Java " + major + " installed and detected");
                    downloadProgress.setValue(100);
                    downloadProgress.setString("Java " + major + " installed");
                    setStatus("Java " + major + " installed. Automatic mode can now select it for matching Minecraft versions.");
                } catch (Exception ex) {
                    downloadProgress.setValue(0);
                    downloadProgress.setString("Java installation failed");
                    error("Java " + major + " installation failed: " + rootMessage(ex));
                }
            }
        }.execute();
    }

    private void importModpack(JButton button) {
        String selectedVersion = installedVersions.getSelectedValue();
        if (selectedVersion == null || selectedVersion.startsWith("No versions")) selectedVersion = (String)profile.getSelectedItem();
        if (selectedVersion == null || selectedVersion.startsWith("No versions")) { error("Select an installed Minecraft version first."); return; }
        final String versionId = selectedVersion;
        JFileChooser chooser = new JFileChooser(new File(System.getProperty("user.home"), "Downloads"));
        chooser.setDialogTitle("Choose a Modrinth .mrpack or modpack ZIP");
        chooser.setAcceptAllFileFilterUsed(false);
        chooser.addChoosableFileFilter(new javax.swing.filechooser.FileNameExtensionFilter("Modrinth modpack or ZIP (*.mrpack, *.zip)", "mrpack", "zip"));
        if (chooser.showOpenDialog(frame) != JFileChooser.APPROVE_OPTION) return;
        final File archive = chooser.getSelectedFile();
        int confirm = JOptionPane.showConfirmDialog(frame,
                "Import " + archive.getName() + " into Minecraft " + versionId + "?\n\nWinter Client will create an isolated instance at instances/" + versionId + ". Existing files are preserved; conflicting names are imported with a .modpack suffix.\n\nModrinth .mrpack files are supported. ZIP files must contain mods, config, resourcepacks or shaderpacks folders.",
                "Add modpack to version", JOptionPane.YES_NO_OPTION);
        if (confirm != JOptionPane.YES_OPTION) return;
        button.setEnabled(false); downloadProgress.setIndeterminate(true); downloadProgress.setString("Importing modpack…");
        new SwingWorker<File,String>() {
            protected File doInBackground() throws Exception {
                return new ModpackInstaller(new File(gameDir.getText())).importModpack(archive, versionId, message -> publish(message));
            }
            protected void process(List<String> chunks) {
                if (!chunks.isEmpty()) { String latest = chunks.get(chunks.size()-1); downloadProgress.setString(latest); setStatus(latest); }
            }
            protected void done() {
                button.setEnabled(true); downloadProgress.setIndeterminate(false);
                try {
                    File instance = get(); profile.setSelectedItem(versionId); refreshInstalledVersions(); installedVersions.setSelectedValue(versionId, true);
                    downloadProgress.setValue(100); downloadProgress.setString("Modpack imported");
                    setStatus("Modpack added to Minecraft " + versionId + ". Launch that version to use its isolated mods/config: " + instance.getAbsolutePath());
                } catch (Exception ex) {
                    downloadProgress.setValue(0); downloadProgress.setString("Modpack import failed"); error("Modpack import failed: " + rootMessage(ex));
                }
            }
        }.execute();
    }

    private void installVanilla(String id, String customName, JButton button) {
        button.setEnabled(false); downloadProgress.setIndeterminate(true); downloadProgress.setString("Downloading and installing " + customName + "…"); setStatus("Preparing Minecraft " + id + " download for " + customName + "…");
        new SwingWorker<Void,String>() {
            protected Void doInBackground() throws Exception { new VersionInstaller(new File(gameDir.getText())).installVanilla(id,s->publish(s)); return null; }
            protected void process(List<String> chunks) { if(!chunks.isEmpty()) { String latest=chunks.get(chunks.size()-1); setStatus(latest); downloadProgress.setString(latest); } }
            protected void done() {
                button.setEnabled(true); downloadProgress.setIndeterminate(false);
                try {
                    get(); File nameFile = new File(gameDir.getText(), "versions/" + id + "/.winter-name");
                    Files.write(nameFile.toPath(), customName.getBytes(StandardCharsets.UTF_8), StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING);
                    downloadProgress.setValue(100); downloadProgress.setString("Installed " + customName); refreshProfiles(); refreshInstalledVersions(); profile.setSelectedItem(id);
                    setStatus(customName + " (Minecraft " + id + ") installed successfully.");
                } catch(Exception ex) { downloadProgress.setValue(0); downloadProgress.setString("Download failed"); error("Installation failed: " + rootMessage(ex)); }
            }
        }.execute();
    }
    private void installForge(JButton button) {
        if(!new File(gameDir.getText(),"versions/1.8.9/1.8.9.json").isFile()){error("Install vanilla Minecraft 1.8.9 first using the Version Manager.");return;}
        int choice=JOptionPane.showConfirmDialog(frame,"Download the official Forge 1.8.9 installer and run it? The installer will modify your Minecraft game directory. Continue only if you trust the official Forge source.","Install Forge 1.8.9",JOptionPane.YES_NO_OPTION);
        if(choice!=JOptionPane.YES_OPTION)return;
        button.setEnabled(false);setStatus("Downloading Forge installer…");
        new SwingWorker<File,String>() {
            protected File doInBackground() throws Exception {return new VersionInstaller(new File(gameDir.getText())).downloadForgeInstaller(s->publish(s));}
            protected void process(List<String> chunks){if(!chunks.isEmpty())setStatus(chunks.get(chunks.size()-1));}
            protected void done() {
                button.setEnabled(true);
                try {
                    File installer = get();
                    int run = JOptionPane.showConfirmDialog(frame,
                        "Forge installer downloaded and verified. Open it now?\n" + installer.getAbsolutePath() +
                        "\n\nIn the Forge window, select Install client, confirm the game directory, then click OK.",
                        "Open Forge installer", JOptionPane.YES_NO_OPTION);
                    if (run == JOptionPane.YES_OPTION) {
                        new ProcessBuilder(javaPath.getText().trim().isEmpty() ? "java" : javaPath.getText().trim(),
                            "-jar", installer.getAbsolutePath()).directory(new File(gameDir.getText())).start();
                        setStatus("Forge installer opened. Select Install client and confirm the game directory, then refresh profiles here.");
                    } else setStatus("Forge installer downloaded. Open it from frost-downloads when ready.");
                } catch (Exception ex) { error("Forge installer download/launch failed: " + rootMessage(ex)); }
            }
        }.execute();
    }
    private void installOptiFine(JButton button) {
        JFileChooser chooser = new JFileChooser(new File(System.getProperty("user.home"), "Downloads"));
        chooser.setDialogTitle("Select official OptiFine 1.8.9 HD U M5 or M6 pre2 JAR from optifine.net");
        chooser.setAcceptAllFileFilterUsed(false);
        chooser.addChoosableFileFilter(new javax.swing.filechooser.FileNameExtensionFilter("Java archive (*.jar)", "jar"));
        if (chooser.showOpenDialog(frame) != JFileChooser.APPROVE_OPTION) return;
        File selected = chooser.getSelectedFile(); button.setEnabled(false); downloadProgress.setIndeterminate(true); downloadProgress.setString("Verifying OptiFine…");
        new SwingWorker<File,String>() {
            protected File doInBackground() throws Exception { return new VersionInstaller(new File(gameDir.getText())).importOptiFine(selected, s -> publish(s)); }
            protected void process(List<String> chunks) { if (!chunks.isEmpty()) { String message = chunks.get(chunks.size()-1); setStatus(message); downloadProgress.setString(message); } }
            protected void done() {
                button.setEnabled(true); downloadProgress.setIndeterminate(false);
                try { File installed = get(); downloadProgress.setValue(100); downloadProgress.setString("OptiFine installed"); setStatus("OptiFine installed: " + installed.getAbsolutePath() + ". Restart Minecraft before launching."); }
                catch (Exception ex) { downloadProgress.setValue(0); downloadProgress.setString("OptiFine install failed"); error("OptiFine installation failed: " + rootMessage(ex)); }
            }
        }.execute();
    }
    private static String rootMessage(Throwable t){while(t.getCause()!=null)t=t.getCause();return t.getMessage()==null?t.toString():t.getMessage();}
    private void addRow(JPanel p,GridBagConstraints c,String label,JComponent component) {        JLabel l=new JLabel(label);l.setForeground(new Color(178,192,213));l.setFont(new Font("SansSerif",Font.PLAIN,13));
        c.gridx=0;c.weightx=0;c.gridy++;p.add(l,c);c.gridx=1;c.weightx=1;component.setFont(new Font("SansSerif",Font.PLAIN,13));p.add(component,c);
    }
    private JButton button(String text) {
        JButton b=new JButton(text);b.setFocusPainted(false);b.setBackground(new Color(40,50,67));b.setForeground(new Color(230,238,250));
        b.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(new Color(67,82,106)),new EmptyBorder(9,13,9,13)));return b;
    }
    private void refreshProfiles() {
        File versions=new File(gameDir.getText(),"versions");String selected=(String)profile.getSelectedItem();profile.removeAllItems();
        if(versions.isDirectory()){File[] dirs=versions.listFiles();if(dirs!=null)for(File d:dirs)if(new File(d,d.getName()+".json").isFile())profile.addItem(d.getName());}
        if(profile.getItemCount()==0)profile.addItem("1.8.9");if(selected!=null)profile.setSelectedItem(selected);
        refreshInstalledVersions();
        setStatus("Found "+profile.getItemCount()+" local profile(s). Install Minecraft 1.8.9 using Version Manager if needed.");
    }
    private void launchGame() {
        if(restoringSession){setStatus("Please wait while the saved account session is restored…");return;}
        saveSettings();
        String name=username.getText().trim(), uuid, accessToken="0", userType="legacy";
        if("Offline / Cracked".equals(selectedAccountType)) {
            if(!name.matches("[A-Za-z0-9_]{1,16}")){error("Use a Minecraft name with 1–16 letters, numbers, or underscores.");return;}
            uuid=UUID.nameUUIDFromBytes(("OfflinePlayer:"+name).getBytes(StandardCharsets.UTF_8)).toString().replace("-","");
        } else {
            if(authenticatedSession==null || !selectedAccountType.equals(authenticatedSession.type) || authenticatedSession.profile==null) {
                error("Sign in to the selected "+selectedAccountType+" account before launching."); return;
            }
            name=authenticatedSession.profile.name; uuid=authenticatedSession.profile.id.replace("-","");
            accessToken=authenticatedSession.accessToken; userType="Microsoft".equals(selectedAccountType)?"msa":"legacy";            if(!uuid.matches("(?i)[0-9a-f]{32}")){error("The authenticated Minecraft profile returned an invalid UUID.");return;}
        }
        File root=new File(gameDir.getText()).getAbsoluteFile();
        String id=(String)profile.getSelectedItem();
        if(id==null || id.trim().isEmpty()){error("Select an installed Minecraft version first.");return;}
        File jsonFile=new File(new File(root,"versions/"+id),id+".json");
        if(!jsonFile.isFile()){error("Profile "+id+" is not installed. Install it using Version Downloader first.");return;}
        File versionInstance = instanceDirectoryForVersion(root, id);
        File gameRoot = versionInstance;
        if (!gameRoot.isDirectory() && !gameRoot.mkdirs()) { error("Could not create game instance directory: " + gameRoot); return; }        try {            Map<String,Object> meta=loadMetadata(root,id,new HashSet<String>());
            String baseId=string(meta.get("_frostBaseVersion")); if(baseId==null)baseId=id;
            int requiredJava=requiredJavaMajor(meta,id);
            String selectedJava;
            if(javaMode.getSelectedIndex()==0) {
                selectedJava=findJava(requiredJava);
                if(selectedJava==null)throw new IOException("Minecraft "+id+" requires Java "+requiredJava+", but it was not found. Install Java "+requiredJava+" or select Manual Java.");                javaPath.setText(selectedJava); javaRequirement.setText("Auto: Java "+requiredJava+" selected for "+id);
            } else {
                selectedJava=javaPath.getText().trim();
                if(selectedJava.isEmpty() || !new File(selectedJava).isFile() || !new File(selectedJava).canExecute())
                    throw new IOException("Choose a valid Java executable in Manual mode.");
                javaRequirement.setText("Manual: "+selectedJava);
            }

            File client=new File(root,"versions/"+baseId+"/"+baseId+".jar");
            if(!client.isFile())throw new IOException("Missing Minecraft client JAR: "+client+". Reinstall this version.");
            File natives=new File(root,"versions/"+id+"/"+id+"-natives");
            if(!natives.isDirectory())natives=new File(root,"versions/"+baseId+"/"+baseId+"-natives");
            if(!natives.exists())natives.mkdirs();
            for(String nativeFolder:new String[]{"java","jna","lwjgl","netty"})new File(natives,nativeFolder).mkdirs();
            extractNatives(root, meta, natives);

            LinkedHashMap<String,String> classpathEntries=new LinkedHashMap<String,String>();
            classpathEntries.put("minecraft-client",client.getAbsolutePath());
            Object libs=meta.get("libraries");
            if(libs instanceof List) for(Object item:(List<?>)libs) {
                Map<String,Object> lib=asMap(item);
                if(!libraryAllowed(lib))continue;
                Map<String,Object> artifact=asMap(asMap(lib.get("downloads")).get("artifact"));
                String rel=string(artifact.get("path"));
                if(rel==null)rel=mavenPath(string(lib.get("name")));
                if(rel!=null) {
                    File jar=new File(root,"libraries/"+rel);
                    if(jar.isFile())classpathEntries.put(libraryKey(item),jar.getAbsolutePath());
                    else if(asMap(lib.get("downloads")).containsKey("artifact"))
                        throw new IOException("Missing library "+rel+". Reinstall Minecraft "+id+" from Version Downloader.");
                }
            }
            String classpath=join(new ArrayList<String>(classpathEntries.values()),File.pathSeparator);
            String mainClass=string(meta.get("mainClass"));
            if(mainClass==null)throw new IOException("Version metadata has no mainClass.");
            Map<String,String> vars=new HashMap<String,String>();
            vars.put("auth_player_name",name); vars.put("version_name",id);
            vars.put("game_directory",gameRoot.getAbsolutePath()); vars.put("assets_root",new File(root,"assets").getAbsolutePath());            Map<String,Object> assetIndex=asMap(meta.get("assetIndex"));
            String assets=string(assetIndex.get("id")); if(assets==null)assets=string(meta.get("assets")); if(assets==null)assets=baseId;
            vars.put("assets_index_name",assets); vars.put("auth_uuid",uuid); vars.put("auth_access_token",accessToken);
            vars.put("clientid",""); vars.put("auth_xuid",""); vars.put("user_type",userType);
            vars.put("user_properties","{}");
            Map<String,Object> logging=asMap(meta.get("logging")); Map<String,Object> clientLogging=asMap(logging.get("client"));
            Map<String,Object> loggingFile=asMap(clientLogging.get("file")); String loggingId=string(loggingFile.get("id"));
            File logConfig=loggingId==null?new File(root,"assets/log_configs/none"):new File(root,"assets/log_configs/"+loggingId);
            vars.put("path",logConfig.getAbsolutePath());
            vars.put("version_type",string(meta.get("type"))==null?"release":string(meta.get("type")));
            vars.put("natives_directory",natives.getAbsolutePath()); vars.put("launcher_name","Winter Client");
            vars.put("launcher_version","1.0"); vars.put("classpath",classpath);
            vars.put("library_directory",new File(root,"libraries").getAbsolutePath());
            vars.put("classpath_separator",File.pathSeparator); vars.put("resolution_width","960"); vars.put("resolution_height","600");            Object arguments=meta.get("arguments");
            List<String> cmd=new ArrayList<String>(); cmd.add(selectedJava);
            // Modern SDL-based versions need Cocoa initialized on the first JVM thread.
            // Legacy LWJGL 2 (Minecraft 1.8.9) matches OneClient and omits this flag.
            if(System.getProperty("os.name","").toLowerCase(Locale.ROOT).contains("mac") && arguments instanceof Map)
                cmd.add("-XstartOnFirstThread");
            if(arguments instanceof Map) {
                Object defaultJvm=asMap(arguments).get("default-user-jvm");
                if(defaultJvm!=null && String.valueOf(defaultJvm).contains("UseCompactObjectHeaders"))
                    cmd.add("-XX:+UnlockExperimentalVMOptions");
                appendArguments(cmd,defaultJvm,vars);
            }            cmd.add("-Xms512M"); cmd.add("-Xmx"+memory.getValue()+"M");            if("LittleSkin".equals(selectedAccountType)) {
                File injector=AccountAuthenticator.ensureAuthlibInjector();
                String prefetched=AccountAuthenticator.littleSkinPrefetchedMetadata(authenticatedSession.apiRoot);
                cmd.add("-javaagent:"+injector.getAbsolutePath()+"="+authenticatedSession.apiRoot);
                cmd.add("-Dauthlibinjector.yggdrasil.prefetched="+prefetched);
            }
            if(arguments instanceof Map) {
                Map<String,Object> argMap=asMap(arguments);
                appendArguments(cmd,argMap.get("jvm"),vars);
                String loggingArgument=string(clientLogging.get("argument"));
                if(loggingArgument!=null && logConfig.isFile())cmd.add(substitute(loggingArgument,vars));
                // Modern metadata supplies the classpath through arguments.jvm.
                if(!containsToken(asList(argMap.get("jvm")),"-cp") && !containsToken(asList(argMap.get("jvm")),"-classpath")) {
                    cmd.add("-cp"); cmd.add(classpath);
                }
                cmd.add(mainClass);
                appendArguments(cmd,argMap.get("game"),vars);
            } else {
                String gameArgs=string(meta.get("minecraftArguments"));
                if(gameArgs==null)throw new IOException("This version has neither modern arguments nor legacy minecraftArguments.");
                cmd.add("-Djava.library.path="+natives.getAbsolutePath());
                cmd.add("-cp"); cmd.add(classpath); cmd.add(mainClass);
                // Legacy 1.8.9 requires its full version-defined authentication and game arguments.
                for(String arg:splitLegacyArguments(gameArgs))cmd.add(substitute(arg,vars));
                
            }
            // Explicitly keep per-instance display settings under the selected --gameDir.
            // Do not read or copy the global Minecraft options.txt for any profile.
            if (!cmd.contains("--gameDir")) { cmd.add("--gameDir"); cmd.add(gameRoot.getAbsolutePath()); }
            ProcessBuilder pb=new ProcessBuilder(cmd);
            pb.directory(gameRoot);
            pb.redirectErrorStream(true);
            File log=new File(gameRoot,"winter-client.log");
            Map<String,String> processEnvironment=pb.environment();
            if(System.getProperty("os.name","").toLowerCase(Locale.ROOT).contains("mac")) {
                // Remove stale XQuartz/Wayland display hints and let SDL select the native macOS backend.
                processEnvironment.remove("DISPLAY");
                processEnvironment.remove("WAYLAND_DISPLAY");
                processEnvironment.remove("SDL_VIDEODRIVER");
            }            pb.redirectOutput(ProcessBuilder.Redirect.appendTo(log));
            Process gameProcess=pb.start();
            String launchInfo="\\n["+new java.util.Date()+"] Starting Minecraft "+id+" with Java "+requiredJava
                    +" | gameDir="+gameRoot.getAbsolutePath()+" | SDL_VIDEODRIVER="
                    +processEnvironment.getOrDefault("SDL_VIDEODRIVER","auto")+"\\n";
            Files.write(log.toPath(),launchInfo.getBytes(StandardCharsets.UTF_8),StandardOpenOption.CREATE,StandardOpenOption.APPEND);
            setStatus("Minecraft "+id+" launched with Java "+requiredJava+". Output: "+log.getAbsolutePath());        } catch(Exception ex){error("Could not launch: "+ex.getMessage());}
    }

    private static String normalizeGameDirectory(String configured) {
        File path = new File(configured == null || configured.trim().isEmpty() ? defaultGameDir() : configured).getAbsoluteFile();
        // Recover from a game directory accidentally saved as a version/profile folder.
        if ("versions".equals(path.getParentFile() == null ? "" : path.getParentFile().getName())) {
            File root = path.getParentFile().getParentFile();
            if (root != null && new File(root, "versions").isDirectory()) return root.getAbsolutePath();
        }
        return path.getAbsolutePath();
    }

    private static File instanceDirectoryForVersion(File root, String id) {
        // Keep the existing 26.3 Fabric performance-pack folder stable while
        // giving every other Minecraft profile its own independent game directory.
        String instanceId = id.startsWith("fabric-loader-") && id.endsWith("-26.3") ? "26.3-fabric" : id;
        return new File(root, "instances/" + instanceId);
    }

    private static List<String> asList(Object value) {
        return value instanceof List?(List<String>)value:Collections.<String>emptyList();
    }
    private static boolean containsToken(List<String> values,String token) {
        return values.contains(token);
    }
    private static void appendArguments(List<String> target,Object raw,Map<String,String> vars) throws IOException {
        if(!(raw instanceof List))return;
        for(Object entry:(List<?>)raw) {
            if(entry instanceof String) target.add(substitute((String)entry,vars));
            else if(entry instanceof Map) {
                Map<String,Object> conditional=asMap(entry);
                if(!rulesAllow(conditional.get("rules")))continue;
                Object value=conditional.get("value");
                if(value instanceof String)target.add(substitute((String)value,vars));
                else if(value instanceof List)for(Object part:(List<?>)value)if(part instanceof String)target.add(substitute((String)part,vars));
            }
        }
    }
    private static String substitute(String value,Map<String,String> vars) throws IOException {
        java.util.regex.Matcher matcher=java.util.regex.Pattern.compile("\\$\\{([^}]+)\\}").matcher(value);
        StringBuffer out=new StringBuffer();
        while(matcher.find()) {
            String replacement=vars.get(matcher.group(1));
            if(replacement==null)throw new IOException("Unsupported Minecraft launch variable: "+matcher.group(1));            matcher.appendReplacement(out,java.util.regex.Matcher.quoteReplacement(replacement));
        }
        matcher.appendTail(out); return out.toString();
    }
    private static List<String> splitLegacyArguments(String value) {
        List<String> result=new ArrayList<String>();
        java.util.regex.Matcher m=java.util.regex.Pattern.compile("\"([^\"]*)\"|'([^']*)'|\\S+").matcher(value);
        while(m.find())result.add(m.group(1)!=null?m.group(1):m.group(2)!=null?m.group(2):m.group());
        return result;
    }
    /** Extract the platform-native libraries declared by the version metadata.
     * Legacy Forge 1.8.9 requires LWJGL 2 native binaries on macOS; merely
     * adding the Java JARs to the classpath leaves OpenGL unavailable.
     */
    private static void extractNatives(File root, Map<String,Object> meta, File nativesDir) throws IOException {
        Object rawLibraries = meta.get("libraries");
        if (!(rawLibraries instanceof List)) return;
        String os = System.getProperty("os.name", "").toLowerCase(Locale.ROOT).contains("mac") ? "osx"
                : System.getProperty("os.name", "").toLowerCase(Locale.ROOT).contains("win") ? "windows" : "linux";
        for (Object raw : (List<?>) rawLibraries) {
            Map<String,Object> lib = asMap(raw);
            if (!rulesAllow(lib.get("rules"))) continue;
            Map<String,Object> nativeMap = asMap(lib.get("natives"));
            String classifier = string(nativeMap.get(os));
            if (classifier == null) continue;
            Map<String,Object> downloads = asMap(lib.get("downloads"));
            Map<String,Object> classifiers = asMap(downloads.get("classifiers"));
            Map<String,Object> artifact = asMap(classifiers.get(classifier));
            String relative = string(artifact.get("path"));
            if (relative == null) continue;
            File archive = new File(root, "libraries/" + relative);
            if (!archive.isFile()) throw new IOException("Missing native library " + relative + ". Reinstall the selected Minecraft version.");
            java.util.zip.ZipInputStream zip = new java.util.zip.ZipInputStream(new FileInputStream(archive));
            try {
                java.util.zip.ZipEntry entry;
                while ((entry = zip.getNextEntry()) != null) {
                    String name = entry.getName();
                    if (entry.isDirectory() || name.startsWith("META-INF/") || name.contains("../") || name.startsWith("/")) continue;
                    File output = new File(nativesDir, name);
                    if (!output.getCanonicalPath().startsWith(nativesDir.getCanonicalPath() + File.separator))
                        throw new IOException("Unsafe native library entry: " + name);
                    File parent = output.getParentFile();
                    if (!parent.isDirectory() && !parent.mkdirs()) throw new IOException("Could not create native directory: " + parent);
                    FileOutputStream stream = new FileOutputStream(output);
                    try { byte[] buffer = new byte[8192]; int count; while ((count = zip.read(buffer)) != -1) stream.write(buffer, 0, count); }
                    finally { stream.close(); }
                }
            } finally { zip.close(); }
        }
    }

    private static boolean libraryAllowed(Map<String,Object> library) {
        if(!rulesAllow(library.get("rules")))return false;
        String coordinate=string(library.get("name")); if(coordinate==null)return true;
        String[] parts=coordinate.split(":"); if(parts.length<4)return true;
        String classifier=parts[3].toLowerCase(Locale.ROOT), arch=System.getProperty("os.arch","").toLowerCase(Locale.ROOT);
        boolean arm=arch.contains("aarch64")||arch.contains("arm64");
        if(classifier.contains("arm64")||classifier.contains("aarch64"))return arm;
        if(classifier.contains("x86_64")||classifier.contains("amd64"))return !arm;
        if(classifier.startsWith("natives-") && (classifier.endsWith("-macos")||classifier.endsWith("-windows")||classifier.endsWith("-linux")))return !arm;
        return true;
    }
    private static boolean rulesAllow(Object raw) {
        if(!(raw instanceof List))return true;
        boolean allowed=false;
        for(Object item:(List<?>)raw) {
            Map<String,Object> rule=asMap(item);
            if(!ruleMatches(rule))continue;
            allowed="allow".equals(string(rule.get("action")));
        }
        return allowed;
    }
    private static boolean ruleMatches(Map<String,Object> rule) {
        Map<String,Object> os=asMap(rule.get("os"));
        if(!os.isEmpty()) {
            String name=string(os.get("name"));
            String current=System.getProperty("os.name","").toLowerCase(Locale.ROOT);
            String normalized=current.contains("mac")?"osx":current.contains("win")?"windows":current.contains("linux")?"linux":"unknown";
            if(name!=null&&!name.equals(normalized))return false;
            String arch=string(os.get("arch"));
            if(arch!=null&&!java.util.regex.Pattern.compile(arch).matcher(System.getProperty("os.arch","")).matches())return false;
            String version=string(os.get("version"));
            if(version!=null&&!java.util.regex.Pattern.compile(version).matcher(System.getProperty("os.version","")).find())return false;
        }
        Map<String,Object> features=asMap(rule.get("features"));
        for(Map.Entry<String,Object> feature:features.entrySet()) {
            // Winter Client currently exposes no optional launcher feature flags.
            if(Boolean.TRUE.equals(feature.getValue()))return false;
        }
        return true;
    }
    private static String mavenPath(String coordinate) {
        if(coordinate==null)return null;
        String[] p=coordinate.split(":"); if(p.length<3)return null;
        String extension="jar"; int at=p[2].indexOf('@');
        if(at>=0){extension=p[2].substring(at+1);p[2]=p[2].substring(0,at);}
        StringBuilder path=new StringBuilder(p[0].replace('.','/')).append('/').append(p[1]).append('/').append(p[2]).append('/').append(p[1]).append('-').append(p[2]);
        if(p.length>3)path.append('-').append(p[3]);
        return path.append('.').append(extension).toString();
    }
    private Map<String,Object> loadMetadata(File root,String id,Set<String> seen) throws Exception {
        if(!seen.add(id))throw new IOException("Circular version inheritance: "+id);
        File file=new File(root,"versions/"+id+"/"+id+".json");
        if(!file.isFile())throw new IOException("Missing version metadata: "+file);
        Map<String,Object> child=object(new Json(new String(Files.readAllBytes(file.toPath()),StandardCharsets.UTF_8)).parse());
        String parentId=string(child.get("inheritsFrom"));
        if(parentId==null){child.put("_frostBaseVersion",id);return child;}
        Map<String,Object> parent=loadMetadata(root,parentId,seen);

        LinkedHashMap<String,Object> mergedLibraries = new LinkedHashMap<String,Object>();
        Object parentLibs=parent.get("libraries"),childLibs=child.get("libraries");
        if(parentLibs instanceof List) for(Object lib:(List<?>)parentLibs) mergedLibraries.put(libraryKey(lib),lib);
        if(childLibs instanceof List) for(Object lib:(List<?>)childLibs) mergedLibraries.put(libraryKey(lib),lib);
        List<Object> combined = new ArrayList<Object>(mergedLibraries.values());
        String base=string(parent.get("_frostBaseVersion"));
        parent.putAll(child);
        parent.put("libraries",combined);
        parent.put("_frostBaseVersion",base==null?parentId:base);
        return parent;    }
    private static String libraryKey(Object value) {
        String coordinate = string(asMap(value).get("name"));
        if (coordinate == null) return String.valueOf(value);
        String[] parts = coordinate.split(":");
        if (parts.length < 3) return coordinate;
        String classifier = parts.length > 3 ? parts[3] : "";
        int at = parts[2].indexOf('@');
        String extension = at >= 0 ? parts[2].substring(at + 1) : "jar";
        return parts[0] + ":" + parts[1] + ":" + classifier + "@" + extension;
    }

    private static String join(List<String> a,String sep){StringBuilder b=new StringBuilder();for(String s:a){if(b.length()>0)b.append(sep);b.append(s);}return b.toString();}
    private void chooseFile(JTextField t){JFileChooser f=new JFileChooser();if(f.showOpenDialog(frame)==JFileChooser.APPROVE_OPTION)t.setText(f.getSelectedFile().getAbsolutePath());}
    private void chooseDirectory(JTextField t){JFileChooser f=new JFileChooser();f.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);if(f.showOpenDialog(frame)==JFileChooser.APPROVE_OPTION)t.setText(f.getSelectedFile().getAbsolutePath());}
    private void openSubfolder(String child){String selected=(String)profile.getSelectedItem();File base=selected==null?new File(gameDir.getText()):instanceDirectoryForVersion(new File(gameDir.getText()),selected);File f=new File(base,child);if(!f.exists())f.mkdirs();openPath(f);}    private void openPath(File f){try{if(!f.exists())f.mkdirs();Desktop.getDesktop().open(f);}catch(Exception e){error(e.getMessage());}}    private void setStatus(String s){status.setText(s);}
    private void error(String s){setStatus(s);JOptionPane.showMessageDialog(frame,s,"Winter Client",JOptionPane.ERROR_MESSAGE);}
    private void loadSettings(){try{if(settingsFile.isFile()){FileInputStream in=new FileInputStream(settingsFile);settings.load(in);in.close();}}catch(Exception ignored){}}
    private void saveSettings(){try{settingsFile.getParentFile().mkdirs();settings.setProperty("username",username.getText());settings.setProperty("java",javaPath.getText());settings.setProperty("javaMode",javaMode.getSelectedIndex()==1?"manual":"auto");settings.setProperty("gameDir",gameDir.getText());settings.setProperty("memory",String.valueOf(memory.getValue()));settings.setProperty("profile",String.valueOf(profile.getSelectedItem()));FileOutputStream out=new FileOutputStream(settingsFile);settings.store(out,"Winter Client settings");out.close();}catch(Exception e){setStatus("Settings save failed: "+e.getMessage());}}
    private static int requiredJavaMajor(Map<String,Object> meta,String id) {
        Object javaVersion=meta.get("javaVersion");
        Object major=asMap(javaVersion).get("majorVersion");
        if(major instanceof Number) return ((Number)major).intValue();
        // Older metadata may omit javaVersion. Use Mojang's historical runtime mapping.
        try {
            String v=id.startsWith("1.")?id.substring(2):id;
            String[] p=v.split("\\.");
            int minor=Integer.parseInt(p[0]);            if(minor<=16)return 8;
            if(minor==17)return 16;
            if(minor==18 || minor==19 || minor==20 && (p.length<2 || Integer.parseInt(p[1])<=4))return 17;
            if(minor==20 || minor==21)return 21;
            if(minor>=26)return 25;
        } catch(Exception ignored) { }
        return 8;
    }
    private static String findJava(int major) {
        String os=System.getProperty("os.name").toLowerCase(Locale.ROOT);
        List<String> candidates=new ArrayList<String>();
        String configuredHome=System.getenv("JAVA_HOME");
        if(configuredHome!=null&&!configuredHome.trim().isEmpty()) {
            File home=new File(configuredHome.trim());
            candidates.add(new File(home,"bin"+File.separator+(os.contains("win")?"java.exe":"java")).getAbsolutePath());
        }
        if(os.contains("mac")) {
            // Prefer the user's existing Temurin Java 8 runtime for legacy Minecraft 1.8.9.
            if(major==8) {
                File temurin8=new File("/Library/Java/JavaVirtualMachines/temurin-8.jdk/Contents/Home/bin/java");
                if(temurin8.isFile()&&temurin8.canExecute())candidates.add(temurin8.getAbsolutePath());
            }
            
            try {

                String javaHomeVersion=String.valueOf(major);
                Process process=new ProcessBuilder("/usr/libexec/java_home","-v",javaHomeVersion).redirectErrorStream(true).start();
                BufferedReader reader=new BufferedReader(new InputStreamReader(process.getInputStream(),"UTF-8"));
                String home=reader.readLine();
                int exit=process.waitFor();
                if(exit==0&&home!=null&&!home.trim().isEmpty())candidates.add(new File(home.trim(),"bin/java").getAbsolutePath());
            } catch(Exception ignored) { }
            File[] roots={new File("/Library/Java/JavaVirtualMachines"),new File(System.getProperty("user.home"),"Library/Java/JavaVirtualMachines")};
            for(File root:roots) {
                File[] installed=root.listFiles();
                if(installed!=null)for(File home:installed) {
                    File executable=new File(home,"Contents/Home/bin/java");
                    if(executable.isFile()&&executable.canExecute())candidates.add(executable.getAbsolutePath());
                }
            }
            // Keep the legacy browser-plugin runtime as a last-resort Java 8 candidate.
            File pluginJava=new File("/Library/Internet Plug-Ins/JavaAppletPlugin.plugin/Contents/Home/bin/java");
            if(pluginJava.isFile()&&pluginJava.canExecute())candidates.add(pluginJava.getAbsolutePath());
        } else {
            String executable=os.contains("win")?"java.exe":"java";
            String path=System.getenv("PATH");
            if(path!=null)for(String directory:path.split(java.util.regex.Pattern.quote(File.pathSeparator)))
                candidates.add(new File(directory,executable).getAbsolutePath());
            File current=new File(System.getProperty("java.home"),"bin"+File.separator+executable);
            candidates.add(current.getAbsolutePath());
        }
        // De-duplicate while preserving preference order (JAVA_HOME, java_home, JDK bundles, then plugin/PATH).
        Set<String> unique=new LinkedHashSet<String>(candidates);
        for(String candidate:unique) {
            File executable=new File(candidate);
            if(!executable.isFile()||!executable.canExecute())continue;
            try {
                Process process=new ProcessBuilder(candidate,"-version").redirectErrorStream(true).start();
                BufferedReader reader=new BufferedReader(new InputStreamReader(process.getInputStream(),"UTF-8"));
                StringBuilder output=new StringBuilder(); String line;
                while((line=reader.readLine())!=null)output.append(line).append('\n');
                int exit=process.waitFor();
                java.util.regex.Matcher matcher=java.util.regex.Pattern.compile("version\\s+\"(?:1\\.)?([0-9]+)").matcher(output.toString());                if(exit==0&&matcher.find()&&Integer.parseInt(matcher.group(1))==major)return executable.getAbsolutePath();
            } catch(Exception ignored) { }
        }
        return null;
    }    private static String defaultJava(){String java8=findJava(8);return java8!=null?java8:System.getProperty("java.home")+"/bin/java";}
    private static String defaultGameDir(){String os=System.getProperty("os.name").toLowerCase(Locale.ROOT);if(os.contains("mac"))return System.getProperty("user.home")+"/Library/Application Support/minecraft";if(os.contains("win"))return System.getenv("APPDATA")+"\\\\.minecraft";return System.getProperty("user.home")+"/.minecraft";}    @SuppressWarnings("unchecked") private static Map<String,Object> object(Object o){return (Map<String,Object>)o;}    @SuppressWarnings("unchecked") private static Map<String,Object> asMap(Object o){return o instanceof Map?(Map<String,Object>)o:Collections.<String,Object>emptyMap();}
    private static String string(Object o){return o instanceof String?(String)o:null;}
    static final class Json {
        private final String s;private int i;Json(String s){this.s=s;}
        Object parse(){Object v=value();ws();if(i!=s.length())throw new IllegalArgumentException("Trailing JSON");return v;}
        private Object value(){ws();if(i>=s.length())throw new IllegalArgumentException("Unexpected end of JSON");char c=s.charAt(i);if(c=='{')return obj();if(c=='[')return arr();if(c=='"')return str();if(c=='t'){i+=4;return Boolean.TRUE;}if(c=='f'){i+=5;return Boolean.FALSE;}if(c=='n'){i+=4;return null;}return num();}
        private Map<String,Object> obj(){Map<String,Object> m=new LinkedHashMap<String,Object>();i++;ws();if(take('}'))return m;do{ws();String k=str();ws();need(':');m.put(k,value());ws();if(take('}'))return m;need(',');}while(true);}
        private List<Object> arr(){List<Object>a=new ArrayList<Object>();i++;ws();if(take(']'))return a;do{a.add(value());ws();if(take(']'))return a;need(',');}while(true);}
        private String str(){need('"');StringBuilder b=new StringBuilder();while(i<s.length()){char c=s.charAt(i++);if(c=='"')return b.toString();if(c=='\\'){char e=s.charAt(i++);switch(e){case '"':case '\\':case '/':b.append(e);break;case 'b':b.append('\b');break;case 'f':b.append('\f');break;case 'n':b.append('\n');break;case 'r':b.append('\r');break;case 't':b.append('\t');break;case 'u':b.append((char)Integer.parseInt(s.substring(i,i+4),16));i+=4;break;default:throw new IllegalArgumentException("Bad escape");}}else b.append(c);}throw new IllegalArgumentException("Unclosed string");}
        private Number num(){int start=i;while(i<s.length()&&"-+0123456789.eE".indexOf(s.charAt(i))>=0)i++;String n=s.substring(start,i);try{return n.indexOf('.')>=0?Double.valueOf(n):Long.valueOf(n);}catch(Exception e){throw new IllegalArgumentException("Bad number");}}
        private void ws(){while(i<s.length()&&Character.isWhitespace(s.charAt(i)))i++;}
        private boolean take(char c){if(i<s.length()&&s.charAt(i)==c){i++;return true;}return false;}
        private void need(char c){if(!take(c))throw new IllegalArgumentException("Expected "+c+" at "+i);}
    }
}
