package com.frostclient;

import java.io.File;
import java.util.List;

/** Network smoke test for official Mojang metadata and the official Forge installer artifact. */
public final class VersionInstallerSmokeTest {
    public static void main(String[] args) throws Exception {
        File temp = new File("launcher/build/smoke-game");
        VersionInstaller installer = new VersionInstaller(temp);
        List<String> releases = installer.listReleases();
        if (!releases.contains("1.8.9")) throw new AssertionError("Mojang manifest does not contain 1.8.9");
        installer.installVanilla("1.8.9", s -> System.out.println(s));
        File vanilla = new File(temp, "versions/1.8.9/1.8.9.jar");
        if (!vanilla.isFile() || vanilla.length() < 1000000) throw new AssertionError("Minecraft 1.8.9 client JAR was not installed.");
        System.out.println("Vanilla 1.8.9 installed and verified.");
        File forge = installer.downloadForgeInstaller(s -> System.out.println(s));
        if (!forge.isFile() || forge.length() < 1000000) throw new AssertionError("Forge installer download is missing or unexpectedly small.");
        System.out.println("Forge installer downloaded: " + forge.length() + " bytes at " + forge.getPath());    }
}
