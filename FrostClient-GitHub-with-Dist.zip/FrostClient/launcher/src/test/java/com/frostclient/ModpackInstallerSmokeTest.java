package com.frostclient;

import java.io.*;
import java.nio.file.*;
import java.util.zip.*;

public final class ModpackInstallerSmokeTest {
    public static void main(String[] args) throws Exception {
        File temp = Files.createTempDirectory("winter-modpack-test").toFile();
        File versions = new File(temp, "versions/1.20.1");
        if (!versions.mkdirs()) throw new AssertionError("Could not create test version");
        Files.write(new File(versions, "1.20.1.json").toPath(), "{}".getBytes("UTF-8"));

        File zip = new File(temp, "sample.zip");
        try (ZipOutputStream out = new ZipOutputStream(new FileOutputStream(zip))) {
            add(out, "SamplePack/mods/example.jar", "mod-data");
            add(out, "SamplePack/config/options.txt", "options");
            add(out, "SamplePack/notes.txt", "ignored");
            add(out, "SamplePack/../escape.jar", "blocked");
        }
        File instance = new ModpackInstaller(temp).importModpack(zip, "1.20.1", s -> {});
        if (!new File(instance, "mods/example.jar").isFile()) throw new AssertionError("Mod JAR was not imported");
        if (!new File(instance, "config/options.txt").isFile()) throw new AssertionError("Config was not imported");
        if (new File(temp, "escape.jar").exists()) throw new AssertionError("ZIP traversal escaped instance");
        if (!new File(instance, ".winter-modpack-instance").isFile()) throw new AssertionError("Instance marker missing");

        File secondZip = new File(temp, "second.zip");
        try (ZipOutputStream out = new ZipOutputStream(new FileOutputStream(secondZip))) {
            add(out, "mods/example.jar", "replacement");
        }
        new ModpackInstaller(temp).importModpack(secondZip, "1.20.1", s -> {});
        if (!new File(instance, "mods/example.modpack-1.jar").isFile()) throw new AssertionError("Existing mod was overwritten instead of preserved");

        File mrpack = new File(temp, "sample.mrpack");
        try (ZipOutputStream out = new ZipOutputStream(new FileOutputStream(mrpack))) {
            add(out, "modrinth.index.json", "{\"formatVersion\":1,\"game\":\"minecraft\",\"versionId\":\"test\",\"name\":\"Test\",\"summary\":\"\",\"files\":[],\"dependencies\":{\"minecraft\":\"1.20.1\",\"fabric-loader\":\"0.16.9\"}}");
            add(out, "overrides/config/test.txt", "mrpack-config");
        }
        File fabricVersion = new File(temp, "versions/fabric-loader-0.16.9-1.20.1");
        if (!fabricVersion.mkdirs()) throw new AssertionError("Could not create Fabric test profile");
        Files.write(new File(fabricVersion, "fabric-loader-0.16.9-1.20.1.json").toPath(), "{}".getBytes("UTF-8"));
        File fabricInstance = new ModpackInstaller(temp).importModpack(mrpack, "fabric-loader-0.16.9-1.20.1", s -> {});
        if (!new File(fabricInstance, "config/test.txt").isFile()) throw new AssertionError("Modrinth overrides were not imported");

        System.out.println("Modpack import smoke tests passed.");
    }

    private static void add(ZipOutputStream out, String name, String value) throws Exception {
        out.putNextEntry(new ZipEntry(name));
        out.write(value.getBytes("UTF-8"));
        out.closeEntry();
    }
}
