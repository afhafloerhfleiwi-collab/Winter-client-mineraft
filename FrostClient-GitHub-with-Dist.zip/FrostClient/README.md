# Winter Client

Winter Client is an independently written Minecraft Java Edition 1.8.9 PvP launcher and client-side mod project. The launcher is a standalone Java Swing application; it is **not based on HMCL**.

## Launcher

The original launcher source is in `launcher/src/main/java/com/frostclient/Launcher.java`.

Current launcher capabilities:
- Scans local Minecraft version profiles.
- Configures player name, Java executable, game directory and memory allocation.
- Saves settings locally and opens the game/mods folders.
- Lists official Mojang release versions.
- Installs vanilla versions by downloading the Mojang version JSON, client JAR, libraries, native libraries and asset objects, validating SHA-1 hashes.
- Downloads the official Forge 1.8.9 installer (11.15.1.2318) from the Forge Maven repository, verifies its published SHA-1 file, and opens the official installer after confirmation.

Build the runnable launcher JAR (JDK 8 or newer):

```bash
./scripts/build-launcher.sh
```

Output: `dist/WinterClient.jar`.

**Account sign-in:** The Account Manager supports Microsoft Java Edition authentication and LittleSkin Yggdrasil authentication. For Microsoft, save/select a Microsoft account, press **SIGN IN**, complete the browser login, then paste the full redirect URL when prompted. Winter Client exchanges the authorization code through Xbox Live, XSTS and Minecraft Services, verifies Java Edition entitlement, and fetches the Minecraft profile. For LittleSkin, choose the LittleSkin account type, enter your account email and API root, press **SIGN IN**, and enter your password in the password prompt. If multiple player profiles are available, choose one. Passwords and access tokens are not written to launcher.properties; authenticated sessions exist only in memory, so sign in again after restarting the launcher. LittleSkin launch downloads and validates authlib-injector into `~/.frostclient` and uses the configured Yggdrasil API root. Never paste passwords or tokens into issue reports or logs. The Microsoft browser redirect URL contains a temporary authorization code; paste it only into Winter Client. Offline / Cracked accounts still work only on offline-mode servers and cannot authenticate to premium online-mode servers. Live sign-in and multiplayer joining still require testing with real accounts. Forge profile creation is completed in the official Forge installer window: choose **Install client**, check the target game directory, and click OK. Complex Forge-specific runtime edge cases still need in-game testing.

## WinterHUD

Build the original Forge 1.8.9 mod (requires JDK 8; downloads Gradle 2.14.1 on first run):

```bash
./scripts/build-frosthud.sh
```

Output: `dist/mods/WinterHUD-1.0.0.jar`. The mod provides FPS/CPS, keystrokes, armor and potion HUDs, toggle sprint, zoom, HUD toggle and perspective cycling. It still needs an in-game smoke test.

### Forge 1.8.9 performance add-ons

WinterHUD's **FPS MOD STATUS / RECOMMENDATIONS** page (open WinterHUD settings with `O`) detects these separately installed client mods; it does not bundle or dynamically enable third-party code:

- **FoamFix** — memory and targeted modded-game optimizations.
- **BetterFPS** — small algorithmic optimizations; test its algorithm options individually.
- **PolyPatcher** — Forge 1.8.9 client fixes and performance features.
- **Nothirium 1.8.9 port** — optional modern-OpenGL chunk renderer; requires RenderLib 1.4.5 and ConfigurationsBackport. Test separately, especially on older Intel graphics.
- **Entity Culling 1.8.9 port** — skips rendering hidden entities/tile entities; requires RenderLib 1.4.5 and ConfigurationsBackport. Test separately.

These are independent `.jar` files placed in the Forge 1.8.9 `mods` folder. Do not install every renderer mod at once; add one, launch, and test before adding another. References: [Forge 1.8.9 performance list](https://github.com/JediByte/MCOptiMods/blob/main/Performance/Performance189.md), [PolyPatcher](https://github.com/Polyfrost/PolyPatcher), [Nothirium 1.8.9 port](https://modrinth.com/mod/nothirium-1.8.9-port), [Entity Culling 1.8.9 port](https://modrinth.com/mod/entityculling-1.8.9-port).

## Low-end Mac starting settings

- Use 64-bit Java 8 for Minecraft 1.8.9.
- Start with 1.5–2 GB maximum heap on an 8 GB machine.
- Render distance 6, Fast graphics, minimum/off smooth lighting, clouds off, minimal particles and entity shadows off.
- Start with a 60 FPS cap; test higher only if temperatures and frame pacing remain stable.
- OptiFine is optional and must be downloaded manually from [its official site](https://optifine.net/downloads). It is not bundled.

Winter Client does not bundle Minecraft game files, account data, OptiFine or third-party mod binaries. It is not affiliated with Mojang or Microsoft.
