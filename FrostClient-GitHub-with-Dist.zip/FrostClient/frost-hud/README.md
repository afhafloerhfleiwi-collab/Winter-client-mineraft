# WinterHUD (Minecraft Forge 1.8.9)

Original, client-side Forge mod source for Winter Client. Features: FPS/CPS text, WASD + mouse keystrokes, armor durability percentages, potion timers, toggle sprint (G), zoom (C), HUD toggle (H), and perspective cycling (P). Key names are localized in English and Simplified Chinese.

## Build

This legacy ForgeGradle 2.1 project requires **JDK 8**. From the project root, run:

```bash
./scripts/build-frosthud.sh
```

The script locates a JDK 8 with `javac`, downloads Gradle 2.14.1 on first use, and builds against Forge 1.8.9-11.15.1.2318. Output: `dist/mods/WinterHUD-1.0.0.jar`.

The mod compiled successfully, but still needs an in-game smoke test with the exact Forge/Java 8 runtime. It is not a cheat: it does not automate attacks, alter reach, or manipulate packets.
