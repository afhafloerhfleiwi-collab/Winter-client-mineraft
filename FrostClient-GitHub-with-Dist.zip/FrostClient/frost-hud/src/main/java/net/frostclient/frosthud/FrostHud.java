package net.frostclient.frosthud;

import java.util.ArrayDeque;
import java.util.Deque;
import java.io.File;
import java.io.FileInputStream;
import java.util.Properties;
import net.minecraft.client.renderer.GlStateManager;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.item.ItemStack;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import net.minecraftforge.fml.client.registry.ClientRegistry;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.client.event.FOVUpdateEvent;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraftforge.event.entity.player.AttackEntityEvent;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.entity.Entity;
import net.minecraft.client.renderer.RenderGlobal;
import org.lwjgl.opengl.GL11;import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.FMLCommonHandler;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import net.minecraftforge.fml.common.gameevent.InputEvent.MouseInputEvent;
import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;

/** Lightweight client-side PvP HUD and controls for Minecraft 1.8.9. */
@Mod(modid = FrostHud.MOD_ID, name = "WinterHUD", version = "1.0.0", clientSideOnly = true)
public final class FrostHud {
    public static final String MOD_ID = "frosthud";
    final Minecraft mc = Minecraft.getMinecraft();
    private final Deque<Long> leftClicks = new ArrayDeque<Long>();
    private final Deque<Long> rightClicks = new ArrayDeque<Long>();
    private KeyBinding toggleSprintKey;
    private KeyBinding zoomKey;
    private KeyBinding hudKey;
    private KeyBinding perspectiveKey;
    private KeyBinding settingsKey;
    boolean toggleSprint;
    boolean zoom;
    boolean hudVisible = true;
    float previousFov = 70.0F;
    private int ticks;
    boolean showFps=true, showCps=true, showKeys=true, showArmor=true, showPotions=true;
    boolean sprintEnabled=true, zoomEnabled=true, perspectiveEnabled=true;    String anchor="TOP_LEFT";
    int offsetX=6, offsetY=6, opacity=100;
    float hudScale=1.0F;
    int performancePreset=0; boolean dynamicFov=false;    boolean blockColorEnabled=true, hitColorEnabled=true, hitboxesEnabled=false;
    int blockColor=0xFF45D7F5, hitColor=0xFFFF5577, hitboxColor=0xFF55FF99;
    float blockOpacity=0.75F, hitOpacity=0.9F, hitboxOpacity=0.85F, hitboxLineWidth=1.5F;
    int lastHitEntityId=-1, hitColorTicks=0;

    /** Register client-only key bindings and Forge event listeners. */
    @Mod.EventHandler
    public void init(FMLInitializationEvent event) {
        toggleSprintKey = new KeyBinding("key.frosthud.toggle_sprint", Keyboard.KEY_G, "key.categories.frosthud");
        zoomKey = new KeyBinding("key.frosthud.zoom", Keyboard.KEY_C, "key.categories.frosthud");
        hudKey = new KeyBinding("key.frosthud.toggle_hud", Keyboard.KEY_H, "key.categories.frosthud");
        perspectiveKey = new KeyBinding("key.frosthud.perspective", Keyboard.KEY_P, "key.categories.frosthud");
        settingsKey = new KeyBinding("key.frosthud.settings", Keyboard.KEY_O, "key.categories.frosthud");
        ClientRegistry.registerKeyBinding(toggleSprintKey);
        ClientRegistry.registerKeyBinding(zoomKey);
        ClientRegistry.registerKeyBinding(hudKey);
        ClientRegistry.registerKeyBinding(perspectiveKey);
        ClientRegistry.registerKeyBinding(settingsKey);
        MinecraftForge.EVENT_BUS.register(this);
        FMLCommonHandler.instance().bus().register(this);
        loadConfig();
    }
    /** Process toggles once per client tick and apply hold-to-zoom state. */
    @SubscribeEvent
    public void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        if (++ticks % 40 == 0) loadConfig();
        boolean shouldZoom=zoomEnabled && mc.thePlayer!=null && mc.currentScreen==null && zoomKey!=null && Keyboard.isKeyDown(zoomKey.getKeyCode());
        if (shouldZoom && !zoom) { previousFov=mc.gameSettings.fovSetting; zoom=true; }
        if (zoom) {
            if (shouldZoom) mc.gameSettings.fovSetting=25.0F;
            else { mc.gameSettings.fovSetting=previousFov; zoom=false; }
        }
        if (mc.thePlayer == null) return;
        while (settingsKey.isPressed()) mc.displayGuiScreen(new FrostHudConfigScreen(this));
        if (sprintEnabled) while (toggleSprintKey.isPressed()) toggleSprint = !toggleSprint;
        else toggleSprint = false;
        while (hudKey.isPressed()) hudVisible = !hudVisible;
        if (perspectiveEnabled) while (perspectiveKey.isPressed()) mc.gameSettings.thirdPersonView = (mc.gameSettings.thirdPersonView + 1) % 3;
        if (toggleSprint) {
            boolean moving = mc.thePlayer.movementInput != null &&
                    (mc.thePlayer.movementInput.moveForward != 0.0F || mc.thePlayer.movementInput.moveStrafe != 0.0F);
            mc.thePlayer.setSprinting(moving && mc.thePlayer.getFoodStats().getFoodLevel() > 6);
        }
        prune(leftClicks);
        prune(rightClicks);
    }

    /** Optionally restore vanilla sprint FOV changes. */
    @SubscribeEvent
    public void onFovUpdate(FOVUpdateEvent event) {
        if (!dynamicFov && mc.thePlayer != null) event.newfov = 1.0F;
    }
    @SubscribeEvent
    public void onAttackEntity(AttackEntityEvent event) {
        if(event.target!=null && mc.thePlayer!=null && event.target!=mc.thePlayer){lastHitEntityId=event.target.getEntityId();hitColorTicks=8;}
    }
    @SubscribeEvent
    public void onWorldRender(RenderWorldLastEvent event) {
        if(mc.thePlayer==null||mc.theWorld==null)return;
        Entity view=mc.getRenderViewEntity();if(view==null)return;
        double x=view.lastTickPosX+(view.posX-view.lastTickPosX)*event.partialTicks;
        double y=view.lastTickPosY+(view.posY-view.lastTickPosY)*event.partialTicks;
        double z=view.lastTickPosZ+(view.posZ-view.lastTickPosZ)*event.partialTicks;
        GlStateManager.pushMatrix();GlStateManager.disableTexture2D();GlStateManager.enableBlend();GlStateManager.tryBlendFuncSeparate(770,771,1,0);GlStateManager.disableDepth();GlStateManager.depthMask(false);GlStateManager.disableLighting();
        if(blockColorEnabled&&mc.objectMouseOver!=null&&mc.objectMouseOver.typeOfHit==MovingObjectPosition.MovingObjectType.BLOCK){net.minecraft.util.BlockPos pos=mc.objectMouseOver.getBlockPos();AxisAlignedBB box=mc.theWorld.getBlockState(pos).getBlock().getSelectedBoundingBox(mc.theWorld,pos);if(box!=null){GL11.glLineWidth(2.0F);drawOutline(box.offset(-x,-y,-z),blockColor,blockOpacity);}}
        if(hitboxesEnabled||(hitColorEnabled&&hitColorTicks>0))for(Object obj:mc.theWorld.loadedEntityList){Entity entity=(Entity)obj;if(entity==mc.thePlayer||entity.isDead)continue;boolean hit=hitColorEnabled&&entity.getEntityId()==lastHitEntityId&&hitColorTicks>0;if(!hitboxesEnabled&&!hit)continue;GL11.glLineWidth(hit?2.5F:hitboxLineWidth);drawOutline(entity.getEntityBoundingBox().expand(0.02D,0.02D,0.02D).offset(-x,-y,-z),hit?hitColor:hitboxColor,hit?hitOpacity:hitboxOpacity);}
        GlStateManager.color(1,1,1,1);GlStateManager.depthMask(true);GlStateManager.enableDepth();GlStateManager.disableBlend();GlStateManager.enableTexture2D();GlStateManager.popMatrix();if(hitColorTicks>0)hitColorTicks--;
    }
    private void drawOutline(AxisAlignedBB box,int color,float alpha){RenderGlobal.drawOutlinedBoundingBox(box,(color>>16)&255,(color>>8)&255,color&255,Math.round(Math.max(0.0F,Math.min(1.0F,alpha))*255.0F));}    @SubscribeEvent
    public void onMouse(MouseInputEvent event) {
        if (!Mouse.getEventButtonState()) return;
        long now = System.currentTimeMillis();
        if (Mouse.getEventButton() == 0) leftClicks.addLast(now);
        if (Mouse.getEventButton() == 1) rightClicks.addLast(now);
    }

    /** Draw a compact, dark client-style HUD with cyan accents. */
    @SubscribeEvent
    public void onOverlay(RenderGameOverlayEvent.Post event) {
        if (event.type != RenderGameOverlayEvent.ElementType.ALL || mc.thePlayer == null || !hudVisible) return;
        int width=event.resolution.getScaledWidth(), height=event.resolution.getScaledHeight();
        boolean left=anchor.endsWith("LEFT"), top=anchor.startsWith("TOP");
        int x=left?offsetX:width-offsetX-154, y=top?offsetY:height-offsetY-100;
        int keyX=left?width-offsetX-78:offsetX, keyY=top?height-offsetY-66:offsetY;
        GlStateManager.pushMatrix();
        GlStateManager.translate(x,y,0.0F); GlStateManager.scale(hudScale,hudScale,1.0F);
        int a=opacity*255/100;
        int panel=(a<<24)|0x101722, panel2=(a<<24)|0x172331;
        int accent=(a<<24)|0x45D7F5, white=(a<<24)|0xF1F6FA, muted=(a<<24)|0x9AAAB8;
        Gui.drawRect(0,0,154,showArmor||showPotions?100:42,panel);
        Gui.drawRect(0,0,154,2,accent);        mc.fontRendererObj.drawString("W I N T E R",8,7,accent,false);
        
        mc.fontRendererObj.drawString("1.8.9  /  PVP",98,7,muted,false);
        Gui.drawRect(8,20,146,21,panel2);
        if(showFps) {
            mc.fontRendererObj.drawString("FPS",8,27,muted,false);
            mc.fontRendererObj.drawStringWithShadow(String.valueOf(Minecraft.getDebugFPS()),8,38,0xFFFFFFFF);
        }
        if(showCps) {
            mc.fontRendererObj.drawString("CPS",58,27,muted,false);
            mc.fontRendererObj.drawStringWithShadow("L "+leftClicks.size()+"   R "+rightClicks.size(),58,38,0xFFFFFFFF);
        }
        if(showArmor) drawArmor(8,56);
        if(showPotions) drawPotions(8,78);
        GlStateManager.popMatrix();
        if(showKeys) drawKeystrokes(keyX,keyY);
    }
    private void drawKeystrokes(int x, int y) {
        drawKey(x + 24, y, "W", Keyboard.isKeyDown(Keyboard.KEY_W));
        drawKey(x, y + 22, "A", Keyboard.isKeyDown(Keyboard.KEY_A));
        drawKey(x + 24, y + 22, "S", Keyboard.isKeyDown(Keyboard.KEY_S));
        drawKey(x + 48, y + 22, "D", Keyboard.isKeyDown(Keyboard.KEY_D));
        drawKey(x, y + 46, "LMB", Mouse.isButtonDown(0));
        drawKey(x + 38, y + 46, "RMB", Mouse.isButtonDown(1));
    }

    private void drawKey(int x, int y, String label, boolean pressed) {
        int alpha=opacity*255/100;
        int bg=(alpha<<24)|(pressed?0x164B60:0x101722);
        Gui.drawRect(x,y,x+34,y+19,bg);
        Gui.drawRect(x,y,x+34,y+1,(alpha<<24)|(pressed?0x45D7F5:0x293B4C));
        int textX=x+(34-mc.fontRendererObj.getStringWidth(label))/2;
        mc.fontRendererObj.drawString(label,textX,y+6,pressed?0xFFFFFF:0xAFC0CF,false);
    }
    private void drawArmor(int x, int y) {
        mc.fontRendererObj.drawString("ARMOR",x,y,(opacity*255/100<<24)|0x9AAAB8,false);
        int offset=0;
        for(int i=3;i>=0;i--) {
            ItemStack stack=mc.thePlayer.inventory.armorInventory[i];
            if(stack!=null && stack.isItemStackDamageable()) {
                int max=stack.getMaxDamage();
                int percent=max<=0?100:(max-stack.getItemDamage())*100/max;
                int color=percent>60?0x55E69A:(percent>25?0xFFD166:0xFF647C);
                Gui.drawRect(x+offset,y+12,x+offset+25,y+15,(opacity*255/100<<24)|0x293B4C);
                Gui.drawRect(x+offset,y+12,x+offset+25*percent/100,y+15,(opacity*255/100<<24)|(color&0xFFFFFF));
                mc.fontRendererObj.drawString(percent+"%",x+offset,y+18,(opacity*255/100<<24)|(color&0xFFFFFF),false);
            }
            offset+=34;
        }
    }

    private void drawPotions(int x,int y) {
        int line=0;
        for(Object object:mc.thePlayer.getActivePotionEffects()) {
            PotionEffect effect=(PotionEffect)object;
            Potion potion=Potion.potionTypes[effect.getPotionID()];
            if(potion!=null) {
                String name=potion.getName().replace("potion.","").toUpperCase()+" "+(effect.getAmplifier()+1);
                String duration=Potion.getDurationString(effect);
                mc.fontRendererObj.drawString(name,x,y+line*10,(opacity*255/100<<24)|0xDCE7F0,false);
                int dw=mc.fontRendererObj.getStringWidth(duration);
                mc.fontRendererObj.drawString(duration,x+138-dw,y+line*10,(opacity*255/100<<24)|0x45D7F5,false);
                line++;
                if(line==2)break;
            }
        }
    }
    void applyPerformancePreset() {
        if(performancePreset==0) { mc.gameSettings.renderDistanceChunks=6; mc.gameSettings.fancyGraphics=false; mc.gameSettings.clouds=1; mc.gameSettings.particleSetting=1; mc.gameSettings.entityShadows=false; mc.gameSettings.enableVsync=false; mc.gameSettings.ambientOcclusion=0; mc.gameSettings.mipmapLevels=1; }
        else if(performancePreset==1) { mc.gameSettings.renderDistanceChunks=4; mc.gameSettings.fancyGraphics=false; mc.gameSettings.clouds=0; mc.gameSettings.particleSetting=2; mc.gameSettings.entityShadows=false; mc.gameSettings.enableVsync=false; mc.gameSettings.ambientOcclusion=0; mc.gameSettings.mipmapLevels=0; }
        else { mc.gameSettings.renderDistanceChunks=2; mc.gameSettings.fancyGraphics=false; mc.gameSettings.clouds=0; mc.gameSettings.particleSetting=2; mc.gameSettings.entityShadows=false; mc.gameSettings.enableVsync=false; mc.gameSettings.ambientOcclusion=0; mc.gameSettings.mipmapLevels=0; }
        mc.gameSettings.saveOptions();
    }

    void saveConfig() {
        Properties p=new Properties();
        p.setProperty("hud.enabled",String.valueOf(hudVisible)); p.setProperty("hud.fps",String.valueOf(showFps)); p.setProperty("hud.cps",String.valueOf(showCps));
        p.setProperty("hud.keystrokes",String.valueOf(showKeys)); p.setProperty("hud.armor",String.valueOf(showArmor)); p.setProperty("hud.potions",String.valueOf(showPotions));
        p.setProperty("mod.toggleSprint",String.valueOf(sprintEnabled));        p.setProperty("visual.block.enabled",String.valueOf(blockColorEnabled));p.setProperty("visual.hit.enabled",String.valueOf(hitColorEnabled));p.setProperty("visual.hitboxes.enabled",String.valueOf(hitboxesEnabled));
        p.setProperty("visual.block.color",String.valueOf(blockColor));p.setProperty("visual.hit.color",String.valueOf(hitColor));p.setProperty("visual.hitbox.color",String.valueOf(hitboxColor));
        p.setProperty("visual.block.opacity",String.valueOf(blockOpacity));p.setProperty("visual.hit.opacity",String.valueOf(hitOpacity));p.setProperty("visual.hitbox.opacity",String.valueOf(hitboxOpacity));p.setProperty("visual.hitbox.width",String.valueOf(hitboxLineWidth));        p.setProperty("video.dynamicFov",String.valueOf(dynamicFov)); p.setProperty("mod.zoom",String.valueOf(zoomEnabled)); p.setProperty("mod.perspective",String.valueOf(perspectiveEnabled));
        p.setProperty("hud.anchor",anchor); p.setProperty("hud.offsetX",String.valueOf(offsetX)); p.setProperty("hud.offsetY",String.valueOf(offsetY));
        p.setProperty("hud.scale",String.valueOf(Math.round(hudScale*100.0F))); p.setProperty("hud.opacity",String.valueOf(opacity));
        File dir=new File(mc.mcDataDir,"config"); if(!dir.isDirectory())dir.mkdirs();
        java.io.FileOutputStream out=null; try { out=new java.io.FileOutputStream(new File(dir,"frosthud.properties")); p.store(out,"WinterHUD settings"); } catch(Exception ignored) { } finally { if(out!=null)try{out.close();}catch(Exception ignored){} }
    }

    private void loadConfig() {
        Properties p=new Properties();
        File file=new File(new File(mc.mcDataDir,"config"),"frosthud.properties");
        if(file.isFile()) { FileInputStream in=null; try { in=new FileInputStream(file); p.load(in); } catch(Exception ignored) { } finally { if(in!=null)try{in.close();}catch(Exception ignored){} } }
        hudVisible=bool(p,"hud.enabled",true); showFps=bool(p,"hud.fps",true); showCps=bool(p,"hud.cps",true);
        showKeys=bool(p,"hud.keystrokes",true); showArmor=bool(p,"hud.armor",true); showPotions=bool(p,"hud.potions",true);
        sprintEnabled=bool(p,"mod.toggleSprint",true);        blockColorEnabled=bool(p,"visual.block.enabled",true);hitColorEnabled=bool(p,"visual.hit.enabled",true);hitboxesEnabled=bool(p,"visual.hitboxes.enabled",false);
        blockColor=integer(p,"visual.block.color",0xFF45D7F5);hitColor=integer(p,"visual.hit.color",0xFFFF5577);hitboxColor=integer(p,"visual.hitbox.color",0xFF55FF99);
        blockOpacity=decimal(p,"visual.block.opacity",0.75F);hitOpacity=decimal(p,"visual.hit.opacity",0.9F);hitboxOpacity=decimal(p,"visual.hitbox.opacity",0.85F);hitboxLineWidth=decimal(p,"visual.hitbox.width",1.5F);        dynamicFov=bool(p,"video.dynamicFov",false); zoomEnabled=bool(p,"mod.zoom",true); perspectiveEnabled=bool(p,"mod.perspective",true);
        anchor=p.getProperty("hud.anchor","TOP_LEFT"); if(!anchor.matches("TOP_LEFT|TOP_RIGHT|BOTTOM_LEFT|BOTTOM_RIGHT"))anchor="TOP_LEFT";
        offsetX=clamp(integer(p,"hud.offsetX",6),0,400); offsetY=clamp(integer(p,"hud.offsetY",6),0,400);        hudScale=clamp(integer(p,"hud.scale",100),50,150)/100.0F; opacity=clamp(integer(p,"hud.opacity",100),20,100);
    }
    private static boolean bool(Properties p,String key,boolean fallback){return Boolean.parseBoolean(p.getProperty(key,String.valueOf(fallback)));}
    private static float decimal(Properties p,String key,float fallback){try{return Float.parseFloat(p.getProperty(key,String.valueOf(fallback)));}catch(Exception e){return fallback;}}
    private static int integer(Properties p,String key,int fallback){try{return Integer.parseInt(p.getProperty(key,String.valueOf(fallback)));}catch(Exception e){return fallback;}}    private static int clamp(int value,int min,int max){return Math.max(min,Math.min(max,value));}

    private void prune(Deque<Long> clicks) {
        long cutoff = System.currentTimeMillis() - 1000L;
        while (!clicks.isEmpty() && clicks.peekFirst() < cutoff) clicks.removeFirst();
    }
}
