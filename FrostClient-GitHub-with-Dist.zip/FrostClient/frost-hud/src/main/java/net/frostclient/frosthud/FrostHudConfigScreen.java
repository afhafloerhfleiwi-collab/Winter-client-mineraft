package net.frostclient.frosthud;

import java.io.IOException;import java.awt.Desktop;
import java.net.URI;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;
import org.lwjgl.input.Keyboard;
import net.minecraftforge.fml.common.Loader;
/** In-game WinterHUD configuration menu. Open with O (rebind in Controls). */
public final class FrostHudConfigScreen extends GuiScreen {
    private final FrostHud hud;
    private final List<GuiButton> controls = new ArrayList<GuiButton>();
    private int left;
    private int right;
    private int top;
    private boolean fpsPage=false;
    private boolean modsPage=false;
    private boolean visualPage=false;
    private int colorPage=0;    private int row=0;
    private int scrollOffset=0;
    private int maxScroll=0;
    private int scrollTop=0;
    private int scrollBottom=0;

    public FrostHudConfigScreen(FrostHud hud) { this.hud=hud; }

    @Override public void initGui() {
        buttonList.clear(); controls.clear(); row=0;
        int panelWidth=Math.min(560,width-28);
        int panelX=(width-panelWidth)/2;
        left=panelX+126;
        right=left+(panelWidth-150)/2+8;
        int panelHeight=Math.min(height-34,390);
        int panelY=(height-panelHeight)/2;
        top=panelY+72;
        scrollTop=panelY+58;
        scrollBottom=panelY+panelHeight-38;
        if (visualPage) {
            if(colorPage>0){add(80,left,top+150,"Opacity: click to cycle");add(81,right,top+150,"Reset color");add(82,left,top+198,"BACK  <");updateScrollPositions();return;}
            add(70,left,top,"Custom Block Color: "+on(hud.blockColorEnabled));add(71,right,top,"Block Color Settings >");
            add(72,left,top+48,"Custom Hit Color: "+on(hud.hitColorEnabled));add(73,right,top+48,"Hit Color Settings >");
            add(74,left,top+96,"Entity Hitboxes: "+on(hud.hitboxesEnabled));add(75,right,top+96,"Hitbox Settings >");
            add(76,left,top+156,"BACK TO HUD SETTINGS <");updateScrollPositions();return;
        }
        if (modsPage) {            int y=top+18;
            addLink(30,left,y,"PolyPatcher",isInstalled("patcher","polypatcher"));
            addLink(31,right,y,"FoamFix",isInstalled("foamfix","foamfix"));
            addLink(32,left,y+48,"Phosphor Legacy",isInstalled("phosphor","phosphor"));
            addLink(33,right,y+48,"BetterFPS",isInstalled("betterfps","betterfps"));
            addLink(34,left,y+96,"Nothirium (EXPERIMENTAL)",isInstalled("nothirium","nothirium"));
            addLink(35,right,y+96,"RenderLib",isInstalled("renderlib","renderlib"));
            addLink(36,left,y+144,"ConfigurationsBackport",isInstalled("configurationsbackport","configurationsbackport"));
            add(26,left,y+192,"BACK TO SETTINGS  <");
            updateScrollPositions();
            return;
        }
        if (fpsPage) {
            add(40,left,top,"Graphics: "+(mc.gameSettings.fancyGraphics?"FANCY":"FAST")); add(41,right,top,"Render distance: "+mc.gameSettings.renderDistanceChunks+" chunks"); row++;
            add(42,left,top+row*46,"Max FPS: "+fpsLabel(mc.gameSettings.limitFramerate)); add(43,right,top+row*46,"Brightness: "+Math.round(mc.gameSettings.gammaSetting*100)+"%"); row++;
            add(44,left,top+row*46,"View bobbing: "+on(mc.gameSettings.viewBobbing)); add(45,right,top+row*46,"Clouds: "+(mc.gameSettings.clouds==0?"OFF":"ON")); row++;
            add(46,left,top+row*46,"Particles: "+particleLabel(mc.gameSettings.particleSetting)); add(47,right,top+row*46,"Entity shadows: "+on(mc.gameSettings.entityShadows)); row++;
            add(48,left,top+row*46,"Smooth lighting: "+on(mc.gameSettings.ambientOcclusion>0)); add(49,right,top+row*46,"Mipmaps: "+mc.gameSettings.mipmapLevels); row++;
            add(50,left,top+row*46,"VSync: "+on(mc.gameSettings.enableVsync)); add(51,right,top+row*46,"GUI scale: "+guiScaleLabel(mc.gameSettings.guiScale)); row++;
            add(52,left,top+row*46,"Dynamic FOV: "+on(hud.dynamicFov)); add(53,right,top+row*46,"FOV: "+Math.round(mc.gameSettings.fovSetting)); row++;
            add(54,left,top+row*46,"Mouse sensitivity: "+Math.round(mc.gameSettings.mouseSensitivity*100)+"%"); add(55,right,top+row*46,"Invert mouse: "+on(mc.gameSettings.invertMouse)); row++;
            add(56,left,top+row*46,"VBO: "+on(mc.gameSettings.useVbo)); add(57,right,top+row*46,"Unicode font: "+on(mc.gameSettings.forceUnicodeFont)); row++;
            add(58,left,top+row*46,"Snooper: "+on(mc.gameSettings.snooperEnabled)); add(59,right,top+row*46,"Debug info: "+on(mc.gameSettings.showDebugInfo)); row++;
            add(60,left,top+row*46,"OptiFine Fast Render: "+optifineOption("ofFastRender")); add(61,right,top+row*46,"OptiFine Fast Math: "+optifineOption("ofFastMath")); row++;
            add(62,left,top+row*46,"OptiFine Smooth FPS: "+optifineOption("ofSmoothFps")); add(63,right,top+row*46,"OptiFine Smooth World: "+optifineOption("ofSmoothWorld")); row++;
            add(64,left,top+row*46,"OptiFine Dynamic Lights: "+optifineOption("ofDynamicLights")); add(65,right,top+row*46,"OptiFine Connected Textures: "+optifineOption("ofConnectedTextures")); row++;
            add(66,left,top+row*46,"OptiFine Lazy Chunk Loading: "+optifineOption("ofLazyChunkLoading")); add(67,right,top+row*46,"OptiFine Better Grass: "+optifineOption("ofBetterGrass")); row++;
            add(24,left,top+row*46,"Back to WinterHUD settings");
        } else {
            add(0,left,top,"HUD overlay: "+on(hud.hudVisible)); add(1,right,top,"FPS counter: "+on(hud.showFps)); row++;
            add(2,left,top+row*48,"CPS counter: "+on(hud.showCps)); add(3,right,top+row*48,"Keystrokes: "+on(hud.showKeys)); row++;
            add(4,left,top+row*48,"Armor status: "+on(hud.showArmor)); add(5,right,top+row*48,"Potion effects: "+on(hud.showPotions)); row++;
            add(6,left,top+row*48,"Toggle Sprint (G): "+on(hud.sprintEnabled)); add(7,right,top+row*48,"Zoom (C, hold): "+on(hud.zoomEnabled)); row++;
            add(8,left,top+row*48,"Perspective (P): "+on(hud.perspectiveEnabled)); add(9,right,top+row*48,"HUD corner: "+hud.anchor.replace('_',' ')); row++;
            add(12,left,top+row*48,"HUD size: "+Math.round(hud.hudScale*100)+"%"); add(13,right,top+row*48,"Opacity: "+hud.opacity+"%"); row++;
            add(14,left,top+row*48,"Reset HUD layout"); add(15,right,top+row*48,"Done / Save"); row++;
            add(16,left,top+row*48,"Apply FPS preset: "+presetName(hud.performancePreset)); add(23,right,top+row*48,"VIDEO SETTINGS  >"); row++;
            add(25,left,top+row*48,"PERFORMANCE MODS  >");            add(27,right,top+row*48,"PVP VISUAL MODS  >");
        }
        updateScrollPositions();
    }

    private void add(int id,int x,int y,String label) { GuiButton b=new FrostButton(id,x,y,Math.max(120,(right-left-12)),42,label); buttonList.add(b); controls.add(b); }
    private String on(boolean value) { return value?"ON":"OFF"; }
    private void addLink(int id,int x,int y,String name,boolean installed) {
        GuiButton b=new FrostButton(id,x,y,Math.max(120,(right-left-12)),42,name+(installed?"  [INSTALLED]":"  [GET]"));
        buttonList.add(b); controls.add(b);
    }
    private boolean isInstalled(String modId,String filePrefix) {
        if (Loader.isModLoaded(modId)) return true;
        File mods=new File(mc.mcDataDir,"mods");
        File[] files=mods.listFiles();
        if(files!=null) for(File file:files) {
            String name=file.getName().toLowerCase(java.util.Locale.ROOT);
            if(file.isFile() && name.endsWith(".jar") && name.contains(filePrefix)) return true;
        }
        return false;
    }
    private void openModPage(String url) {
        try { if(Desktop.isDesktopSupported()) Desktop.getDesktop().browse(new URI(url)); }
        catch(Exception ignored) { }
    }
    private void updateScrollPositions() {
        int contentBottom=top;
        for (GuiButton b:controls) contentBottom=Math.max(contentBottom,b.yPosition+b.height+scrollOffset);
        maxScroll=Math.max(0,contentBottom-scrollBottom);
        scrollOffset=Math.max(0,Math.min(scrollOffset,maxScroll));
        for (GuiButton b:controls) {
            b.yPosition-=scrollOffset;
            b.visible=b.yPosition>=scrollTop && b.yPosition+b.height<=scrollBottom;
        }
    }
    @Override public void handleMouseInput() throws IOException {
        int wheel=org.lwjgl.input.Mouse.getDWheel();
        super.handleMouseInput();
        if (wheel!=0 && maxScroll>0) {
            int delta=wheel>0?-45:45;
            scrollOffset=Math.max(0,Math.min(maxScroll,scrollOffset+delta));
            initGui();
        }
    }
    @Override protected void actionPerformed(GuiButton button) throws IOException {        switch(button.id) {
            case 0: hud.hudVisible=!hud.hudVisible; break;
            case 1: hud.showFps=!hud.showFps; break;
            case 2: hud.showCps=!hud.showCps; break;
            case 3: hud.showKeys=!hud.showKeys; break;
            case 4: hud.showArmor=!hud.showArmor; break;
            case 5: hud.showPotions=!hud.showPotions; break;
            case 6: hud.sprintEnabled=!hud.sprintEnabled; if(!hud.sprintEnabled)hud.toggleSprint=false; break;
            case 7: hud.zoomEnabled=!hud.zoomEnabled; if(!hud.zoomEnabled&&hud.zoom){hud.mc.gameSettings.fovSetting=hud.previousFov;hud.zoom=false;} break;
            case 8: hud.perspectiveEnabled=!hud.perspectiveEnabled; break;
            case 9: hud.anchor=nextAnchor(hud.anchor); break;
            case 10: hud.offsetX=(hud.offsetX+10>400)?0:hud.offsetX+10; break;
            case 11: hud.offsetY=(hud.offsetY+10>400)?0:hud.offsetY+10; break;
            case 12: hud.hudScale=hud.hudScale>=1.5F?0.5F:hud.hudScale+0.1F; break;
            case 13: hud.opacity=hud.opacity>=100?20:hud.opacity+10; break;
            case 14: hud.anchor="TOP_LEFT";hud.offsetX=6;hud.offsetY=6;hud.hudScale=1.0F;hud.opacity=100;break;
            case 15: hud.saveConfig();mc.displayGuiScreen(null);return;
            case 16: hud.performancePreset=(hud.performancePreset+1)%3;hud.applyPerformancePreset();break;
            case 40: hud.mc.gameSettings.fancyGraphics=!hud.mc.gameSettings.fancyGraphics; break;
            case 41: hud.mc.gameSettings.renderDistanceChunks=nextRenderDistance(hud.mc.gameSettings.renderDistanceChunks); break;
            case 42: hud.mc.gameSettings.limitFramerate=nextFps(hud.mc.gameSettings.limitFramerate); break;
            case 43: hud.mc.gameSettings.gammaSetting=hud.mc.gameSettings.gammaSetting>=1.0F?0.0F:Math.min(1.0F,hud.mc.gameSettings.gammaSetting+0.25F); break;
            case 44: hud.mc.gameSettings.viewBobbing=!hud.mc.gameSettings.viewBobbing; break;
            case 45: hud.mc.gameSettings.clouds=(hud.mc.gameSettings.clouds==0?1:0); break;
            case 46: hud.mc.gameSettings.particleSetting=(hud.mc.gameSettings.particleSetting+1)%3; break;
            case 47: hud.mc.gameSettings.entityShadows=!hud.mc.gameSettings.entityShadows; break;
            case 48: hud.mc.gameSettings.ambientOcclusion=(hud.mc.gameSettings.ambientOcclusion==0?2:0); break;
            case 49: hud.mc.gameSettings.mipmapLevels=hud.mc.gameSettings.mipmapLevels>=4?0:hud.mc.gameSettings.mipmapLevels+1; break;
            case 50: hud.mc.gameSettings.enableVsync=!hud.mc.gameSettings.enableVsync; break;
            case 51: hud.mc.gameSettings.guiScale=(hud.mc.gameSettings.guiScale+1)%5; break;
            case 52: hud.dynamicFov=!hud.dynamicFov; break;
            case 53: hud.mc.gameSettings.fovSetting=nextFov(hud.mc.gameSettings.fovSetting); break;
            case 54: hud.mc.gameSettings.mouseSensitivity=nextSensitivity(hud.mc.gameSettings.mouseSensitivity); break;
            case 55: hud.mc.gameSettings.invertMouse=!hud.mc.gameSettings.invertMouse; break;
            case 56: hud.mc.gameSettings.useVbo=!hud.mc.gameSettings.useVbo; break;
            case 57: hud.mc.gameSettings.forceUnicodeFont=!hud.mc.gameSettings.forceUnicodeFont; break;
            case 58: hud.mc.gameSettings.snooperEnabled=!hud.mc.gameSettings.snooperEnabled; break;
            case 59: hud.mc.gameSettings.showDebugInfo=!hud.mc.gameSettings.showDebugInfo; break;
            case 60: toggleOptifineOption("ofFastRender"); break;
            case 61: toggleOptifineOption("ofFastMath"); break;
            case 62: toggleOptifineOption("ofSmoothFps"); break;
            case 63: toggleOptifineOption("ofSmoothWorld"); break;
            case 64: toggleOptifineOption("ofDynamicLights"); break;
            case 65: toggleOptifineOption("ofConnectedTextures"); break;
            case 66: toggleOptifineOption("ofLazyChunkLoading"); break;
            case 67: toggleOptifineOption("ofBetterGrass"); break;            case 23: fpsPage=true; break;
            case 24: fpsPage=false; break;
            case 25: modsPage=true; break;            case 27: visualPage=true;fpsPage=false;modsPage=false;colorPage=0;scrollOffset=0;break;
            case 70: hud.blockColorEnabled=!hud.blockColorEnabled;break;
            case 71: colorPage=1;break;
            case 72: hud.hitColorEnabled=!hud.hitColorEnabled;break;
            case 73: colorPage=2;break;
            case 74: hud.hitboxesEnabled=!hud.hitboxesEnabled;break;
            case 75: colorPage=3;break;
            case 76: visualPage=false;break;
            case 80: if(colorPage==1)hud.blockOpacity=hud.blockOpacity>=1.0F?0.2F:hud.blockOpacity+0.2F;else if(colorPage==2)hud.hitOpacity=hud.hitOpacity>=1.0F?0.2F:hud.hitOpacity+0.2F;else hud.hitboxOpacity=hud.hitboxOpacity>=1.0F?0.2F:hud.hitboxOpacity+0.2F;break;
            case 81: if(colorPage==1)hud.blockColor=0xFF45D7F5;else if(colorPage==2)hud.hitColor=0xFFFF5577;else hud.hitboxColor=0xFF55FF99;break;
            case 82: colorPage=0;break;
            case 26: modsPage=false; break;            case 30: openModPage("https://github.com/Polyfrost/PolyPatcher/releases"); return;
            case 31: openModPage("https://www.curseforge.com/minecraft/mc-mods/foamfix-optimization-mod"); return;
            case 32: openModPage("https://modrinth.com/mod/phosphorlegacyforge/versions"); return;
            case 33: openModPage("https://www.curseforge.com/minecraft/mc-mods/betterfps"); return;
            case 34: openModPage("https://modrinth.com/mod/nothirium-1.8.9-port/versions"); return;
            case 35: openModPage("https://modrinth.com/mod/renderlib-1.8.9-port/versions"); return;
            case 36: openModPage("https://modrinth.com/mod/configurationsbackport/versions"); return;
        }
        hud.mc.gameSettings.saveOptions();
        hud.saveConfig(); initGui();
    }

    private String optifineOption(String field) {
        String getter=optifineGetter(field);
        Class<?> config=loadOptifineConfig();
        if(config!=null && getter!=null) {
            try {
                Object value=config.getMethod(getter).invoke(null);
                if(value instanceof Boolean) return ((Boolean)value)?"ON":"OFF";
                return String.valueOf(value);
            } catch(Throwable ignored) { }
        }
        try {
            java.lang.reflect.Field f=findOptifineField(field);
            if(f==null) return "N/A";
            Object value=f.get(mc.gameSettings);
            return value instanceof Boolean?(((Boolean)value)?"ON":"OFF"):String.valueOf(value);
        } catch(Throwable ignored) { return "N/A"; }
    }
    private void toggleOptifineOption(String field) {
        try {
            java.lang.reflect.Field f=findOptifineField(field);
            if(f==null) return;
            if(f.getType()==Boolean.TYPE) f.setBoolean(mc.gameSettings,!f.getBoolean(mc.gameSettings));
            else if(f.getType()==Integer.TYPE) f.setInt(mc.gameSettings,(f.getInt(mc.gameSettings)+1)%3);
            mc.gameSettings.saveOptions();
        } catch(Throwable ignored) { }
    }
    private Class<?> loadOptifineConfig() {
        ClassLoader[] loaders=new ClassLoader[]{Thread.currentThread().getContextClassLoader(),mc.getClass().getClassLoader(),getClass().getClassLoader()};
        for(ClassLoader loader:loaders) {
            if(loader==null) continue;
            try { return Class.forName("Config",false,loader); } catch(Throwable ignored) { }
        }
        try { return Class.forName("Config"); } catch(Throwable ignored) { return null; }
    }
    private java.lang.reflect.Field findOptifineField(String name) {
        Object settings=mc.gameSettings;
        Class<?> config=loadOptifineConfig();
        if(config!=null) {
            try { Object actual=config.getMethod("getGameSettings").invoke(null); if(actual!=null) settings=actual; }
            catch(Throwable ignored) { }
        }
        Class<?> type=settings.getClass();
        while(type!=null) {
            try { java.lang.reflect.Field f=type.getDeclaredField(name); f.setAccessible(true); return f; }
            catch(NoSuchFieldException ignored) { type=type.getSuperclass(); }
            catch(Throwable ignored) { return null; }
        }
        return null;
    }
    private String optifineGetter(String field) {
        if("ofFastRender".equals(field)) return "isFastRender";
        if("ofSmoothFps".equals(field)) return "isSmoothFps";
        if("ofSmoothWorld".equals(field)) return "isSmoothWorld";
        if("ofDynamicLights".equals(field)) return "isDynamicLights";
        if("ofConnectedTextures".equals(field)) return "isConnectedTextures";
        if("ofLazyChunkLoading".equals(field)) return "isLazyChunkLoading";
        if("ofBetterGrass".equals(field)) return "isBetterGrass";
        return null;
    }
    private float nextFov(float value) { return value>=110.0F?-1.0F:(value<0.0F?30.0F:Math.min(110.0F,value+10.0F)); }
    private float nextSensitivity(float value) { return value>=1.0F?0.0F:Math.min(1.0F,value+0.1F); }
    private int nextRenderDistance(int value) { return value>=16?2:Math.min(16,value+2); }
    private int nextFps(int value) { if(value<=60)return 120; if(value<=120)return 144; if(value<=144)return 240; return 30; }
    private String fpsLabel(int value) { return value>=260?"Unlimited":String.valueOf(value); }
    private String particleLabel(int value) { return value==0?"ALL":(value==1?"DECREASED":"MINIMAL"); }
    private String guiScaleLabel(int value) { return value==0?"AUTO":String.valueOf(value); }

    private String presetName(int value) { return value==0?"Balanced":(value==1?"Performance":"Potato"); }
    private String nextAnchor(String value) {        if("TOP_LEFT".equals(value))return "TOP_RIGHT";
        if("TOP_RIGHT".equals(value))return "BOTTOM_RIGHT";
        if("BOTTOM_RIGHT".equals(value))return "BOTTOM_LEFT";
        return "TOP_LEFT";
    }

    @Override protected void mouseClicked(int mouseX,int mouseY,int mouseButton) throws IOException {
        if(mouseButton==0){int panelW=Math.min(560,width-28),panelH=Math.min(height-34,390),px=(width-panelW)/2,py=(height-panelH)/2;
            if(mouseX>=px+8&&mouseX<px+104){if(mouseY>=py+49&&mouseY<py+71){fpsPage=false;modsPage=false;visualPage=false;colorPage=0;scrollOffset=0;initGui();return;}if(mouseY>=py+83&&mouseY<py+105){fpsPage=true;modsPage=false;visualPage=false;colorPage=0;scrollOffset=0;initGui();return;}if(mouseY>=py+117&&mouseY<py+139){fpsPage=false;modsPage=true;visualPage=false;colorPage=0;scrollOffset=0;initGui();return;}}
            if(visualPage&&colorPage>0){int cx=left+172,cy=top+65;double dx=mouseX-cx,dy=mouseY-cy,dist=Math.sqrt(dx*dx+dy*dy);if(dist<=48.0){float hue=(float)((Math.atan2(dy,dx)/(Math.PI*2.0)+1.0)%1.0),sat=(float)Math.min(1.0,dist/48.0);int rgb=java.awt.Color.HSBtoRGB(hue,sat,1.0F)|0xFF000000;if(colorPage==1)hud.blockColor=rgb;else if(colorPage==2)hud.hitColor=rgb;else hud.hitboxColor=rgb;hud.saveConfig();return;}}        }super.mouseClicked(mouseX,mouseY,mouseButton);
    }    @Override public void drawScreen(int mouseX,int mouseY,float partialTicks) {
        drawDefaultBackground();
        drawRect(0,0,width,height,0xB8070B11);
        int panelW=Math.min(560,width-28), panelH=Math.min(height-34,390);
        int px=(width-panelW)/2, py=(height-panelH)/2;
        // Main shell and top accent
        drawRect(px,py,px+panelW,py+panelH,0xF20D141D);
        drawRect(px,py,px+panelW,py+2,0xFF35CFF0);
        drawRect(px+1,py+2,px+panelW-1,py+panelH-1,0xFF111B26);
        // Left navigation rail
        drawRect(px+1,py+3,px+112,py+panelH-1,0xFF0B121A);
        drawRect(px+112,py+3,px+113,py+panelH-1,0xFF263747);
        drawString(fontRendererObj,"WINTER",px+16,py+16,0xFF45D7F5);
        drawString(fontRendererObj,"CLIENT",px+16,py+28,0xFF91A5B8);        drawRect(px+14,py+48,px+98,py+49,0xFF263747);
        drawNavItem(px,py,"HUD",!fpsPage&&!modsPage&&!visualPage);
        drawNavItem(px,py,"VIDEO",fpsPage);
        drawNavItem(px,py,"MODS",modsPage);        drawString(fontRendererObj,"FORGE",px+16,py+panelH-39,0xFF6F8498);        drawString(fontRendererObj,"1.8.9",px+16,py+panelH-27,0xFFB8C7D8);
        // Page title and context
        String pageTitle=colorPage>0?(colorPage==1?"CUSTOM BLOCK COLOR":(colorPage==2?"CUSTOM HIT COLOR":"HITBOX SETTINGS")):(visualPage?"PVP VISUAL MODS":(modsPage?"PERFORMANCE MODS":(fpsPage?"VIDEO & FPS":"HUD SETTINGS")));        drawString(fontRendererObj,pageTitle,px+130,py+15,0xFFF2F7FB);
        drawString(fontRendererObj,"PERSONALIZE YOUR PVP EXPERIENCE",px+130,py+29,0xFF8196AA);
        drawRect(px+130,py+43,px+panelW-16,py+44,0xFF263747);        if(visualPage){drawString(fontRendererObj,colorPage>0?"COLOR WHEEL / CLICK TO SELECT":"VISUAL EFFECTS / CLICK A MOD",left,py+60,0xFF45D7F5);if(colorPage>0)drawColorWheel(left+172,top+65,colorPage==1?hud.blockColor:(colorPage==2?hud.hitColor:hud.hitboxColor));}

        if (modsPage) {
            drawCenteredString(fontRendererObj,"Forge 1.8.9 PERFORMANCE MODS",width/2+55,py+61,0xFF45D7F5);
            drawCenteredString(fontRendererObj,"Click a tile to open its official project/download page",width/2+55,py+76,0xFFB8C7D8);
            drawString(fontRendererObj,"Nothirium is experimental and needs RenderLib + ConfigurationsBackport.",left,py+260,0xFFFFCC66);
            drawString(fontRendererObj,"PolyPatcher has Fast Math; avoid duplicating BetterFPS algorithm changes.",left,py+276,0xFFFFCC66);
            drawString(fontRendererObj,"FoamFix upstream lists OptiFine as unsupported.",left,py+292,0xFFFFCC66);
            drawCenteredString(fontRendererObj,"Restart Minecraft after installing or removing any mod",width/2+55,py+panelH-20,0xFF8798B0);
        } else if (fpsPage) {
            drawString(fontRendererObj,"VIDEO SETTINGS  /  PERFORMANCE",left,py+58,0xFF45D7F5);
            drawCenteredString(fontRendererObj,"Vanilla 1.8.9 settings — changes apply immediately",width/2+55,py+panelH-20,0xFF8798B0);
        } else if (visualPage) {
            drawString(fontRendererObj,"PVP VISUAL MODS",left,py+58,0xFF45D7F5);
        } else {
            drawString(fontRendererObj,"HUD ELEMENTS & MOVEMENT",left,py+56,0xFF45D7F5);
            drawRect(left-7,py+70,right+(right-left-12)+7,py+71,0xFF263747);
            drawString(fontRendererObj,"SCROLL TO SEE ALL OPTIONS",left,py+panelH-18,0xFF8798B0);
        }        super.drawScreen(mouseX,mouseY,partialTicks);    }

    private void drawColorWheel(int cx,int cy,int selectedColor){int radius=48;for(int yy=-radius;yy<=radius;yy+=2)for(int xx=-radius;xx<=radius;xx+=2){float d=(float)Math.sqrt(xx*xx+yy*yy);if(d<=radius){float h=(float)((Math.atan2(yy,xx)/(Math.PI*2.0)+1.0)%1.0);int c=java.awt.Color.HSBtoRGB(h,d/radius,1.0F)|0xFF000000;drawRect(cx+xx,cy+yy,cx+xx+2,cy+yy+2,c);}}drawRect(cx-2,cy-2,cx+3,cy+3,0xFFFFFFFF);drawRect(cx+62,cy-9,cx+100,cy+9,selectedColor);drawString(fontRendererObj,String.format("#%06X",selectedColor&0xFFFFFF),cx+58,cy+16,0xFFEAF4FC);}

    private void drawNavItem(int px,int py,String label,boolean selected) {
        int yOffset=label.equals("HUD")?54:(label.equals("VIDEO")?88:122);
        int y=py+yOffset;
        if(selected) {
            drawRect(px+8,y-5,px+104,y+17,0xFF172B39);
            drawRect(px+8,y-5,px+10,y+17,0xFF45D7F5);
        }
        drawString(fontRendererObj,label,px+20,y+2,selected?0xFF45D7F5:0xFF8196AA);
    }

    private void drawModStatus(String name,String modId,String description,int y) {
        boolean loaded=Loader.isModLoaded(modId);
        drawRect(left-8,y-5,right+(right-left-12)+8,y+15,0xFF0B121A);
        drawString(fontRendererObj,name,left,y,loaded?0xFF55FF99:0xFFFFCC66);
        drawString(fontRendererObj,loaded?"DETECTED":"NOT INSTALLED",left+105,y,loaded?0xFF55FF99:0xFFFFCC66);
        drawString(fontRendererObj,description,left+205,y,0xFFB8C7D8);
    }

    @Override protected void keyTyped(char typedChar,int keyCode) throws IOException {
        if(keyCode==Keyboard.KEY_ESCAPE){hud.saveConfig();mc.displayGuiScreen(null);} else super.keyTyped(typedChar,keyCode);
    }

    @Override public boolean doesGuiPauseGame() { return false; }

    private static final class FrostButton extends GuiButton {
        FrostButton(int id,int x,int y,int width,int height,String label) { super(id,x,y,width,height,label); }
        @Override public void drawButton(net.minecraft.client.Minecraft mc,int mouseX,int mouseY) {
            if(!visible)return;
            boolean over=mouseX>=xPosition && mouseY>=yPosition && mouseX<xPosition+width && mouseY<yPosition+height;
            String upper=displayString.toUpperCase();
            boolean active=upper.contains(": ON") || upper.contains("DETECTED") || upper.contains("INSTALLED");
            int bg=!enabled?0xFF101820:(over?0xFF243F50:(active?0xFF173342:0xFF121E29));
            int edge=!enabled?0xFF293542:(over?0xFF45D7F5:(active?0xFF287F96:0xFF304456));
            // Flat, square-corner tiles inspired by Lunar Client's compact settings UI.
            net.minecraft.client.gui.Gui.drawRect(xPosition,yPosition,xPosition+width,yPosition+height,bg);
            net.minecraft.client.gui.Gui.drawRect(xPosition,yPosition,xPosition+width,yPosition+1,edge);
            net.minecraft.client.gui.Gui.drawRect(xPosition,yPosition+height-1,xPosition+width,yPosition+height,edge);
            net.minecraft.client.gui.Gui.drawRect(xPosition,yPosition,xPosition+1,yPosition+height,edge);
            net.minecraft.client.gui.Gui.drawRect(xPosition+width-1,yPosition,xPosition+width,yPosition+height,edge);
            int color=!enabled?0xFF687786:(over?0xFFFFFFFF:(active?0xFFBDEFFF:0xFFDCE7F0));
            drawCenteredString(mc.fontRendererObj,displayString,xPosition+width/2,yPosition+(height-8)/2,color);
        }
    }}