package net.frostclient.winterhud;

import java.awt.Color;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;

/** WinterHUD settings split into HUD, video, visuals and performance pages. */
public final class WinterHudSettingsScreen extends Screen {
    private int page = 0;
    private boolean colorPickerActive;
    private int colorTarget;

    public WinterHudSettingsScreen() {
        super(Component.literal("WinterHUD Settings"));
    }

    @Override
    protected void init() {
        int left = width / 2 - 150;
        int top = 72;
        int row = 0;
        addNav(left, 24, 0, "HUD");
        addNav(left + 60, 24, 1, "VIDEO");
        addNav(left + 120, 24, 2, "VISUALS");
        addNav(left + 180, 24, 3, "MODS");
        addNav(left + 240, 24, 4, "SODIUM");        if (colorPickerActive) {
            addAction(left, top, row++, "Cancel color picker", () -> colorPickerActive = false);
        } else if (page == 0) {
            addToggle(left, top, row++, "HUD overlay", WinterHudClient.isHudVisible(), WinterHudClient::setHudVisible);
            addToggle(left, top, row++, "Toggle Sprint (G)", WinterHudClient.isSprintEnabled(), WinterHudClient::setSprintEnabled);
            addToggle(left, top, row++, "Hold Zoom (C)", WinterHudClient.isZoomEnabled(), WinterHudClient::setZoomEnabled);
            addToggle(left, top, row++, "Perspective (P)", WinterHudClient.isPerspectiveEnabled(), WinterHudClient::setPerspectiveEnabled);
            addToggle(left, top, row++, "FPS counter", WinterHudClient.isShowFps(), WinterHudClient::setShowFps);
            addToggle(left, top, row++, "CPS counter", WinterHudClient.isShowCps(), WinterHudClient::setShowCps);
            addToggle(left, top, row++, "Keystrokes", WinterHudClient.isShowKeys(), WinterHudClient::setShowKeys);
            addToggle(left, top, row++, "Armor status", WinterHudClient.isShowArmor(), WinterHudClient::setShowArmor);
            addToggle(left, top, row++, "Potion effects", WinterHudClient.isShowPotions(), WinterHudClient::setShowPotions);
            addAction(left, top, row++, "HUD corner: " + WinterHudClient.getAnchor().replace('_', ' '), WinterHudClient::cycleAnchor);
            addAction(left, top, row++, "HUD scale: " + WinterHudClient.getScale() + "%", WinterHudClient::cycleScale);
            addAction(left, top, row++, "HUD opacity: " + WinterHudClient.getOpacity() + "%", WinterHudClient::cycleOpacity);
            addAction(left, top, row++, "Horizontal offset: " + WinterHudClient.getOffsetX(), WinterHudClient::cycleOffsetX);
            addAction(left, top, row++, "Vertical offset: " + WinterHudClient.getOffsetY(), WinterHudClient::cycleOffsetY);
        } else if (page == 1) {
            addToggle(left, top, row++, "Dynamic FOV", WinterHudClient.isDynamicFov(), WinterHudClient::setDynamicFov);
            addAction(left, top, row++, "Render distance: " + Minecraft.getInstance().options.renderDistance().get() + " chunks", WinterHudClient::cycleRenderDistance);
            addAction(left, top, row++, "Simulation distance: " + Minecraft.getInstance().options.simulationDistance().get() + " chunks", WinterHudClient::cycleSimulationDistance);
            addAction(left, top, row++, "Apply Balanced FPS preset", () -> WinterHudClient.applyPerformancePreset(0));
            addAction(left, top, row++, "Apply High FPS preset", () -> WinterHudClient.applyPerformancePreset(1));
            addAction(left, top, row++, "Apply Maximum FPS preset", () -> WinterHudClient.applyPerformancePreset(2));
            addAction(left, top, row++, "Restore default HUD layout", WinterHudClient::resetLayout);
        } else if (page == 2) {
            addToggle(left, top, row++, "Custom block outline color", WinterHudClient.isBlockColorEnabled(), WinterHudClient::setBlockColorEnabled);
            addAction(left, top, row++, "Choose block color: " + hex(WinterHudClient.getBlockColor()), () -> { colorTarget = 0; colorPickerActive = true; });
            addToggle(left, top, row++, "Custom target hit color", WinterHudClient.isHitColorEnabled(), WinterHudClient::setHitColorEnabled);
            addAction(left, top, row++, "Choose hit color: " + hex(WinterHudClient.getHitColor()), () -> { colorTarget = 1; colorPickerActive = true; });
            addToggle(left, top, row++, "Entity hitboxes", WinterHudClient.isHitboxesEnabled(), WinterHudClient::setHitboxesEnabled);
        } else if (page == 3) {
            String[] ids = {"sodium", "lithium", "immediatelyfast", "entityculling", "ferritecore", "moreculling", "dynamic_fps"};
            String[] names = {"Sodium — rendering engine", "Lithium — game logic", "ImmediatelyFast — GUI/render batching",
                    "Entity Culling — hidden entities", "FerriteCore — memory usage", "More Culling — extra visibility culling",
                    "Dynamic FPS — background throttling"};
            for (int i = 0; i < ids.length; i++) {
                boolean installed = FabricLoader.getInstance().isModLoaded(ids[i]);
                addStatus(left, top, row++, names[i], installed);
            }
        } else {
            boolean sodiumInstalled = FabricLoader.getInstance().isModLoaded("sodium");
            addStatus(left, top, row++, "Sodium options", sodiumInstalled);
            addAction(left, top, row++, "Apply Sodium Balanced preset", () -> WinterHudClient.applySodiumPreset(0));
            addAction(left, top, row++, "Apply Sodium MAX FPS preset", () -> WinterHudClient.applySodiumPreset(1));
            addStatus(left, top, row++, "MAX FPS: lower visual quality for speed", true);
            addStatus(left, top, row++, "Changes save to Sodium config", true);
        }
        addRenderableWidget(Button.builder(Component.literal("Done"), b -> onClose())
                .bounds(left, Math.min(height - 32, top + row * 24 + 6), 300, 22).build());
    }

    private void addNav(int x, int y, int target, String label) {
        addRenderableWidget(Button.builder(Component.literal((page == target ? "> " : "") + label),
                        b -> { page = target; colorPickerActive = false; rebuildWidgets(); })
                .bounds(x, y, 60, 22).build());
    }
    private void addToggle(int x, int y, int row, String name, boolean value,
                           java.util.function.Consumer<Boolean> setter) {
        addRenderableWidget(Button.builder(label(name, value), button -> {
                    setter.accept(!value);
                    button.setMessage(label(name, !value));
                })
                .bounds(x, y + row * 24, 300, 22).build());
    }

    private void addAction(int x, int y, int row, String name, Runnable action) {
        addRenderableWidget(Button.builder(Component.literal(name), button -> {
                    action.run();
                    rebuildWidgets();
                })
                .bounds(x, y + row * 24, 300, 22).build());
    }

    private void addStatus(int x, int y, int row, String name, boolean installed) {
        Component label = Component.literal(name + "  [" + (installed ? "INSTALLED" : "MISSING") + "]");
        addRenderableWidget(Button.builder(label, b -> { })
                .bounds(x, y + row * 24, 300, 22).build());
    }

    private static Component label(String name, boolean enabled) {
        return Component.literal(name + ": " + (enabled ? "ON" : "OFF"));
    }

    private static String hex(int color) {
        return String.format(java.util.Locale.ROOT, "#%06X", color & 0xFFFFFF);
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        if (colorPickerActive && event.button() == 0) {
            int cx = width / 2;
            int cy = height / 2 + 12;
            double dx = event.x() - cx;
            double dy = event.y() - cy;
            double distance = Math.sqrt(dx * dx + dy * dy);
            if (distance <= 56.0) {
                float hue = (float)((Math.atan2(dy, dx) / (Math.PI * 2.0) + 1.0) % 1.0);
                float saturation = (float)(distance / 56.0);
                int selected = 0xFF000000 | (Color.HSBtoRGB(hue, saturation, 1.0F) & 0xFFFFFF);
                if (colorTarget == 0) WinterHudClient.setBlockColor(selected);
                else WinterHudClient.setHitColor(selected);
                colorPickerActive = false;
                rebuildWidgets();
                return true;
            }
        }
        return super.mouseClicked(event, doubleClick);
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float partialTick) {
        graphics.centeredText(font, title, width / 2, Math.max(8, height / 2 - 210), 0xFF45D7F5);
        String subtitle = colorPickerActive ? "COLOR WHEEL — CLICK TO SELECT"
                : page == 0 ? "HUD ELEMENTS & LAYOUT" : page == 1 ? "VIDEO & FPS"
                : page == 2 ? "BLOCK / HIT COLORS & HITBOXES" : page == 3 ? "INSTALLED PERFORMANCE MODS" : "SODIUM PERFORMANCE PRESETS";
        super.extractRenderState(graphics, mouseX, mouseY, partialTick);        if (colorPickerActive) drawColorWheel(graphics);
    }

    private void drawColorWheel(GuiGraphicsExtractor graphics) {
        int cx = width / 2, cy = height / 2 + 12, radius = 56, step = 4;
        for (int dx = -radius; dx <= radius; dx += step) {
            for (int dy = -radius; dy <= radius; dy += step) {
                double distance = Math.sqrt(dx * dx + dy * dy);
                if (distance > radius) continue;
                float hue = (float)((Math.atan2(dy, dx) / (Math.PI * 2.0) + 1.0) % 1.0);
                float saturation = (float)(distance / radius);
                int color = 0xFF000000 | (Color.HSBtoRGB(hue, saturation, 1.0F) & 0xFFFFFF);
                graphics.fill(cx + dx, cy + dy, cx + dx + step, cy + dy + step, color);
            }
        }
        graphics.centeredText(font, "Click the wheel to choose a color", cx, cy + 66, 0xFFFFFFFF);
    }

    @Override public boolean isPauseScreen() { return false; }

    @Override public void onClose() {
        Minecraft.getInstance().gui.setScreen(null);
    }
}
