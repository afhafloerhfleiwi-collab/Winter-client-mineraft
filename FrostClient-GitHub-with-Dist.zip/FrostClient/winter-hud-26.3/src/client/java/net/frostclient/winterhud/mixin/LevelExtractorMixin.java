package net.frostclient.winterhud.mixin;

import net.frostclient.winterhud.WinterHudClient;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.entity.state.EntityRenderState;
import net.minecraft.client.renderer.extract.LevelExtractor;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.EntityHitResult;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Colors the entity currently under the crosshair without changing its team or data. */
@Mixin(value = LevelExtractor.class, remap = false)
abstract class LevelExtractorMixin {
    @Inject(
            method = "extractEntity",
            at = @At("RETURN"),
            remap = false
    )
    private void winterhud$targetEntityColor(Entity entity, float partialTick,
                                              CallbackInfoReturnable<EntityRenderState> cir) {
        if (!WinterHudClient.isHitColorEnabled()) return;
        if (!(Minecraft.getInstance().hitResult instanceof EntityHitResult hit)) return;
        if (hit.getEntity() != entity) return;
        EntityRenderState state = cir.getReturnValue();
        if (state != null) state.outlineColor = WinterHudClient.getHitColor();
    }
}
