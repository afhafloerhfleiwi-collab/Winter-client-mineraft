package net.frostclient.winterhud;

import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayDeque;
import java.util.Deque;
import java.util.Properties;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.CameraType;
import net.minecraft.client.CloudStatus;
import net.minecraft.client.gui.components.debug.DebugScreenEntries;
import net.minecraft.client.gui.components.debug.DebugScreenEntryStatus;
import net.minecraft.client.GraphicsPreset;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.resources.Identifier;
import net.minecraft.network.chat.Component;
import com.mojang.blaze3d.platform.InputConstants;
import org.lwjgl.sdl.SDLVideo;

/** Fabric 26.3 WinterHUD port using the unobfuscated Mojang-name client API. */
public final class WinterHudClient implements ClientModInitializer {
    private static final KeyMapping.Category CATEGORY = KeyMapping.Category.register(
            Identifier.fromNamespaceAndPath("winterhud", "main"));
    private static final Path CONFIG = FabricLoader.getInstance().getConfigDir().resolve("winterhud.properties");
    private static KeyMapping toggleHudKey, toggleSprintKey, zoomKey, perspectiveKey, settingsKey;
    private static boolean hudVisible = true, sprintEnabled = true, toggleSprint;
    private static boolean zoomEnabled = true, perspectiveEnabled = true, zooming, dynamicFov;
    private static boolean showFps = true, showCps = true, showKeys = true;
    private static boolean showArmor = true, showPotions = true;
    private static boolean blockColorEnabled, hitColorEnabled, hitboxesEnabled;
    private static int blockColor = 0xFF45D7F5, hitColor = 0xFFFF5B7F;
    private static String anchor = "TOP_LEFT";
    private static int offsetX = 8, offsetY = 8, opacity = 92, hudScale = 100;
    private static int savedFov = 70;
    private static boolean leftWasDown, rightWasDown;
    private static boolean runtimeSettingsApplied;
    private static boolean borderlessWindowApplied;
    private static final Deque<Long> leftClicks = new ArrayDeque<>();
    private static final Deque<Long> rightClicks = new ArrayDeque<>();

    @Override public void onInitializeClient() {
        loadConfig();
        toggleHudKey = register("key.winterhud.toggle_hud", InputConstants.KEY_H);
        toggleSprintKey = register("key.winterhud.toggle_sprint", InputConstants.KEY_G);
        zoomKey = register("key.winterhud.zoom", InputConstants.KEY_C);
        perspectiveKey = register("key.winterhud.perspective", InputConstants.KEY_P);
        settingsKey = register("key.winterhud.open_settings", InputConstants.KEY_O);
        ClientTickEvents.END_CLIENT_TICK.register(WinterHudClient::tick);
        HudElementRegistry.addLast(Identifier.fromNamespaceAndPath("winterhud", "overlay"),
                (graphics, tickCounter) -> renderHud(graphics));
    }

    private static KeyMapping register(String translationKey, int keyCode) {
        return KeyMappingHelper.registerKeyMapping(new KeyMapping(translationKey, keyCode, CATEGORY));
    }

    private static void tick(Minecraft client) {
        if (!borderlessWindowApplied && client.getWindow() != null && client.getWindow().handle() != 0L) {
            try {
                var window = client.getWindow();
                window.setWindowed(960, 600);
                SDLVideo.SDL_SetWindowBordered(window.handle(), false);
                SDLVideo.SDL_SetWindowPosition(window.handle(), Math.max(0, (window.getScreenWidth() - 960) / 2), Math.max(0, (window.getScreenHeight() - 600) / 2));
                borderlessWindowApplied = true;
            } catch (Throwable ignored) {
                // Keep the normal window usable if the platform rejects borderless mode.
            }
        }
        if (!runtimeSettingsApplied && client.options != null) {
            client.options.fovEffectScale().set(dynamicFov ? 1.0 : 0.0);
            applyHitboxesSetting();
            runtimeSettingsApplied = true;
        }
        while (toggleHudKey.consumeClick()) { hudVisible = !hudVisible; saveConfig(); }
        while (toggleSprintKey.consumeClick()) if (sprintEnabled) { toggleSprint = !toggleSprint; }
        // Settings must be handled even when no world/player exists (title screen, menus, etc.).
        while (settingsKey.consumeClick()) client.setScreenAndShow(new WinterHudSettingsScreen());
        LocalPlayer player = client.player;
        if (player == null) {
            if (zooming) restoreFov(client);
            leftClicks.clear(); rightClicks.clear();
            return;
        }
        if (toggleSprint && sprintEnabled) {            boolean moving = client.options.keyUp.isDown() || client.options.keyDown.isDown()
                    || client.options.keyLeft.isDown() || client.options.keyRight.isDown();
            player.setSprinting(moving && player.getFoodData().getFoodLevel() > 6);
        }
        boolean shouldZoom = zoomEnabled && client.gui.screen() == null && zoomKey.isDown();
        if (shouldZoom && !zooming) { savedFov = client.options.fov().get(); zooming = true; }
        if (shouldZoom) client.options.fov().set(30);
        else if (zooming) restoreFov(client);
        while (perspectiveKey.consumeClick()) if (perspectiveEnabled) {
            CameraType current = client.options.getCameraType();
            client.options.setCameraType(current.isFirstPerson()
                    ? CameraType.THIRD_PERSON_BACK
                    : (current == CameraType.THIRD_PERSON_BACK
                        ? CameraType.THIRD_PERSON_FRONT : CameraType.FIRST_PERSON));
        }
        long now = System.currentTimeMillis();
        boolean left = client.mouseHandler.isLeftPressed();
        boolean right = client.mouseHandler.isRightPressed();
        if (left && !leftWasDown) leftClicks.addLast(now);
        if (right && !rightWasDown) rightClicks.addLast(now);
        leftWasDown = left; rightWasDown = right;
        prune(leftClicks, now); prune(rightClicks, now);
    }

    private static void prune(Deque<Long> clicks, long now) {
        while (!clicks.isEmpty() && now - clicks.peekFirst() > 1000L) clicks.removeFirst();
    }

    private static void restoreFov(Minecraft client) {
        client.options.fov().set(savedFov);
        zooming = false;
    }

    private static void renderHud(GuiGraphicsExtractor g) {
        Minecraft client = Minecraft.getInstance();
        LocalPlayer p = client.player;
        if (!hudVisible || p == null || client.gui.hud.isHidden()) return;
        int rows = 2 + (showFps ? 1 : 0) + (showCps ? 1 : 0) + (showArmor ? 1 : 0) + (showPotions ? 1 : 0);
        int panelHeight = 16 + rows * 13;
        float scale = Math.max(50, Math.min(150, hudScale)) / 100.0F;
        boolean left = anchor.endsWith("LEFT"), top = anchor.startsWith("TOP");
        int x = left ? offsetX : g.guiWidth() - offsetX - Math.round(158 * scale);
        int y = top ? offsetY : g.guiHeight() - offsetY - Math.round(panelHeight * scale);
        int alpha = Math.max(0, Math.min(100, opacity)) * 255 / 100;
        g.pose().pushMatrix();
        g.pose().translate(x, y);
        g.pose().scale(scale, scale);        g.fill(0, 0, 154, panelHeight, (alpha << 24) | 0x101722);
        g.fill(0, 0, 154, 2, (alpha << 24) | 0x45D7F5);
        g.text(client.font, Component.literal("W I N T E R  /  26.3"), 8, 7, (alpha << 24) | 0x45D7F5, false);
        int line = 22;
        if (showFps) { g.text(client.font, Component.literal("FPS  " + client.getFps()), 8, line, (alpha << 24) | 0xFFFFFF, true); line += 13; }
        if (showCps) { g.text(client.font, Component.literal("CPS  L " + leftClicks.size() + "   R " + rightClicks.size()), 8, line, (alpha << 24) | 0xFFFFFF, false); line += 13; }
        g.text(client.font, Component.literal("XYZ  " + (int)p.getX() + "  " + (int)p.getY() + "  " + (int)p.getZ()), 8, line, (alpha << 24) | 0xDCE7F0, false);
        line += 13;
        g.text(client.font, Component.literal("SPRINT  " + (toggleSprint ? "ON" : "OFF")), 8, line,
                (alpha << 24) | (toggleSprint ? 0x55E69A : 0x9AAAB8), false);
        line += 13;
        if (showArmor) { g.text(client.font, Component.literal("ARMOR  " + p.getArmorValue()), 8, line, (alpha << 24) | 0xDCE7F0, false); line += 13; }
        if (showPotions) g.text(client.font, Component.literal("EFFECTS  " + p.getActiveEffects().size()), 8, line, (alpha << 24) | 0x45D7F5, false);
        g.pose().popMatrix();
        if (showKeys) {
            int keyX = left ? g.guiWidth() - offsetX - Math.round(84 * scale) : offsetX;
            int keyY = top ? g.guiHeight() - offsetY - Math.round(66 * scale) : offsetY;            drawKeystrokes(g, client, keyX, keyY, alpha, scale);
        }
    }

    private static void drawKeystrokes(GuiGraphicsExtractor g, Minecraft c, int x, int y, int alpha, float scale) {
        g.pose().pushMatrix(); g.pose().translate(x, y); g.pose().scale(scale, scale);
        drawKey(g,c,24,0,"W",c.options.keyUp.isDown(),alpha);
        drawKey(g,c,0,22,"A",c.options.keyLeft.isDown(),alpha);
        drawKey(g,c,24,22,"S",c.options.keyDown.isDown(),alpha);
        drawKey(g,c,48,22,"D",c.options.keyRight.isDown(),alpha);
        drawKey(g,c,0,46,"LMB",c.mouseHandler.isLeftPressed(),alpha);
        drawKey(g,c,40,46,"RMB",c.mouseHandler.isRightPressed(),alpha);
        g.pose().popMatrix();
    }

    private static void drawKey(GuiGraphicsExtractor g, Minecraft c, int x, int y,
                                String label, boolean pressed, int alpha) {
        int bg=(alpha<<24)|(pressed?0x164B60:0x101722);
        g.fill(x,y,x+36,y+20,bg);
        g.fill(x,y,x+36,y+1,(alpha<<24)|(pressed?0x45D7F5:0x293B4C));
        g.centeredText(c.font,label,x+18,y+6,0xFFFFFFFF);
    }

    static void setHudVisible(boolean v){hudVisible=v;saveConfig();}
    static void setSprintEnabled(boolean v){sprintEnabled=v;if(!v)toggleSprint=false;saveConfig();}
    static void setZoomEnabled(boolean v){zoomEnabled=v;if(!v&&zooming)restoreFov(Minecraft.getInstance());saveConfig();}
    static void setPerspectiveEnabled(boolean v){perspectiveEnabled=v;saveConfig();}
    static void setShowFps(boolean v){showFps=v;saveConfig();}
    static void setShowCps(boolean v){showCps=v;saveConfig();}
    static void setShowKeys(boolean v){showKeys=v;saveConfig();}
    static void setShowArmor(boolean v){showArmor=v;saveConfig();}
    static void setShowPotions(boolean v){showPotions=v;saveConfig();}
    static void setDynamicFov(boolean v){dynamicFov=v;Minecraft.getInstance().options.fovEffectScale().set(v?1.0:0.0);saveConfig();}
    static void cycleOpacity(){opacity=opacity>=100?20:opacity+10;saveConfig();}
    static void cycleAnchor(){anchor=anchor.equals("TOP_LEFT")?"TOP_RIGHT":anchor.equals("TOP_RIGHT")?"BOTTOM_RIGHT":anchor.equals("BOTTOM_RIGHT")?"BOTTOM_LEFT":"TOP_LEFT";saveConfig();}
    static void cycleScale(){hudScale=hudScale>=150?50:hudScale+10;saveConfig();}
    static void cycleOffsetX(){offsetX=offsetX>=80?0:offsetX+8;saveConfig();}
    static void cycleOffsetY(){offsetY=offsetY>=80?0:offsetY+8;saveConfig();}
    static void cycleRenderDistance(){Minecraft c=Minecraft.getInstance();int v=c.options.renderDistance().get();c.options.renderDistance().set(v>=12?2:Math.min(12,v+2));}

    static void cycleSimulationDistance(){Minecraft c=Minecraft.getInstance();int v=c.options.simulationDistance().get();c.options.simulationDistance().set(v>=8?5:Math.max(5,v+2));}
    static void resetLayout(){anchor="TOP_LEFT";offsetX=8;offsetY=8;hudScale=100;opacity=92;saveConfig();}
    static void applyPerformancePreset(int preset){
        Minecraft c=Minecraft.getInstance();
        c.options.renderDistance().set(preset==0?6:preset==1?4:2);
        c.options.simulationDistance().set(preset==0?6:5);
        c.options.graphicsPreset().set(GraphicsPreset.FAST);
        c.options.cloudStatus().set(CloudStatus.OFF);
        c.options.entityShadows().set(false);
        c.options.enableVsync().set(false);
        saveConfig();
    }

    /** Applies supported Sodium 0.9.x options through Sodium's live options object. */
    static void applySodiumPreset(int preset) {
        if (!FabricLoader.getInstance().isModLoaded("sodium")) return;
        try {
            Class<?> sodium = Class.forName("net.caffeinemc.mods.sodium.client.SodiumClientMod");
            Object options = sodium.getMethod("options").invoke(null);
            Object performance = options.getClass().getField("performance").get(options);
            Object quality = options.getClass().getField("quality").get(options);

            performance.getClass().getField("chunkBuilderThreads").setInt(performance, 0);
            performance.getClass().getField("chunkBuildDeferMode").set(performance,
                    Enum.valueOf((Class) Class.forName("net.caffeinemc.mods.sodium.client.render.chunk.DeferMode"), "ALWAYS"));
            performance.getClass().getField("animateOnlyVisibleTextures").setBoolean(performance, true);
            performance.getClass().getField("useEntityCulling").setBoolean(performance, true);
            performance.getClass().getField("useFogOcclusion").setBoolean(performance, true);
            performance.getClass().getField("useBlockFaceCulling").setBoolean(performance, true);
            performance.getClass().getField("useNoErrorGLContext").setBoolean(performance, true);
            if (preset == 1) {
                quality.getClass().getField("hiddenFluidCulling").setBoolean(quality, true);
                quality.getClass().getField("improvedFluidShaping").setBoolean(quality, false);
                quality.getClass().getField("useClosestPointEntitySort").setBoolean(quality, false);
                quality.getClass().getField("pixelFilteringMode").set(quality,
                        Enum.valueOf((Class) Class.forName("com.mojang.renderpearl.api.textures.FilterMode"), "NEAREST"));
            }
            Class<?> sodiumOptions = Class.forName("net.caffeinemc.mods.sodium.client.gui.SodiumOptions");
            sodiumOptions.getMethod("writeToDisk", sodiumOptions).invoke(null, options);
            Minecraft client = Minecraft.getInstance();
            client.options.renderDistance().set(preset == 1 ? 4 : 6);
            client.options.simulationDistance().set(preset == 1 ? 5 : 6);
            client.options.graphicsPreset().set(GraphicsPreset.FAST);
            client.options.cloudStatus().set(CloudStatus.OFF);
            client.options.entityShadows().set(false);
            client.options.enableVsync().set(false);
        } catch (Throwable error) {
            System.err.println("[WinterHUD] Could not apply Sodium preset: " + error);
        }
    }

    private static void loadConfig() {
        Properties p = new Properties();
        if (Files.isRegularFile(CONFIG)) {
            try (InputStream in = Files.newInputStream(CONFIG)) { p.load(in); } catch (Exception ignored) { }
        }
        hudVisible=bool(p,"hud.enabled",true); showFps=bool(p,"hud.fps",true); showCps=bool(p,"hud.cps",true);
        showKeys=bool(p,"hud.keystrokes",true); showArmor=bool(p,"hud.armor",true); showPotions=bool(p,"hud.potions",true);
        sprintEnabled=bool(p,"mod.toggleSprint",true); zoomEnabled=bool(p,"mod.zoom",true);
        perspectiveEnabled=bool(p,"mod.perspective",true); dynamicFov=bool(p,"video.dynamicFov",false);
        blockColorEnabled=bool(p,"visual.blockColorEnabled",false); hitColorEnabled=bool(p,"visual.hitColorEnabled",false);
        hitboxesEnabled=bool(p,"visual.hitboxesEnabled",false);
        blockColor=color(p,"visual.blockColor",0xFF45D7F5); hitColor=color(p,"visual.hitColor",0xFFFF5B7F);
        anchor=p.getProperty("hud.anchor","TOP_LEFT");
        if(!anchor.matches("TOP_LEFT|TOP_RIGHT|BOTTOM_LEFT|BOTTOM_RIGHT"))anchor="TOP_LEFT";
        offsetX=clamp(integer(p,"hud.offsetX",8),0,200); offsetY=clamp(integer(p,"hud.offsetY",8),0,200);
        hudScale=clamp(integer(p,"hud.scale",100),50,150); opacity=clamp(integer(p,"hud.opacity",92),20,100);
    }

    private static void saveConfig() {
        Properties p=new Properties();
        p.setProperty("hud.enabled",String.valueOf(hudVisible)); p.setProperty("hud.fps",String.valueOf(showFps));
        p.setProperty("hud.cps",String.valueOf(showCps)); p.setProperty("hud.keystrokes",String.valueOf(showKeys));
        p.setProperty("hud.armor",String.valueOf(showArmor)); p.setProperty("hud.potions",String.valueOf(showPotions));
        p.setProperty("mod.toggleSprint",String.valueOf(sprintEnabled)); p.setProperty("mod.zoom",String.valueOf(zoomEnabled));
        p.setProperty("mod.perspective",String.valueOf(perspectiveEnabled)); p.setProperty("video.dynamicFov",String.valueOf(dynamicFov));
        p.setProperty("visual.blockColorEnabled",String.valueOf(blockColorEnabled)); p.setProperty("visual.hitColorEnabled",String.valueOf(hitColorEnabled));
        p.setProperty("visual.hitboxesEnabled",String.valueOf(hitboxesEnabled));
        p.setProperty("visual.blockColor",String.format(java.util.Locale.ROOT,"%08X",blockColor));
        p.setProperty("visual.hitColor",String.format(java.util.Locale.ROOT,"%08X",hitColor));
        p.setProperty("hud.anchor",anchor); p.setProperty("hud.offsetX",String.valueOf(offsetX)); p.setProperty("hud.offsetY",String.valueOf(offsetY));
        p.setProperty("hud.scale",String.valueOf(hudScale)); p.setProperty("hud.opacity",String.valueOf(opacity));
        try { Files.createDirectories(CONFIG.getParent()); try(OutputStream out=Files.newOutputStream(CONFIG)){p.store(out,"WinterHUD 26.3 settings");} } catch(Exception ignored) { }
    }

    private static boolean bool(Properties p,String k,boolean fallback){return Boolean.parseBoolean(p.getProperty(k,String.valueOf(fallback)));}
    private static int integer(Properties p,String k,int fallback){try{return Integer.parseInt(p.getProperty(k,String.valueOf(fallback)));}catch(Exception e){return fallback;}}
    private static int clamp(int v,int min,int max){return Math.max(min,Math.min(max,v));}
    private static int color(Properties p,String key,int fallback){try{return (int)Long.parseLong(p.getProperty(key,String.format(java.util.Locale.ROOT,"%08X",fallback)),16);}catch(Exception e){return fallback;}}
    private static void applyHitboxesSetting(){Minecraft c=Minecraft.getInstance();c.debugEntries.setStatus(DebugScreenEntries.ENTITY_HITBOXES,hitboxesEnabled?DebugScreenEntryStatus.ALWAYS_ON:DebugScreenEntryStatus.IN_OVERLAY);c.debugEntries.save();}
    static void setBlockColorEnabled(boolean v){blockColorEnabled=v;saveConfig();}
    static void setHitColorEnabled(boolean v){hitColorEnabled=v;saveConfig();}
    static void setHitboxesEnabled(boolean v){hitboxesEnabled=v;applyHitboxesSetting();saveConfig();}
    static void setBlockColor(int v){blockColor=0xFF000000|(v&0xFFFFFF);saveConfig();}
    static void setHitColor(int v){hitColor=0xFF000000|(v&0xFFFFFF);saveConfig();}
    public static boolean isBlockColorEnabled(){return blockColorEnabled;}
    public static boolean isHitColorEnabled(){return hitColorEnabled;}
    public static int getBlockColor(){return blockColor;}
    public static int getHitColor(){return hitColor;}
    static boolean isHitboxesEnabled(){return hitboxesEnabled;}
    static boolean isHudVisible(){return hudVisible;}
    static boolean isSprintEnabled(){return sprintEnabled;}
    static boolean isZoomEnabled(){return zoomEnabled;}
    static boolean isPerspectiveEnabled(){return perspectiveEnabled;}
    static boolean isShowFps(){return showFps;}
    static boolean isShowCps(){return showCps;}
    static boolean isShowKeys(){return showKeys;}
    static boolean isShowArmor(){return showArmor;}
    static boolean isShowPotions(){return showPotions;}
    static boolean isDynamicFov(){return dynamicFov;}
    static String getAnchor(){return anchor;}
    static int getScale(){return hudScale;}
    static int getOpacity(){return opacity;}
    static int getOffsetX(){return offsetX;}
    static int getOffsetY(){return offsetY;}
}
