package net.frostclient.winterhud.mixin;

import net.frostclient.winterhud.WinterHudClient;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.renderer.LevelRenderer;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.renderer.rendertype.RenderType;
import net.minecraft.client.renderer.state.level.BlockOutlineRenderState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

/** Applies WinterHUD's selected color to the vanilla block-selection outline. */
@Mixin(value = LevelRenderer.class, remap = false)
abstract class LevelRendererMixin {
    @ModifyVariable(
            method = "submitHitOutline",
            at = @At("HEAD"),
            argsOnly = true,
            ordinal = 0,
            remap = false
    )
    private int winterhud$blockOutlineColor(int original) {
        return WinterHudClient.isBlockColorEnabled() ? WinterHudClient.getBlockColor() : original;
    }
}
